<?php

use yii\helpers\Html;

$this->title = 'View Currency';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        
        <div class="row">
            <div class="col-md-12">
                <h3>Currency ID: <?= Html::encode($model->id) ?></h3>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Code</th>
                            <th>Symbol</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?= Html::encode($model->name) ?></td>
                            <td><?= Html::encode($model->code) ?></td>
                            <td><?= Html::encode($model->symbol) ?></td>
                        </tr>
                    </tbody>
                </table>
                <div class="form-group">
                    <?= Html::a('Back to Currency List', ['index'], ['class' => 'btn btn-primary']) ?>
                </div>
            </div>
        </div>
    </div>
</main>
