<?php

use yii\helpers\Html;

$this->title = 'Currencies';
$this->params['breadcrumbs'][] = $this->title;
?>
<main class="dash-content">
    <div class="container-fluid">
    <?php
        if (Yii::$app->session->hasFlash('success')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
        }
        if (Yii::$app->session->hasFlash('error')) {
            echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
        }
        ?>
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <div class="row" style="margin-bottom: 20px;">


            <div class="col-auto ml-auto" style="float: right; display: inline-block;">
            </br></br></br>
                <?= Html::a('Add a Currency', ['create'], ['class' => 'btn btn-outline-primary  btn-lg rounded-pill']) ?>
            </div>
        </div>

            


        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Code</th>
                                <th>Symbol</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($currencies as $currency): ?>
                                <tr>
                                    <td><?= Html::encode($currency->name) ?></td>
                                    <td><?= Html::encode($currency->code) ?></td>
                                    <td><?= Html::encode($currency->symbol) ?></td>
                                    <td><?= Yii::$app->formatter->asDatetime($currency->created_at) ?></td>
                                    <td>
                                    <span><?= Html::a('View', ['view', 'id' => $currency->id], ['class' => 'btn btn-info']) ?></span>
                                    <span><?= Html::a('Modify', ['update', 'id' => $currency->id], ['class' => 'btn btn-primary']) ?></span>
                                    <span><?= Html::a('Remove', ['delete', 'id' => $currency->id], [
                                        'class' => 'btn btn-secondary',
                                        'data-confirm' => 'Are you sure you want to delete this item?',
                                        'data-method' => 'post'
                                    ]) ?></span>

                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
