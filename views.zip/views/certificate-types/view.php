<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var app\models\CertificateTypes $model */

$this->title = 'View Certificate Type: ' . $model->type;
$this->params['breadcrumbs'][] = ['label' => 'Certificate Types', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <div class="row">
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Certificate Type:</strong>
                    <?= Html::encode($model->type) ?>
                </li>
              
            </ul>
            <div class="row">
                <?= Html::a('Back to Certificate Types', ['index'], ['class' => 'btn btn-primary']) ?>
            </div>
        </div>
    </div>
</main>
