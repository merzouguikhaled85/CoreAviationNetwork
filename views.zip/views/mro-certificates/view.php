<?php

use yii\helpers\Html;

$this->title = 'View Certificate: ' . $certificate->certificate_id;
$this->params['breadcrumbs'][] = ['label' => 'Certificates', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <div class="row">
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Certificate ID:</strong>
                    <?= Html::encode($certificate->certificate_id) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>MRO Name:</strong>
                    <?= Html::encode($certificate->mro->username) ?> <!-- Assuming MRO username is the display name -->
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>NAA - National Aviation Authority:</strong>
                    <?= Html::encode($certificate->type) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Certificate File:</strong>
                    <?= Html::a('Download', Yii::$app->request->baseUrl . '/' . $certificate->certificate, ['target' => '_blank']) ?>
                </li>
            </ul>
            <div class="row">
                <?= Html::a('Back to Certificates', ['index'],  ['class' => 'btn btn-primary']) ?>
            </div>
        </div>
    </div>
</main>
