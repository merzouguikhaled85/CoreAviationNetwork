<?php

use yii\helpers\Html;

$this->title = 'View Certificate: ' . $certificate->aircraft_certificate_id;
$this->params['breadcrumbs'][] = ['label' => 'Certificates', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <div class="row">
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Certificate ID:</strong>
                    <?= Html::encode($certificate->aircraft_certificate_id) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>MRO Name:</strong>
                    <?= Html::encode($certificate->mro->username) ?> <!-- Assuming MRO username is the display name -->
                </li>

                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Aircraft Manufacturer:</strong>
                    <?= Html::encode($certificate->aircraftModel->manufacturer) ?> <!-- Assuming you have this relation -->
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Aircraft Type:</strong>
                    <?= Html::encode($certificate->aircraftModel->model) ?> <!-- Assuming model_name is the attribute for model name -->
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Certificate File:</strong>
                    <?= Html::a('Download', Yii::$app->request->baseUrl . '/' . $certificate->certificate, ['target' => '_blank']) ?>
                </li>
            </ul>
            <div class="row" style="margin-top: 20px;">
                <?= Html::a('Back to Certificates', ['index'], ['class' => 'btn btn-primary']) ?>
            </div>
        </div>
    </div>
</main>
