<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;

$this->title = 'Create Certificate';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">Create Certificate</h1>

        <?php
        // Check for flash messages
        if (Yii::$app->session->hasFlash('success')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
        }

        if (Yii::$app->session->hasFlash('error')) {
            echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
        }
        ?>

        <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); // Enable file uploads ?>
        <div class="row">
            <div class="form-group col-lg-6">
                <?= $form->field($certificate, 'manufacturer')->dropDownList(
                    ArrayHelper::map(\app\models\AircraftModel::find()->select('manufacturer')->distinct()->all(), 'manufacturer', 'manufacturer'),
                    [
                        'prompt' => 'Select Manufacturer',
                        'id' => 'manufacturer-dropdown',
                    ]
                )->label('Manufacturer<span class="text-danger">*</span>') ?>
            </div>
        </div>

        <div class="row">
            <div class="form-group col-lg-6">
                <?= $form->field($certificate, 'aircraft_model_id')->dropDownList([], [
                    'prompt' => 'Select Aircraft Type',
                    'id' => 'model-dropdown',
                ])->label('Aircraft Model<span class="text-danger">*</span>') ?>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-lg-6">
                <?= $form->field($certificate, 'certificate')->fileInput(['maxlength' => true, 'accept' => '.pdf, .doc, .docx'])->label($certificate->getAttributeLabel('certificate') . '<span class="text-danger">*</span>') ?>
            </div>
        </div>

        <div class="row">
            <div class="form-group col-lg-6">
                <?= $form->field($certificate, 'mro_id')->hiddenInput(['value' => Yii::$app->user->identity->mro_id])->label(false) ?>
            </div>
        </div>



        <div class="row">
            <div class="form-group col-lg-8">
                <div class="row">
                    <div class="col-lg-6">
                        <?= Html::submitButton('Create Certificate', ['class' => 'btn btn-primary']) ?>
                    </div>
                    <div class="col-lg-2">
                        <?= Html::a('Back to Certificates', ['index'], ['class' => 'btn btn-secondary']) ?>
                    </div>
                </div>
            </div>
        </div>

        <?php ActiveForm::end(); ?>
      
    </div>
</main>

<?php
$this->registerJs("
    $('#manufacturer-dropdown').change(function() {
        var selectedManufacturer = $(this).val();
        $.ajax({
            url: '" . Url::to(['mro-aircraft-certificates/get-models-by-manufacturer']) . "',
            type: 'GET',
            data: { manufacturer: selectedManufacturer },
            success: function(data) {
                var modelDropdown = $('#model-dropdown');
                modelDropdown.empty(); // Clear previous options
                modelDropdown.append('<option value=\"\">Select Aircraft Model</option>');

                $.each(data, function(index, model) {

                    modelDropdown.append('<option value=\"' + model.id + '\">' + model.name + '</option>');
                });
            },
            error: function(xhr, status, error) {
                console.error('Error fetching models:', error);
                alert('Error fetching models. Please check console for details.');
            }
        });
    });

   
");
?>
