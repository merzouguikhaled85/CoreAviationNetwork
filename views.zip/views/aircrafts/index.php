<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;


// Define custom CSS styles for pagination links
$this->registerCss("
    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    
    .pagination li {
        margin: 0 5px;
    }
    
    .pagination .active a {
        background-color: #007bff;
        color: #fff;
    }
    
    .pagination li a {
        color: #007bff;
        border: 1px solid #007bff;
        padding: 6px 12px;
        text-decoration: none;
        border-radius: 3px;
    }
    
    .pagination li a:hover {
        background-color: #f2f2f2;
    }
");
$this->title = 'Aircrafts';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">Aircrafts</h1>
        
        <?php if (Yii::$app->session->hasFlash('message')): ?>
            <div class="alert alert-success">
                <?= Yii::$app->session->getFlash('message') ?>
            </div>
        <?php endif; ?>

        <div class="row" style="margin-bottom: 20px;">
        <div class="col-auto ml-auto" style="float: right; display: inline-block;">

            <?= Html::a('Add Aircraft Model', ['create'],['class' => 'btn btn-outline-primary  btn-lg rounded-pill']) ?>
            </div>
        </div>
        
        <div class="row">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Manufacturer</th>
                        <th>Model</th>
                        <th>Serial Number</th>
                        <th>Registration Number</th>
                        <th>Owner Username</th> <!-- New column -->

                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($aircraftModels as $aircraftModel): ?>
                        <tr>
                            <td><?= $aircraftModel->aircraft_id ?></td>
                            <td><?= $aircraftModel->manufacturer ?></td>
                            <td><?= $aircraftModel->model ?></td>
                            <td><?= $aircraftModel->serial_number ?></td>
                            <td><?= $aircraftModel->registration_number ?></td>
                            <td><?= $aircraftModel->owner ? $aircraftModel->owner->username : 'N/A' ?></td> <!-- Display owner username -->

                            <td>
                                <?= Html::a('View', ['view', 'id' => $aircraftModel->aircraft_id], ['class' => 'btn btn-info']) ?>
                                <?= Html::a('Modify', ['update', 'id' => $aircraftModel->aircraft_id], ['class' => 'btn btn-primary']) ?>
                                <?= Html::a('Remove', ['delete', 'id' => $aircraftModel->aircraft_id], [
                                    'class' => 'btn btn-secondary',
                                    'data' => [
                                        'confirm' => 'Are you sure you want to delete this item?',
                                        'method' => 'post',
                                    ],
                                ]) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="pagination-container">
            <?= LinkPager::widget(['pagination' => $pagination]) ?>
        </div>
    </div>
</main>
