<?php
use yii\helpers\Html;

$this->title = 'View Aircraft Model';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">View Aircraft</h1>
        <div class="row">
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Manufacturer: <?= $aircraftModel->manufacturer ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Model: <?= $aircraftModel->model ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Serial Number: <?= $aircraftModel->serial_number ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Registration Number: <?= $aircraftModel->registration_number ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Owner Username: <?= $ownerUsername ?>
                </li>
            </ul>
            <div class="row">
            <?= Html::a('Back to aircraft models', ['index'], ['class' => 'btn btn-primary']) ?>
            </div>
        </div>
    </div>
</main>
