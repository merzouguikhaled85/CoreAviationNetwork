<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\LinkPager;

$this->title = 'Disputes';

// Register custom CSS styles for pagination links and search input
$this->registerCss("
    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    
    .pagination li {
        margin: 0 5px;
    }
    
    .pagination .active a {
        background-color: #007bff;
        color: #fff;
    }
    
    .pagination li a {
        color: #007bff;
        border: 1px solid #007bff;
        padding: 6px 12px;
        text-decoration: none;
        border-radius: 3px;
    }
    
    .pagination li a:hover {
        background-color: #f2f2f2;
    }
    
    .search-container {
        display: flex;
        border-radius: 20px;
        overflow: hidden;
    }
    
    .search-input {
        flex: 1;
        border-top-left-radius: 20px;
        border-bottom-left-radius: 20px;
    }
    
    .search-button {
        border-top-right-radius: 20px;
        border-bottom-right-radius: 20px;
    }
    .search-input-lg {
        width: 100%; /* Set width to 100% to make it full width */
        height: 50px; /* Adjust height as needed */
        font-size: 18px; /* Increase font size for larger input */
    }
");
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">Disputes</h1>

        <?php
        // Check for flash messages
        if (Yii::$app->session->hasFlash('success')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
        }
        if (Yii::$app->session->hasFlash('error')) {
            echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
        }
        ?>

        <div class="row" style="margin-bottom: 20px;">
            <div class="col-lg-12">
                <?= Html::beginForm(['ao-mro-dispute/index'], 'get', ['class' => 'form-inline']) ?>
                <?= Html::textInput('search', Yii::$app->request->get('search'), ['class' => 'form-control search-input search-input-lg', 'placeholder' => 'Search by Description or Status']) ?>
                <div class="input-group-append">
                    <?= Html::submitButton('Search', ['class' => 'btn btn-primary btn-lg search-button']) ?>
                </div>
                <?= Html::endForm() ?>
            </div>
    
            <div class="col-auto ml-auto" style="float: right; display: inline-block;">
            </br></br></br>
                <?= Html::a('Open a dispute', ['create'], ['class' => 'btn btn-outline-primary btn-lg rounded-pill']) ?>
            </div>
        </div>

        <div class="row">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Timestamp</th>
                        <th>Created By</th>
                        <th>AO</th>
                        <th>MRO</th>
                        <th>Description</th>
                        <th>PO</th>
                        <th>Status</th>
                        <th>Admin Response</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($disputes as $dispute): ?>
                        <tr>
                            <td><?= $dispute->dispute_id ?></td>
                            <td><?= Html::encode($dispute->timestamp) ?></td>
                            <td><?= Html::encode($dispute->created_by) ?></td>
                            <td><?= Html::encode($dispute->getAo()->one()->username) ?></td>
                            <td><?= Html::encode($dispute->getMro()->one()->username) ?></td>
                            <td><?= Html::encode($dispute->description) ?></td>
                            <td>
                                <?php if (!empty($dispute->po)): ?>
                                    <?= Html::a('Download PO', Yii::getAlias('@web/uploads/') . $dispute->po, [ 'target' => '_blank']) ?>
                                <?php else: ?>
                                    <?= Html::encode('No PO uploaded') ?>
                                <?php endif; ?>
                            </td>
                            <td><?= Html::encode($dispute->status) ?></td>
                            <td><?= Html::encode($dispute->admin_response) ?></td>
                            <td>
                            <?= Html::a('Delete', ['delete', 'id' => $dispute->dispute_id], [
                                'class' => 'btn btn-secondary',
                                'data' => [
                                    'confirm' => 'Are you sure you want to delete this item?',
                                    'method' => 'post',
                                ],
                                // Conditionally show based on user type
                                'style' => ($dispute->created_by == Yii::$app->session->get('user_type')) ? 'display: inline-block;' : 'display: none;',
                            ]) ?>
                            <?php if ($dispute->status != 'resolved' && $dispute->created_by == Yii::$app->session->get('user_type')): ?>
                                <?= Html::a('Close', ['close', 'id' => $dispute->dispute_id], [
                                    'class' => 'btn btn-primary',
                                    'data' => [
                                        'confirm' => 'Are you sure you want to close this dispute?',
                                        'method' => 'post',
                                    ],
                                ]) ?>
                            <?php endif; ?>

                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="pagination-container">
            <?= LinkPager::widget(['pagination' => $pagination]) ?>
        </div>
    </div>
</main>
