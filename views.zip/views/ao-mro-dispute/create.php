<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;


$this->title = 'Open a dispute';

?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">Open a dispute</h1>
        <?php
        // Check if there is a success flash message set
        if (Yii::$app->session->hasFlash('success')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
        }
        ?>
     <div class="dispute-form">
    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($dispute, 'request_id')->dropDownList($requests, [
        'prompt' => 'Select Request',
        'id' => 'request-id-dropdown' // Add an ID for easy selection in JavaScript
    ]) ?>

    <?= $form->field($dispute, 'ao_username')->textInput(['readonly' => true]) ?>

    <?= $form->field($dispute, 'mro_username')->textInput(['readonly' => true]) ?>

    <?= $form->field($dispute, 'ao_id')->hiddenInput()->label(false) ?>

    <?= $form->field($dispute, 'mro_id')->hiddenInput()->label(false) ?>

    <?= $form->field($dispute, 'po')->textInput(['maxlength' => true, 'readonly' => true]) ?>

    <!-- Download link for PO file -->
    <div class="form-group" style="display: none;">
            <?= Html::a('Download PO', Url::to('@web/uploads/' . $dispute->po), ['class' => 'btn btn-primary', 'target' => '_blank', 'id' => 'download-po-link']) ?>
    </div>

    <?= $form->field($dispute, 'description')->textarea(['rows' => 6]) ?>

    <?= $form->field($dispute, 'status')->hiddenInput(['value' => 'open'])->label(false) ?>

    <?= $form->field($dispute, 'created_by')->hiddenInput(['value' => Yii::$app->session->get('user_type')])->label(false) ?>

    <div class="form-group">
        <?= Html::submitButton('Create', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>

    </div>
</main>


<?php
$notificationCountUrl = Url::to(['ao-mro-dispute/fetch-details']); // Generating URL using Url::to()

// JavaScript section to handle onchange event of request_id dropdown
$script = <<< JS
$('#request-id-dropdown').on('change', function() {
    var requestId = $(this).val();

    if (requestId) {
        $.ajax({
            url: '{$notificationCountUrl}', // Using the generated URL
            type: 'GET',
            data: {requestId: requestId},
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    $('#dispute-ao_id').val(data.ao_id).trigger('change');
                    $('#dispute-mro_id').val(data.mro_id).trigger('change');
                    $('#dispute-ao_username').val(data.ao_username);
                    $('#dispute-mro_username').val(data.mro_username);
                    $('#dispute-po').val(data.po);

                    // Update the download link if po file exists
                    if (data.po) {
                        $('#download-po-link').attr('href', '/GlobalMRO/web/uploads/' + data.po).parent().show();
                    } else {
                        $('#download-po-link').parent().hide();
                    }
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching details:', error);
            }
        });
    }
});
JS;
$this->registerJs($script);
?>
