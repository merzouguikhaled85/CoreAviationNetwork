<?php

use app\models\MroProfile;
use yii\helpers\Html;

$this->title = 'My Appointments';

?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<script>
document.addEventListener('DOMContentLoaded', function () {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
});
</script>
<main class="dash-content">
    <div class="container-fluid">
<h1><?= Html::encode($this->title) ?></h1>
<br><br>
<?php if (Yii::$app->session->hasFlash('success')): ?>
    <div class="alert alert-success">
        <?= Yii::$app->session->getFlash('success') ?>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('error') ?>
    </div>
<?php endif; ?>
<div class="row">

<table class="table table-bordered">
    <thead>
        <tr>
        <th>Request ID</th>
            <th>MRO</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($appointments as $appointment): ?>
            <tr>
            <td><?= Html::encode($appointment->request_id) ?></td>
                <td><?= Html::encode(MroProfile::findOne($appointment->mro_id)->username) ?></td>
                <td><?= Html::encode($appointment->appointment_date) ?></td>
                <td><?= Html::encode($appointment->status) ?></td>
                <td>
             <?php if ($appointment->status !== 'confirmed'): ?>
    <?= Html::a('<i class="bi bi-x-circle"></i>', ['cancel', 'id' => $appointment->id], [
        'class' => 'btn btn-secondary',
        'title' => 'Cancel Appointment',
        'data' => [
            'confirm' => 'Are you sure you want to cancel this appointment?',
        ],
    ]) ?>

    <?= Html::a('<i class="bi bi-check-circle"></i>', ['confirm', 'id' => $appointment->id], [
        'class' => 'btn btn-info',
        'title' => 'Confirm Appointment',
    ]) ?>
<?php endif; ?>

<?php if ($appointment->status === 'waiting response'): ?>
    <?= Html::a('<i class="bi bi-arrow-repeat"></i>', ['reschedule', 'id' => $appointment->id], [
        'class' => 'btn btn-primary',
        'title' => 'Reschedule Appointment',
    ]) ?>
<?php endif; ?>

                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>
</div>
</main>
