<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\datetime\DateTimePicker;

$this->title = 'Reschedule Appointment';
$this->params['breadcrumbs'][] = ['label' => 'My Appointments', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<h1><?= Html::encode($this->title) ?></h1>

<div class="appointment-reschedule-form">
    <?php $form = ActiveForm::begin(); ?>

<?= $form->field($appointment, 'reschedule_appointment_date')->widget(DateTimePicker::class, [
    'options' => [
        'value' => $appointment->reschedule_appointment_date
            ? date('d M Y H:i', strtotime($appointment->reschedule_appointment_date))
            : '',
    ],
    'pluginOptions' => [
        'format' => 'dd M yyyy HH:ii', // e.g. 16 Jul 2025 08:30
        'autoclose' => true,
        'todayHighlight' => true,
    ],
]) ?>
    <div class="form-group">
        <?= Html::submitButton('Reschedule', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>
