<?php

use yii\helpers\Html;

$this->title = 'View AO Profile: ' . $aoProfile->ao_id;
$this->params['breadcrumbs'][] = ['label' => 'AO Profiles', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        
        <div class="row">
            <ul class="list-group">

                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Profile Photo: <?= Html::img('@web/' . $aoProfile->profile_photo, ['class' => 'img-fluid', 'alt' => 'Profile Photo', 'style' => 'width:100px;']) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    First Name: <?= Html::encode($aoProfile->first_name) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Last Name: <?= Html::encode($aoProfile->last_name) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Username: <?= Html::encode($aoProfile->username) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Email: <?= Html::encode($aoProfile->email) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Contact Number: <?= Html::encode($aoProfile->contact_number) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Company Name: <?= Html::encode($aoProfile->company_name) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Status: <?= ucfirst(Html::encode($aoProfile->status)) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Email Verified: <?= $aoProfile->email_verified ? 'Yes' : 'No' ?>
                </li>
            </ul>

        </div>
    </div>
</main>
