<?php

use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;

use yii\web\UploadedFile; // Add this line if it's not already imported

$this->title = 'Update AO Profile';
// Convert cities to a JavaScript-friendly format
$citiesByCountry = [];
foreach ($cities as $city) {
    $citiesByCountry[$city->country_id][] = ['id' => $city->city_id, 'name' => $city->city_name];
}

// JSON encode the cities array for use in JavaScript
$citiesByCountryJson = json_encode($citiesByCountry);
?>


<main class="dash-content">
    
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        
<?php if (Yii::$app->session->hasFlash('message')): ?>
    <!-- Open the Add Airplane modal using JavaScript -->
    <?= Yii::$app->session->getFlash('message') ?>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('error') ?>
    </div>
<?php endif; ?>
        <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>
        
        <!-- Username field -->
        <?= $form->field($aoProfile, 'username')->label('Username' . '<span class="text-danger">*</span>') ?>
        


        <!-- Email field -->
        <?= $form->field($aoProfile, 'email')->label('Email' . '<span class="text-danger">*</span>') ?>
        
        <!-- First name field -->
        <?= $form->field($aoProfile, 'first_name') ?>
        
        <!-- Last name field -->
        <?= $form->field($aoProfile, 'last_name') ?>
        
        <!-- Contact number field -->
        <?= $form->field($aoProfile, 'contact_number') ?>
        
        <!-- Company name field -->
        <?= $form->field($aoProfile, 'company_name') ?>
        
        <!-- Profile photo file input -->
        <?= $form->field($aoProfile, 'profile_photo')->fileInput() ?>

<?php if (!empty($aoProfile->profile_photo)): ?>
    <div>
        <label>Current Company Photo:</label>
        <img src="<?= Yii::getAlias('@web') . '/' . $aoProfile->profile_photo ?>" alt="profile_photo" style="max-width: 200px; max-height: 200px;">
    </div>
<?php endif; ?>

  <!-- Country and City dropdowns -->
<div class="row">
    <div class="form-group col-lg-6">
<?= $form->field($aoProfile, 'country_id')->dropDownList(
    ArrayHelper::map($countries, 'country_id', 'country_name'),
    [
        'prompt' => 'Select Country',
        'id' => 'country-select',
        'class' => 'form-select form-select-lg',
    ]
)->label('Country <span class="text-danger">*</span>') ?>

<?= $form->field($aoProfile, 'city_id')->dropDownList(
    ArrayHelper::map($cities, 'city_id', 'city_name'),
    [
        'prompt' => 'Select City',
        'id' => 'city-select',
        'class' => 'form-select form-select-lg',
    ]
)->label('City <span class="text-danger">*</span>') ?>


</div>

</div>
        <!-- Company name field -->
        <?= $form->field($aoProfile, 'address')->label('Address' . '<span class="text-danger">*</span>') ?>
                <?= $form->field($aoProfile, 'zip_code')->label('Zip Code' . '<span class="text-danger">*</span>') ?>

<!-- Submit button -->
<div class="form-group">
    <?= Html::submitButton('Update AO Profile', ['class' => 'btn btn-primary']) ?>
</div>

<?php ActiveForm::end() ?>
<!-- End form -->


<?php
$cityUrl = \yii\helpers\Url::to(['ao-profile/cities-by-country']); // Adjust route if needed
$selectedCityId = $aoProfile->city_id;
$script = <<<JS
$('#country-select').on('change', function() {
    var countryId = $(this).val();
    var citySelect = $('#city-select');

    citySelect.html('<option value="">Loading...</option>');

    if (!countryId) {
        citySelect.html('<option value="">Select City</option>');
        return;
    }

    $.ajax({
        url: '{$cityUrl}',
        data: { country_id: countryId },
        success: function(data) {
            citySelect.empty();
            citySelect.append('<option value="">Select City</option>');
            $.each(data, function(index, city) {
                var selected = (city.id == '{$selectedCityId}') ? 'selected' : '';
                citySelect.append('<option value="' + city.id + '" ' + selected + '>' + city.name + '</option>');
            });
        },
        error: function() {
            citySelect.html('<option value="">Error loading cities</option>');
        }
    });
});
JS;

$this->registerJs($script);
?>
