<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Update Password';
?>

<h1><?= Html::encode($this->title) ?></h1>
<?php if (Yii::$app->session->hasFlash('success')): ?>
    <!-- Open the Add Airplane modal using JavaScript -->
    <?= Yii::$app->session->getFlash('success') ?>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('error') ?>
    </div>
    <?php endif; ?>

<div class="reset-password-form">
    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'old_password')->passwordInput() ?>
    <?= $form->field($model, 'new_password')->passwordInput() ?>
    <?= $form->field($model, 'confirm_password')->passwordInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Update Password', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>
