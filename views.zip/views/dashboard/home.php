<?php 
use yii\helpers\Html;

$this->title = 'GlobaleMRO';
$user = Yii::$app->user->identity;
?>

<main class="dash-content">
<?php if (Yii::$app->session->hasFlash('message')): ?>
            <div class="alert alert-success">
                <?= Yii::$app->session->getFlash('message') ?>
            </div>
        <?php endif; ?>
        <?php if (Yii::$app->session->hasFlash('success')): ?>
            <div class="alert alert-success">
                <?= Yii::$app->session->getFlash('success') ?>
            </div>
        <?php endif; ?>
        <?php if (Yii::$app->session->hasFlash('error')): ?>
            <div class="alert alert-success">
                <?= Yii::$app->session->getFlash('error') ?>
            </div>
        <?php endif; ?>

    <div class="container-fluid">
        <h1 class="dash-title">Dashboard</h1>
        <?php if ($user): ?>
            <h2 class="dash-subtitle">Welcome,</h2>
        <?php else: ?>
            <p>User identity is not set.</p>
        <?php endif; ?>
    </div>
</main>
