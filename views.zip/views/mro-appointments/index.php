<?php

use app\models\AoProfile;
use yii\helpers\Html;

$this->title = 'My Appointments';

?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<script>
document.addEventListener('DOMContentLoaded', function () {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
});
</script>
</br></br>
<h1><?= Html::encode($this->title) ?></h1>
</br></br>
<?php if (Yii::$app->session->hasFlash('success')): ?>
    <div class="alert alert-success">
        <?= Yii::$app->session->getFlash('success') ?>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('error') ?>
    </div>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
        <th>Request ID</th>
            <th>AO</th>
            <th>Date</th>
            <th>Status</th>
            <th>Reschedule Date</th>
            <th>Actions</th> <!-- Added column for actions -->
        </tr>
    </thead>
    <tbody>
        <?php foreach ($appointments as $appointment): ?>
            <tr>
            <td><?= Html::encode($appointment->request_id) ?></td>
                <td><?= Html::encode(AoProfile::findOne($appointment->ao_id)->username) ?></td>
<td>
    <?= Html::encode($appointment->appointment_date
        ? date('d M Y H:i', strtotime($appointment->appointment_date))
        : '') ?>
</td>
                <td><?= Html::encode($appointment->status) ?></td>
<td>
    <?= Html::encode($appointment->reschedule_appointment_date
        ? date('d M Y H:i', strtotime($appointment->reschedule_appointment_date))
        : '') ?>
</td>
                <td>
<?php if ($appointment->status === 'reschedule'): ?>
    <?= Html::a('<i class="bi bi-check2-circle"></i>', ['accept-reschedule', 'id' => $appointment->id], [
        'class' => 'btn btn-primary',
        'title' => 'Accept Reschedule',
        'data' => [
            'confirm' => 'Are you sure you want to accept this rescheduled appointment date?',
            'method' => 'post',
        ],
    ]) ?>
<?php endif; ?>

<?php if ($appointment->status !== 'confirmed'): ?>
    <?= Html::a('<i class="bi bi-trash"></i>', ['remove-appointment', 'id' => $appointment->id], [
        'class' => 'btn btn-secondary',
        'title' => 'Remove Appointment',
        'data' => [
            'confirm' => 'Are you sure you want to remove this appointment?',
            'method' => 'post',
        ],
    ]) ?>
<?php endif; ?>


                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
