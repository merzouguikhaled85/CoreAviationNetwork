<?php
use yii\helpers\Html;

$this->title = 'Awaiting Request Response';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <?php if (Yii::$app->session->hasFlash('success')): ?>
            <div class="alert alert-success">
                <?= Yii::$app->session->getFlash('success') ?>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>AO</th>
                        <th>MRO</th>
                        <th>Updated At</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reportsAwaitingMRO as $repairReport): ?>
                        <tr>
                            <?php if ($repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one() && $repairReport->getMroRequestApply()->one()->getMro()):?>
                            <td><?= Html::encode($repairReport->getMroRequestApply()->one()->getRequest()->one()->request_id) ?></td>
                            <td><?= Html::encode($repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one()->username) ?></td>
                            <td><?= Html::encode($repairReport->getMroRequestApply()->one()->getMro()->username) ?></td>
                            <td><?= Html::encode($repairReport->updated_at) ?></td>
                            <td><?= Html::encode($statusAwaitingMRO) ?></td>
                            <td>
                            <?= Html::a('Notify AO', ['notify-ao', 'id' => $repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one()->ao_id], ['class' => 'btn btn-info']) ?>
                            <?= Html::a('Notify MRO', ['notify-mro', 'id' => $repairReport->getMroRequestApply()->one()->getMro()->mro_id], ['class' => 'btn btn-info']) ?>
                            <?php if ($repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one()->status == 'banned'): ?>
                            <?= Html::a('Unban AO', ['unban-ao', 'id' => $repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one()->ao_id], [
                                'class' => 'btn btn-primary',
                                'data' => [
                                    'confirm' => 'Are you sure you want to unban this AO?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                            <?php else: ?>
                            <?= Html::a('Ban AO', ['ban-ao', 'id' => $repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one()->ao_id], [
                                'class' => 'btn btn-primary',
                                'data' => [
                                    'confirm' => 'Are you sure you want to ban this AO?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                            <?php endif; ?>
                            <?php if ($repairReport->getMroRequestApply()->one()->getMro()->status == 'banned'): ?>
                            <?= Html::a('Unban MRO', ['unban-mro', 'id' => $repairReport->getMroRequestApply()->one()->getMro()->mro_id], [
                                'class' => 'btn btn-primary',
                                'data' => [
                                    'confirm' => 'Are you sure you want to unban this MRO?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                            <?php else: ?>
                            <?= Html::a('Ban MRO', ['ban-mro', 'id' => $repairReport->getMroRequestApply()->one()->getMro()->mro_id], [
                                'class' => 'btn btn-primary',
                                'data' => [
                                    'confirm' => 'Are you sure you want to ban this MRO?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                            <?php endif; ?>

                            </td>
                            <?php endif; ?>

                        </tr>
                    <?php endforeach; ?>
                    
                    <?php foreach ($reportsAwaitingAO as $repairReport): ?>
                        <tr>
                        <?php if ($repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one() && $repairReport->getMroRequestApply()->one()->getMro()):?>

                            <td><?= Html::encode($repairReport->getMroRequestApply()->one()->getRequest()->one()->request_id) ?></td>
                            <td><?= Html::encode($repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one()->username) ?></td>
                            <td><?= Html::encode($repairReport->getMroRequestApply()->one()->getMro()->username) ?></td>
                            <td><?= Html::encode($repairReport->updated_at) ?></td>
                            <td><?= Html::encode($statusAwaitingAO) ?></td>
                            <td>
                            <?= Html::a('Notify AO', ['notify-ao', 'id' => $repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one()->ao_id], ['class' => 'btn btn-info']) ?>
                            <?= Html::a('Notify MRO', ['notify-mro', 'id' => $repairReport->getMroRequestApply()->one()->getMro()->mro_id], ['class' => 'btn btn-info']) ?>
                            <?php if ($repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one()->status == 'banned'): ?>
                            <?= Html::a('Unban AO', ['unban-ao', 'id' => $repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one()->ao_id], [
                                'class' => 'btn btn-primary',
                                'data' => [
                                    'confirm' => 'Are you sure you want to unban this AO?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                        <?php else: ?>
                            <?= Html::a('Ban AO', ['ban-ao', 'id' => $repairReport->getMroRequestApply()->one()->getRequest()->one()->getAo()->one()->ao_id], [
                                'class' => 'btn btn-secondary',
                                'data' => [
                                    'confirm' => 'Are you sure you want to ban this AO?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                        <?php endif; ?>
                        <?php if ($repairReport->getMroRequestApply()->one()->getMro()->status == 'banned'): ?>
                            <?= Html::a('Unban MRO', ['unban-mro', 'id' => $repairReport->getMroRequestApply()->one()->getMro()->mro_id], [
                                'class' => 'btn btn-primary',
                                'data' => [
                                    'confirm' => 'Are you sure you want to unban this MRO?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                        <?php else: ?>
                            <?= Html::a('Ban MRO', ['ban-mro', 'id' => $repairReport->getMroRequestApply()->one()->getMro()->mro_id], [
                                'class' => 'btn btn-primary',
                                'data' => [
                                    'confirm' => 'Are you sure you want to ban this MRO?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                        <?php endif; ?>

                            </td>
                            <?php endif; ?>

                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </div>
</main>
