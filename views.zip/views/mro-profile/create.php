<?php

use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use kartik\select2\Select2;
use yii\helpers\Url;

$this->title = 'Create MRO Profile';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        <?php if (Yii::$app->session->hasFlash('message')): ?>
    <!-- Open the Add Airplane modal using JavaScript -->
    <?= Yii::$app->session->getFlash('message') ?>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('error') ?>
    </div>
<?php endif; ?>
<br><br>
    <div class="row">
        <div class="col-md-8">
            <div class="ao-profiles-form">
                        <!-- Flash Messages -->
        <?php if (Yii::$app->session->hasFlash('message')): ?>
    <div class="alert alert-success">
        <?= Yii::$app->session->getFlash('message') ?>
    </div>
<?php endif; ?>
<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('error') ?>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('usernameError')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('usernameError') ?>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('passwordError')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('passwordError') ?>
    </div>
<?php endif; ?>
<?php $form = ActiveForm::begin([
    'enableClientValidation' => true,
]) ?>        
       
        
        <div class="col-md-8">
                        <?= $form->field($model, 'username')->textInput(['maxlength' => false, 'class' => 'form-control form-control-lg'])->label('Username'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'password')->passwordInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'password'])->label('Password'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'confirm_password')->passwordInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'confirm_password'])->label('Confirm Password'. '<span class="text-danger">*</span>') ?>
                        <div id="confirm-password-error" class="error-message" style="display: none;"></div>
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'email')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'email'])->label('Email'. '<span class="text-danger">*</span>') ?>
                        <div class="error-message" id="email-error" style="display: none;"></div>
                    </div>
        

        
                    <div class="col-8">
                        <?= $form->field($model, 'first_name')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg' , 'id' => 'first_name'])->label('First Name'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'last_name')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'last_name'])->label('Last Name'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'contact_number')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'contact_number'])->label('Contact Number'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'profile_photo')->fileInput(['class' => 'form-control form-control-lg', 'accept' => 'image/*'])->label('Profile Photo') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'company_name')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'company_name'])->label('Company Name'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'company_photo')->fileInput(['class' => 'form-control form-control-lg', 'accept' => 'image/*'])->label('Company Photo') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'country_id')->dropDownList(
                            ArrayHelper::map($countries, 'country_id', 'country_name'),
                            [
                                'prompt' => 'Select Country',
                                'id' => 'country-select',
                                'class' => 'form-select form-select-lg'
                            ])->label('Country'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'city_id')->dropDownList([], [
    'prompt' => 'Select City',
    'id' => 'city-select',
    'class' => 'form-select form-select-lg'
])->label('City' . '<span class="text-danger">*</span>') ?>
 
                        <div id="selected-city-value" class="selected-city-value"></div> <!-- Add this line -->
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'address')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'address'])->label('Address' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'zip_code')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'zip_code'])->label('Zip Code' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                    <h4>NAA</h4>

                        <?= $form->field($certificate, 'certificate')->fileInput(['class' => 'form-control form-control-lg','maxlength' => true, 'accept' => '.pdf', 'id' => 'naa'])->label($certificate->getAttributeLabel('certificate') . '<span class="text-danger">*</span>') ?>
                    </div>
                    <h4>Insurance Documents</h4>

            <div class="form-group col-lg-8">
                <?= $form->field($model, 'insurance_document')->fileInput(['class' => 'form-control form-control-lg', 'id' => 'insurance','maxlength' => true, 'accept' => '.pdf'])->label($model->getAttributeLabel('insurance_document') . '<span class="text-danger">*</span>') ?>
            </div>
                    <div class="col-md-8">
                        <?= $form->field($certificate, 'type')->dropDownList(
                            ArrayHelper::map(\app\models\CertificateTypes::find()->all(), 'type', 'type'),
                            ['prompt' => 'Select Type', 'id' => 'certificate-type-dropdown']
                        )->label('NAA' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <?= $form->field($certificate, 'certificate_type_id')->hiddenInput()->label(false) ?>

                    <div class="col-lg-8">
                    <h4>Aircraft certificate</h4>

                    <?= $form->field($mroaircraftcertificate, 'manufacturer')->dropDownList(
                    ArrayHelper::map(\app\models\AircraftModel::find()->select('manufacturer')->distinct()->all(), 'manufacturer', 'manufacturer'),
                    [
                        'prompt' => 'Select Manufacturer',
                        'id' => 'manufacturer-dropdown',
                    ]
                )->label('Manufacturer<span class="text-danger">*</span>') ?>
                                    </div>

                    <div class="col-lg-8">
                    <?= $form->field($mroaircraftcertificate, 'aircraft_model_id')->dropDownList([], [
                    'prompt' => 'Select Aircraft Type',
                    'id' => 'model-dropdown',
                ])->label('Aircraft Type<span class="text-danger">*</span>') ?>                   
                 </div>
                    <div class="col-lg-8">
                    <?= $form->field($mroaircraftcertificate, 'certificate')->fileInput(['class' => 'form-control form-control-lg','id'=>'mroaircraftcertificate-certificate','maxlength' => true, 'accept' => '.pdf'])->label($certificate->getAttributeLabel('certificate') . '<span class="text-danger">*</span>') ?>            
                    </div>



                    <div class="col-lg-8">
                    <h4>Airport</h4>

                    <?= $form->field($mroairport, 'airport_id')->widget(Select2::classname(), [
    'options' => ['placeholder' => 'Select Airport'],
    'pluginOptions' => [
        'allowClear' => true,
        'minimumInputLength' => 2,  // Require at least 2 characters before search
        'ajax' => [
            'url' => \yii\helpers\Url::to(['site/airport-search']),
            'dataType' => 'json',
            'data' => new \yii\web\JsExpression('function(params) { return {q:params.term}; }'),
            'processResults' => new \yii\web\JsExpression('function(data) { return {results: data.results}; }'),
        ],
    ],
])->label($mroairport->getAttributeLabel('airport_name') . '<span class="text-danger">*</span>') ?>

        
        <div class="row">
            <div class="form-group">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-lg-6">
                            <?= Html::submitButton('Create MRO Profile', ['class' => 'btn btn-primary']) ?>
                        </div>
                        <div class="col-lg-6">
                        <?= Html::a('Back to MRO Profile', ['index'], ['class' => 'btn btn-primary']) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php ActiveForm::end() ?>
    </div>
</main>

<?php
$this->registerJs("
    $('#certificate-type-dropdown').change(function() {
        var selectedType = $(this).val();
        $.ajax({
            url: '" . \yii\helpers\Url::to(['certificate-types/get-certificate-type-id']) . "',
            type: 'GET',
            data: {type: selectedType},
            success: function(data) {
                $('#certificates-certificate_type_id').val(data.certificate_type_id); // Set 'certificate_type_id' field value
            },
            error: function() {
                alert('Error fetching certificate type ID.');
            }
        });
    });
");
?>
<?php
$this->registerJs("
    $('#manufacturer-dropdown').change(function() {
        var selectedManufacturer = $(this).val();
        $.ajax({
            url: '" . Url::to(['mro-aircraft-certificates/get-models-by-manufacturer']) . "',
            type: 'GET',
            data: { manufacturer: selectedManufacturer },
            success: function(data) {
                var modelDropdown = $('#model-dropdown');
                modelDropdown.empty(); // Clear previous options
                modelDropdown.append('<option value=\"\">Select Aircraft Model</option>');

                $.each(data, function(index, model) {

                    modelDropdown.append('<option value=\"' + model.id + '\">' + model.name + '</option>');
                });
            },
            error: function(xhr, status, error) {
                console.error('Error fetching models:', error);
                alert('Error fetching models. Please check console for details.');
            }
        });
    });

   
");
?>
<?php
$this->registerJs("
    // Step Navigation
    $('#next-step-1').click(function() {
        var username = $('#mroprofile-username').val();
        var password = $('#password').val();
        var confirmPassword = $('#confirm_password').val();
        var email = $('#email').val();

        var first_name = $('#first_name').val();
        var last_name = $('#last_name').val();
        var contact_number = $('#contact_number').val();
        var company_name = $('#company_name').val();

        var isValid = true;

        // Validate Step 1
        if (username === '' || password === '' || confirmPassword === '' || email === '') {
            isValid = false;
            alert('Please fill in all required fields.');
        } else if (password !== confirmPassword) {
            isValid = false;
            alert('Passwords do not match.');
        }

        if (isValid) {
            $('#step-1').hide();
            $('#step-2').show();
        }
    });

    $('#prev-step-2').click(function() {
        $('#step-2').hide();
        $('#step-1').show();
    });

    $('#next-step-2').click(function() {
    var countryId = $('#country-select').val();
    var cityId = $('#city-select').val();
    var address = $('#address').val();
        var zip = $('#zip_code').val();

    var isValid = true;



    // Validate Step 2
    if (countryId === '' || cityId === '' || address === '' || zip ==='' || first_name ==='' || last_name ===''|| contact_number ===''|| company_name ==='') {
        isValid = false;
        alert('Please fill in all required fields.');
    }

    if (isValid) {
        $('#step-2').hide();
        $('#step-3').show();
    }
    });

    $('#prev-step-3').click(function() {
        $('#step-3').hide();
        $('#step-2').show();
    });

    // Show Terms
    $('#show-terms-btn').click(function() {
        $('.terms-content').toggle();
    });
  // Validate Step 3 fields before submission
    $('#submit-btn').click(function(e) {
        var naa = $('#naa').val();
        var insurance = $('#insurance').val();
        var manufacturer = $('#manufacturer-dropdown').val();
        var model = $('#model-dropdown').val();
        var certificateType = $('#certificate-type-dropdown').val();
        var aircraftCertificate = $('#mroaircraftcertificate-certificate').val(); // Aircraft certificate field ID
        var isValid = true;

        // Validate NAA, insurance, manufacturer, model, certificate type, and aircraft certificate
        if (naa === '') {
            isValid = false;
            alert('Please upload the NAA certificate.');
        } else if (insurance === '') {
            isValid = false;
            alert('Please upload the insurance document.');
        } else if (manufacturer === '') {
            isValid = false;
            alert('Please select a manufacturer.');
        } else if (model === '') {
            isValid = false;
            alert('Please select an aircraft model.');
        } else if (certificateType === '') {
            isValid = false;
            alert('Please select a certificate type.');
        } else if (aircraftCertificate === '') {
            isValid = false;
            alert('Please upload the aircraft certificate.');
        }

        // Prevent form submission if any field is invalid
        if (!isValid) {
            e.preventDefault(); // Prevent the form from submitting
        }
    });


    // Enable Submit Button when Terms are Accepted
    $('#terms-check').change(function() {
        $('#submit-btn').prop('disabled', !this.checked);
    });
");
?>
<?php
$urlLoadCities = \yii\helpers\Url::to(['/mro-profile/load-cities']);

$script = <<<JS
// Handle country change -> load cities dynamically via AJAX
$('#country-select').on('change', function () {
    var countryId = $(this).val();
    var citySelect = $('#city-select');

    // Reset city dropdown
    citySelect.html('<option value="">Loading...</option>');

    if (countryId) {
        $.ajax({
            url: '{$urlLoadCities}', // ✅ Correctly inject PHP variable
            type: 'GET',
            data: { countryId: countryId },
            success: function (data) {
                citySelect.empty();
                citySelect.append('<option value="">Select City</option>');
                $.each(data.cities, function (index, city) {
                    citySelect.append('<option value="' + city.id + '">' + city.text + '</option>');
                });
            },
            error: function () {
                citySelect.html('<option value="">Error loading cities</option>');
            }
        });

    } else {
        citySelect.html('<option value="">Select City</option>');
    }
});
JS;
$this->registerJs($script);
?>

