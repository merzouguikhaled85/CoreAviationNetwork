<?php

use yii\helpers\Html;

$this->title = 'MRO Profile: ' . $mroProfile->username;
$this->params['breadcrumbs'][] = ['label' => 'MRO Profiles', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
    .stars {
        font-size: 36px; /* Adjust the size of stars */
    }

    .stars span {
        color: #f8d150; /* Golden color */
    }

</style>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        
        <div class="row">
            <!-- Profile Information Column -->
            <div class="col-md-6">
                <h3>Profile Information</h3>
                <ul class="list-group">
<li class="list-group-item d-flex justify-content-between align-items-center">
    Profile Photo: <?= Html::img('@web/' . $mroProfile->profile_photo, [
        'class' => 'img-fluid rounded-circle',
        'alt' => 'Profile Photo',
        'style' => 'width:100px; height:100px; object-fit:cover;'
    ]) ?>
</li>

                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Username: <?= Html::encode($mroProfile->username) ?>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Email Address: <?= Html::encode($mroProfile->email) ?>
                    </li>

                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Contact Name: <?= Html::encode($mroProfile->first_name) ?>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Contact Lastname: <?= Html::encode($mroProfile->last_name) ?>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Contact Number: <?= Html::encode($mroProfile->contact_number) ?>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                    Address: <?= ucfirst(Html::encode($mroProfile->address)) ?>
                    </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                    Post Code/Zip Code: <?= ucfirst(Html::encode($mroProfile->zip_code)) ?>
                    </li>
                </ul>
            </div>

            <!-- Company Information Column -->
            <div class="col-md-6">
                <h3>Company Information</h3>
                <ul class="list-group">
<li class="list-group-item d-flex justify-content-between align-items-center">
    Company Image: <?= Html::img('@web/' . $mroProfile->company_photo, [
        'class' => 'img-fluid',
        'alt' => 'Company Photo',
        'style' => 'width: 120px; height: auto; object-fit: contain;'
    ]) ?>
</li>

                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Company Name: <?= Html::encode($mroProfile->company_name) ?>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Website: <?= Html::encode($mroProfile->website) ?>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Social Media Link: <?= Html::encode($mroProfile->youtube_video) ?>
                    </li>
                   <li class="list-group-item d-flex justify-content-between align-items-center">
    Main References: 
    <?php
        if (!empty($mroProfile->main_references)) {
            $references = explode(',', $mroProfile->main_references);
            foreach ($references as $reference) {
                echo Html::a(basename($reference), '@web/' . $reference, ['download' => true]) . '<br>';
            }
        } else {
            echo 'No references uploaded.';
        }
    ?>
</li>


                </ul>
            </div>
        </div>

        <div class="row">
                        
            <!-- Project Information Column -->
            <div class="col-12">
            </br>
                <h3>Maintenance Operations Count and Rating</h3>
                <ul class="list-group">
                <li class="list-group-item d-flex  align-items-center">
                Number of project completed:<strong> <?= Html::encode($projectRealisedCount) ?></strong>
                    </li>
                    <li class="list-group-item d-flex align-items-center">
                        Average Rating:     <strong><?= Html::encode($averageRating) ?></strong>  <?= displayStars($averageRating) ?> 

                    </li>
                 
                </ul>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                    <?= Html::a('Back to Requests', Yii::$app->request->referrer, [ 'class' => 'btn btn-secondary']) ?>
                 

            </div>
        </div>
    </div>
</main>
<?php
// Function to display stars based on rating
function displayStars($rating)
{
    $stars = '';
    for ($i = 1; $i <= $rating; $i++) {
        $stars .= '<span>&#x2605;</span>'; // Full star
    }
    for ($i = $rating + 1; $i <= 5; $i++) {
        $stars .= '<span>&#x2606;</span>'; // Empty star
    }
    return '<div class="stars">' . $stars . '</div>';
}
?>

