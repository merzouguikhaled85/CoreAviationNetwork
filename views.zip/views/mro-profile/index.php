<?php

use yii\helpers\Html;
use yii\widgets\LinkPager;


// Define custom CSS styles for pagination links
$this->registerCss("
    .table {
        width: 100%; /* Makes the table responsive */
    }

    .table th, .table td {
        font-size: 14px; /* Adjust the font size as needed */

        white-space: nowrap; /* Prevents long content from wrapping */
        overflow: auto ; /* Ensures content is truncated */
        max-width: 200px; /* Adjust this value as needed */
    }
    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    
    .pagination li {
        margin: 0 5px;
    }
    
    .pagination .active a {
        background-color: #007bff;
        color: #fff;
    }
    
    .pagination li a {
        color: #007bff;
        border: 1px solid #007bff;
        padding: 6px 12px;
        text-decoration: none;
        border-radius: 3px;
    }
    
    .pagination li a:hover {
        background-color: #f2f2f2;
    }
");
$this->title = 'MRO Profiles';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        
        <?php if (Yii::$app->session->hasFlash('message')): ?>
            <div class="alert alert-success">
                <?= Yii::$app->session->getFlash('message') ?>
            </div>
        <?php endif; ?>

        <div class="row" style="margin-bottom: 20px;">
        <div class="col-auto ml-auto" style="float: right; display: inline-block;">

            <?= Html::a('Add MRO Profile', ['create'],['class' => 'btn btn-outline-primary  btn-lg rounded-pill']) ?>
            </div>
        </div>
        
        <div class="row">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Profile Photo</th>
                       
                        <th>Username</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Contact Number</th>
                        <th>Insurance Document</th>

                        <th>Company Name</th>
                        <th>Company Photo</th>
                        <th>Email Verified</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($mroProfiles as $mroProfile): ?>
                        <tr>
                            <td><?= $mroProfile->mro_id ?></td>
                            <td><?= Html::img('@web/' .$mroProfile->profile_photo, ['alt' => 'Profile Photo', 'style' => 'width:100px;']) ?></td>

                                                   
                            <td><?= Html::encode($mroProfile->username) ?></td>
                            <td><?= Html::encode($mroProfile->email) ?></td>
                            <td><?= ucfirst(Html::encode($mroProfile->status)) ?></td>
                            <td><?= Html::encode($mroProfile->first_name) ?></td>
                            <td><?= Html::encode($mroProfile->last_name) ?></td>
                            <td><?= Html::encode($mroProfile->contact_number) ?></td>
                            <td>     
    <?php if (!empty($mroProfile->insurance_document)): ?>
        <?= Html::a('Download Insurance', Yii::getAlias('@web/')  . $mroProfile->insurance_document, ['target' => '_blank']) ?>
    <?php endif; ?>
</td>


                            <td><?= Html::encode($mroProfile->company_name) ?></td>
                            <td><?= Html::img('@web/' .$mroProfile->company_photo, ['alt' => 'Company Photo', 'style' => 'width:100px;']) ?></td>
                            
                            <td><?= $mroProfile->email_verified ? 'Yes' : 'No' ?></td>
                            <td>
                                <?= Html::a('View', ['view', 'id' => $mroProfile->mro_id], ['class' => 'btn btn-info']) ?>

                                <?= Html::a('Modify', ['update', 'id' => $mroProfile->mro_id], ['class' => 'btn btn-primary']) ?>
                                <?= Html::a('Remove', ['delete', 'id' => $mroProfile->mro_id], [
                                    'class' => 'btn btn-secondary',
                                    'data' => [
                                        'confirm' => 'Are you sure you want to delete this item?',
                                        'method' => 'post',
                                    ],
                                ]) ?>
                                <?= Html::a('Toggle Status', ['toggle-status', 'id' => $mroProfile->mro_id], [
                                    'class' => 'btn btn-primary',
                                    'data' => [
                                        'confirm' => 'Are you sure you want to change the status of this profile?',
                                        'method' => 'post',
                                    ],
                                ]) ?>
                                <?= Html::a('Reset Password', ['send-password-reset', 'id' => $mroProfile->mro_id], [
                                    'class' => 'btn',
                                    'style' => 'background-color: violet; color: white;',
                                    'data' => [
                                        'confirm' => 'Are you sure you want to send a password reset email to this user?',
                                        'method' => 'post',
                                    ],
                                ]) ?>

                                
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="pagination-container">
            <?= LinkPager::widget(['pagination' => $pagination]) ?>
        </div>
    </div>
</main>
