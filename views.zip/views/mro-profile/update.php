<?php

use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use yii\helpers\Html;

$this->title = 'Update MRO Profile';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        <?php if (Yii::$app->session->hasFlash('message')): ?>
    <!-- Open the Add Airplane modal using JavaScript -->
    <?= Yii::$app->session->getFlash('message') ?>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('error') ?>
    </div>
<?php endif; ?>
<?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>
        


        
        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                <?= $form->field($mroProfile, 'username')->textInput(['class' => 'form-control form-control-lg'])->label('Username' . '<span class="text-danger">*</span>')?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($mroProfile, 'email')->textInput(['class' => 'form-control form-control-lg'])->label('Email' . '<span class="text-danger">*</span>')?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($mroProfile, 'first_name')->textInput(['class' => 'form-control form-control-lg']) ?>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($mroProfile, 'last_name')->textInput(['class' => 'form-control form-control-lg']) ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
    <?= $form->field($mroProfile, 'country_id')->dropDownList(
        ArrayHelper::map($countries, 'country_id', 'country_name'),
        [
            'prompt' => 'Select Country',
            'id' => 'country-select',
            'class' => 'form-select form-select-lg',
        ]
    )->label('Country' . '<span class="text-danger">*</span>') ?>
</div>

<div class="col-md-8">
    <?= $form->field($mroProfile, 'city_id')->dropDownList(
        ArrayHelper::map($cities, 'city_id', 'city_name'),
        [
            'prompt' => 'Select City',
            'id' => 'city-select',
            'class' => 'form-select form-select-lg',
        ]
    )->label('City' . '<span class="text-danger">*</span>') ?>
</div>

<div class="col-8">
                        <?= $form->field($mroProfile, 'address')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'address'])->label('Address' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-8">
                        <?= $form->field($mroProfile, 'zip_code')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'zip_code'])->label('Zip Code' . '<span class="text-danger">*</span>') ?>
                    </div>
          <!-- Profile Photo Field -->
  <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($mroProfile, 'profile_photo')->fileInput() ?>
                    <?php if ($mroProfile->profile_photo): ?>
                        <p>Current file: <?= Html::a('View Profile Photo', ['/' . $mroProfile->profile_photo], ['target' => '_blank']) ?></p>
                        <?= Html::hiddenInput('profile_photo_existing', $mroProfile->profile_photo) ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($mroProfile, 'contact_number')->textInput(['class' => 'form-control form-control-lg']) ?>
                </div>
            </div>
        </div>   
        
        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($mroProfile, 'company_name')->textInput(['class' => 'form-control form-control-lg']) ?>
                </div>
            </div>
        </div>
        

                    <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($mroProfile, 'website')->textInput(['class' => 'form-control form-control-lg']) ?>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($mroProfile, 'youtube_video')->textInput(['class' => 'form-control form-control-lg']) ?>
                </div>
            </div>
        </div>
        
        <!-- Company Photo Field -->
        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($mroProfile, 'company_photo')->fileInput() ?>
                    <?php if ($mroProfile->company_photo): ?>
                        <p>Current file: <?= Html::a('View Company Photo', ['/' . $mroProfile->company_photo], ['target' => '_blank']) ?></p>
                        <!-- Hidden input to preserve existing file -->
                        <?= Html::hiddenInput('company_photo_existing', $mroProfile->company_photo) ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
  <!-- Main References Field -->
  <div class="row">
    <div class="form-group">
        <div class="col-lg-6">
            <?= $form->field($mroProfile, 'main_references[]')->fileInput(['multiple' => true]) ?>
            
            <!-- Display existing main references -->
            <?php if (!empty($mroProfile->main_references)): ?>
                <div>
                    <h5>Existing Main References:</h5>
                    <ul>
                        <?php foreach ($mroProfile->main_references as $reference): ?>
                            <li>
                                <a href="<?= Yii::getAlias('@web/uploads/' . $reference) ?>" target="_blank">
                                    <?= basename($reference) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

        
        <!-- Submit button -->
        <div class="row">
            <div class="form-group">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-lg-6">
                            <?= Html::submitButton('Update MRO Profile', ['class' => 'btn btn-primary']) ?>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
        
        <?php ActiveForm::end() ?>
    </div>
</main>
<?php
$cityUrl = \yii\helpers\Url::to(['mro-profile/cities-by-country']); // Adjust route if needed
$selectedCityId = $mroProfile->city_id;
$script = <<<JS
function loadCities(countryId, selectedCityId = null) {
    var citySelect = $('#city-select');
    citySelect.html('<option value="">Loading...</option>');

    if (!countryId) {
        citySelect.html('<option value="">Select City</option>');
        return;
    }

    $.ajax({
        url: '{$cityUrl}',
        data: { country_id: countryId },
        success: function(data) {
            citySelect.empty();
            citySelect.append('<option value="">Select City</option>');
            $.each(data, function(index, city) {
                var selected = (city.id == selectedCityId) ? 'selected' : '';
                citySelect.append('<option value="' + city.id + '" ' + selected + '>' + city.name + '</option>');
            });
        },
        error: function() {
            citySelect.html('<option value="">Error loading cities</option>');
        }
    });
}

// Load cities when country changes
$('#country-select').on('change', function() {
    loadCities($(this).val());
});

// Auto-load saved city on page load
if ($('#country-select').val()) {
    loadCities($('#country-select').val(), '{$selectedCityId}');
}
JS;
$this->registerJs($script);
?>
