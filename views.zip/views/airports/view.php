<?php
use yii\helpers\Html;

$this->title = $airport->airport_name;
$this->params['breadcrumbs'][] = ['label' => 'Airports', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <div class="row">
            <div class="col-lg-12">
                <table class="table table-striped">
                    <tr>
                        <th>ID</th>
                        <td><?= $airport->airport_id ?></td>
                    </tr>
                    <tr>
                        <th>Airport Name</th>
                        <td><?= Html::encode($airport->airport_name) ?></td>
                    </tr>
                    <tr>
                        <th>City</th>
                        <td><?= $airport->city ? Html::encode($airport->city->city_name) : 'N/A' ?></td>
                    </tr>
                    <tr>
                        <th>Country</th>
                        <td><?= Html::encode($airport->country_name ?? 'N/A') ?></td>
                    </tr>
                    <tr>
                        <th>ICAO</th>
                        <td><?= Html::encode($airport->icao ?? 'N/A') ?></td>
                    </tr>
                </table>

                <div class="row">
            <?= Html::a('Back to airports ', ['index'], ['class' => 'btn btn-primary']) ?>
            </div>
            </div>
        </div>
    </div>
</main>
