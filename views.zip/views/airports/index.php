<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;

// Register custom CSS styles for pagination links and search input
$this->registerCss("
    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    
    .pagination li {
        margin: 0 5px;
    }
    
    .pagination .active a {
        background-color: #007bff;
        color: #fff;
    }
    
    .pagination li a {
        color: #007bff;
        border: 1px solid #007bff;
        padding: 6px 12px;
        text-decoration: none;
        border-radius: 3px;
    }
    
    .pagination li a:hover {
        background-color: #f2f2f2;
    }
    
    .search-container {
        display: flex;
        border-radius: 20px;
        overflow: hidden;
    }
    
    .search-input {
        flex: 1;
        border-top-left-radius: 20px;
        border-bottom-left-radius: 20px;
    }
    
    .search-button {
        border-top-right-radius: 20px;
        border-bottom-right-radius: 20px;
    }
    .search-input-lg {
        width: 100%; /* Set width to 100% to make it full width */
        height: 50px; /* Adjust height as needed */
        font-size: 18px; /* Increase font size for larger input */
    }
");

$this->title = 'Airports';
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">Airports</h1>
        
        <?php if (Yii::$app->session->hasFlash('message')): ?>
            <div class="alert alert-success">
                <?= Yii::$app->session->getFlash('message') ?>
            </div>
        <?php endif; ?>

        <div class="row" style="margin-bottom: 20px;">
            <div class="col-lg-12">
                <?= Html::beginForm(['airports/index'], 'get', ['class' => 'form-inline']) ?>
                    <?= Html::textInput('search', Yii::$app->request->get('search'), ['class' => 'form-control search-input search-input-lg', 'placeholder' => 'Search by Airport Name or ICAO']) ?>
                    <div class="input-group-append">
                        <?= Html::submitButton('Search', ['class' => 'btn btn-primary btn-lg search-button']) ?>
                    </div>
                <?= Html::endForm() ?>
            </div>
            <div class="col-auto ml-auto" style="float: right; display: inline-block;">
                </br></br></br>
                <?= Html::a('Add Airport', ['create'], ['class' => 'btn btn-outline-primary btn-lg rounded-pill']) ?>
            </div>
        </div>
        
        <div class="row">
        <table class="table table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Airport Name</th>
            <th>City</th>
            <th>Country</th>
            <th>ICAO</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($airports as $airport): ?>
            <tr>
                <td><?= $airport->airport_id ?></td>
                <td><?= $airport->airport_name ?></td>
                <td><?= $airport->city ? $airport->city->city_name : 'N/A' ?></td>
                <td><?= $airport->country ? $airport->country->country_name : 'N/A' ?></td>
                <td><?= $airport->icao ?? 'N/A' ?></td>
                <td>
                    <?= Html::a('View', ['view', 'id' => $airport->airport_id], ['class' => 'btn btn-info']) ?>
                    <?= Html::a('Modify', ['update', 'id' => $airport->airport_id], ['class' => 'btn btn-primary']) ?>
                    <?= Html::a('Remove', ['delete', 'id' => $airport->airport_id], [
                        'class' => 'btn btn-secondary',
                        'data' => [
                            'confirm' => 'Are you sure you want to delete this item?',
                            'method' => 'post',
                        ],
                    ]) ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

        </div>
        <div class="pagination-container">
            <?= LinkPager::widget(['pagination' => $pagination]) ?>
        </div>
    </div>
</main>
