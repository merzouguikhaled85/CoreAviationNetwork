<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;

$this->title = 'Create Airport';

// Convert cities to a JavaScript-friendly format
$citiesByCountry = [];
foreach ($cities as $city) {
    $citiesByCountry[$city->country_id][] = ['id' => $city->city_id, 'name' => $city->city_name];
}

// JSON encode the cities array for use in JavaScript
$citiesByCountryJson = json_encode($citiesByCountry);
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">Create Airport</h1>
        <?php $form = ActiveForm::begin(); ?>

        <div class="row">
            <div class="form-group col-lg-6">
                <?= $form->field($airport, 'airport_name')->textInput(['maxlength' => true])->label($airport->getAttributeLabel('airport_name') . '<span class="text-danger">*</span>') ?>
            </div>
            <div class="form-group col-lg-6">
                <?= $form->field($airport, 'icao')->textInput(['maxlength' => true])->label($airport->getAttributeLabel('icao') . '<span class="text-danger">*</span>') ?>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-lg-6">
                <?= $form->field($airport, 'country_id')->dropDownList(
                    ArrayHelper::map($countries, 'country_id', 'country_name'),
                    [
                        'prompt' => 'Select Country',
                        'id' => 'country-select'
                    ]
                    )->label($airport->getAttributeLabel('country_name') . '<span class="text-danger">*</span>') ?>
                <?= $form->field($airport, 'country_name')->hiddenInput()->label(false) ?>
            </div>
            <div class="form-group col-lg-6">
                <?= $form->field($airport, 'city_id')->dropDownList(
                    [],
                    [
                        'prompt' => 'Select City',
                        'id' => 'city-select'
                    ]
                    )->label($airport->getAttributeLabel('city_name') . '<span class="text-danger">*</span>') ?>
                <?= $form->field($airport, 'city_name')->hiddenInput()->label(false) ?>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-lg-8">
                <div class="row">
                    <div class="col-lg-6">
                        <?= Html::submitButton('Create Airport', ['class' => 'btn btn-primary']) ?>
                    </div>
                    <div class="col-lg-2">
                        <?= Html::a('Back to airports', ['index'], ['class' => 'btn btn-primary']) ?>
                    </div>
                </div>
            </div>
        </div>
        
        <?php ActiveForm::end(); ?>
    </div>
</main>

<?php
// Register JavaScript to handle the city dropdown update
$script = <<<JS
    var citiesByCountry = $citiesByCountryJson;

    document.getElementById('country-select').addEventListener('change', function() {
        var countryId = this.value;
        var countryName = this.options[this.selectedIndex].text; // Get selected country name
        var citySelect = document.getElementById('city-select');
        citySelect.innerHTML = '<option value="">Select City</option>'; // Reset city options

        if (citiesByCountry[countryId]) {
            citiesByCountry[countryId].forEach(function(city) {
                var option = document.createElement('option');
                option.value = city.id;
                option.textContent = city.name;
                citySelect.appendChild(option);
            });
        }

        // Set the selected country name to the hidden field
        document.getElementById('airport-country_name').value = countryName;
    });

    // Update city_name when city dropdown changes
    document.getElementById('city-select').addEventListener('change', function() {
        var cityName = this.options[this.selectedIndex].text; // Get selected city name
        document.getElementById('airport-city_name').value = cityName;
    });

    // Populate country_name and city_name if editing an existing airport
    var initialCountryId = document.getElementById('airport-country_id').value;
    var initialCityId = document.getElementById('airport-city_id').value;
    var initialCountryName = document.querySelector('#country-select option[value="' + initialCountryId + '"]').text;
    var initialCityName = document.querySelector('#city-select option[value="' + initialCityId + '"]').text;
    document.getElementById('airport-country_name').value = initialCountryName;
    document.getElementById('airport-city_name').value = initialCityName;
JS;

$this->registerJs($script);
?>
