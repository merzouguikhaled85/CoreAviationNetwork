<?php

/** @var yii\web\View $this */
/** @var string $content */

use app\assets\AppAsset;
use app\widgets\Alert;
use yii\bootstrap5\Breadcrumbs;
use yii\bootstrap5\Html;
use yii\bootstrap5\Nav;
use yii\bootstrap5\NavBar;
use yii\bootstrap5\BootstrapAsset;
use yii\bootstrap5\BootstrapPluginAsset;


BootstrapAsset::register($this);
BootstrapPluginAsset::register($this);

AppAsset::register($this);

$this->registerCsrfMetaTags();
$this->registerMetaTag(['charset' => Yii::$app->charset], 'charset');
$this->registerMetaTag(['name' => 'viewport', 'content' => 'width=device-width, initial-scale=1, shrink-to-fit=no']);
$this->registerMetaTag(['name' => 'description', 'content' => $this->params['meta_description'] ?? '']);
$this->registerMetaTag(['name' => 'keywords', 'content' => $this->params['meta_keywords'] ?? '']);
$this->registerLinkTag(['rel' => 'icon', 'type' => 'image/x-icon', 'href' => Yii::getAlias('@web/favicon.ico')]);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600|Open+Sans:400,600,700" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.bundle.min.js"></script>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
<style>
    #main{
        padding: 25px;
    }
</style>
</head>
<body class="d-flex flex-column h-100">
<?php $this->beginBody() ?>

<header id="header">
    <?php
    /*NavBar::begin([
        'brandLabel' => Yii::$app->name,
        'brandUrl' => Yii::$app->homeUrl,
        'options' => ['class' => 'navbar-expand-md navbar-dark bg-dark fixed-top']
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav'],
        'items' => [
            ['label' => 'Home', 'url' => ['/site/index']],
            ['label' => 'About', 'url' => ['/site/about']],
            ['label' => 'Contact', 'url' => ['/site/contact']],
            Yii::$app->user->isGuest
                ? ['label' => 'Login', 'url' => ['/site/login']]
                : '<li class="nav-item">'
                    . Html::beginForm(['/site/logout'])
                    . Html::submitButton(
                        'Logout (' . Yii::$app->user->identity->username . ')',
                        ['class' => 'nav-link btn btn-link logout']
                    )
                    . Html::endForm()
                    . '</li>'
        ]
    ]);
    NavBar::end();*/
    ?>
</header>

<main id="main" class="flex-shrink-0" role="main">
    <div class="">
        <!--
        <?php if (!empty($this->params['breadcrumbs'])): ?>
            <?= Breadcrumbs::widget(['links' => $this->params['breadcrumbs']]) ?>
        <?php endif ?>-->
        <?= Alert::widget() ?>
        <?= $this->render('header') ?>
        <?= $content ?>
        <?= $this->render('footer') ?>

    </div>
</main>
<!--This is a comment. Comments are not displayed in the browser

<footer id="footer" class="mt-auto py-3 bg-light">
    <div class="container">
        <div class="row text-muted">
            <div class="col-md-6 text-center text-md-start">&copy; My Company <?= date('Y') ?></div>
            <div class="col-md-6 text-center text-md-end"><?= Yii::powered() ?></div>
        </div>
    </div>
</footer>
-->

<?php
/*
// Fetch user_type from session
$user_type = Yii::$app->session->get('user_type');
$isLoggedin = Yii::$app->session->get('isLoggedIn');

// Register JavaScript with user_type check
$this->registerJs("
    const user_type = " . json_encode($user_type) . ";
    const isLoggedin = " . json_encode($isLoggedin) . ";

    // Check if user_type is null or empty
    if (!user_type && user_type) {
        // If user_type is null or empty, immediately log out
        fetch('" . \yii\helpers\Url::to(['site/logout']) . "', {
            method: 'POST',
            headers: {
                'X-CSRF-Token': '" . Yii::$app->request->csrfToken . "'
            }
        }).then(response => {
            if (response.ok) {
                window.location.href = '" . \yii\helpers\Url::to(['site/landing']) . "';
            }
        });
    } else {
        // Start idle timeout logic only if user_type is set
        let idleTime = 0;
        const idleInterval = setInterval(timerIncrement, 60000); // 1 minute

        function timerIncrement() {
            idleTime++;
            if (idleTime >= 20) { // 20 minutes of inactivity
                fetch('" . \yii\helpers\Url::to(['site/logout']) . "', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-Token': '" . Yii::$app->request->csrfToken . "'
                    }
                }).then(response => {
                    if (response.ok) {
                        window.location.href = '" . \yii\helpers\Url::to(['site/landing']) . "';
                    }
                });
            }
        }

        // Reset idle timer on user activity
        document.onmousemove = document.onkeypress = function() {
            idleTime = 0;
        };
    }
");
*/
?>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
