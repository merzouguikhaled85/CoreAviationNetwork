<?php

use app\models\User;
use yii\helpers\Url;
use yii\helpers\Html;
use yii\helpers\VarDumper;

?>
<style>
        .alert {
            position: relative;
            z-index: -1;
        }
        .background-form {
            position: relative;  /* or absolute/fixed if you need */
            z-index: -1;
        }

        .progress-bar-container {
        z-index: -1;
        background-color: #c4cfe1; /* Background color for the container */
        border-radius: 20px; /* Rounded corners */
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        overflow-x: auto; /* Enable horizontal scrolling */
        white-space: nowrap; /* Prevent wrapping */
        position: relative; /* Ensure positioning context for arrows */
        padding: 10px; /* Add padding to give space inside the container */
    }

    .progress-bar-step {
        flex: 1;
        text-align: center;
        position: relative;
        color: black; /* Color for steps not realized */
        margin-left: 20px; /* Adjust the spacing between steps */
        padding: 0 10px; /* Add padding to create space for arrows */
        font-weight: 600;
        z-index: 1; /* Ensure steps are above arrows */

    }

    .progress-bar-step.step-active {
        color: #007bff; /* Color for step in progress */
    }

    .progress-bar-step.step-realized {
        color: #28a745; /* Color for realized step */
    }

    .progress-bar-step:before {
        content: '';
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        left: calc(100% + 10px); /* Adjust the position to the right of the step */
        width: 0;
        height: 0;
        border-top: 10px solid transparent;
        border-bottom: 10px solid transparent;
        border-left: 10px solid black; /* Default color for arrows */
        z-index: -1;
    }

    .progress-bar-step:last-child:before {
        display: none; /* Hide arrow after the last step */
    }

    .progress-bar-step.step-active:before {
        border-left-color: #007bff; /* Arrow color for active step */
    }

    .progress-bar-step.step-realized:before {
        border-left-color: #28a745; /* Arrow color for realized step */
    }
    /* Style for notification dropdown */
    #notification-dropdown {
        max-height: 400px; /* Maximum height of the dropdown */
        overflow-y: auto; /* Enable vertical scrolling */
        max-width: 600px; /* Maximum height of the dropdown */
        width: 400px; /* Maximum height of the dropdown */

    }

    /* Style for individual notification items */
    .dropdown-item {
        padding: 10px;  /*Padding for each notification item */
        border-bottom: 1px solid #ddd; /* Bottom border between items */
    }

    /* Style for read notifications */
    .read-notification {
        opacity: .1; /* Reduce opacity for read notifications */
    }

    /* Style for notification actions (buttons) */
    .notification-actions {
        margin-top: 5px; /* Margin above action buttons */
    }

    .notification-actions button {
        margin-right: 5px; /* Margin between action buttons */
    }
    /* Remove selected and hover effect for notification items */
.dropdown-item {
    cursor: default; /* Prevent pointer cursor */
    user-select: none; /* Disable text selection */
    -webkit-user-select: none; /* For Safari */
    -moz-user-select: none; /* For Firefox */
    -ms-user-select: none; /* For IE/Edge */

    /* Remove hover and focus styles */
    background-color: transparent !important;
    color: inherit !important;
    border: none !important;
    outline: none !important;
}

.dropdown-item:hover,
.dropdown-item:focus {
    background-color: transparent !important;
    color: inherit !important;
    border: none !important;
    outline: none !important;
}
.dash-nav header {

    margin-right: -19px;
   
}
.dash-nav-list {
    display: flex;
    flex-direction: column;
    height: 85vh; /* Full height */
}

.logout-container {
    margin-top: auto; /* Pushes the logout button to the bottom */
}
.dash-nav-dropdown-menu {
    display: block; /* Show dropdown by default */
    /* Add additional styles if necessary */
}

</style>

    <div class="dash">
        <div class="dash-nav dash-nav-dark">
        <header>
    <a href="#!" class="menu-toggle">
        <i class="fas fa-bars"></i>
    </a>
    <a href="<?= Url::to(['dashboard/home']) ?>" class="spur-logo">
        <img src="<?= Url::to('@web/img/logoGmro.png') ?>" alt="GlobalMROs Logo" style="height: 40px;"> 
        <span style="font-size: 18px;">GlobalMROs</span>
    </a>
</header>
            <nav class="dash-nav-list">
           
                <?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'admin'): ?>
                <a href="<?= Url::to(['airports/index']) ?>" class="dash-nav-item">
                <i class="fas fa-plane"></i> Airports </a>


                <div class="dash-nav-dropdown ">
                    <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                        <i class="fas fa-plane"></i> Aircrafts </a>
                        <div class="dash-nav-dropdown-menu">
                            <a href="<?= Url::to(['aircrafts/index']) ?>" class="dash-nav-dropdown-item">Aircrafts</a>
                            <a href="<?= Url::to(['aircraft-model/index']) ?>" class="dash-nav-dropdown-item">Aircraft Models</a>
                            <a href="<?= Url::to(['certificates/models-without-certificates']) ?>" class="dash-nav-dropdown-item">Aircrafts with no </br>certified MRO</a>

                        </div>
                </div>

                <div class="dash-nav-dropdown ">
                    <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                        <i class="fas fa-certificate"></i> certificates </a>
                        <div class="dash-nav-dropdown-menu">
                            <a href="<?= Url::to(['certificates/index']) ?>" class="dash-nav-dropdown-item">Certificates</a>
                            <a href="<?=Url::to(['certificate-types/index']) ?>" class="dash-nav-dropdown-item">Certificate Types</a>
                        </div>
                </div>

                <a href="<?= Url::to(['admin-disputes/index']) ?>" class="dash-nav-item">
                    <i class="fas fa-balance-scale"></i> Disputes
                    </a>

                    <a href="<?= Url::to(['awaiting-request-response/index']) ?>" class="dash-nav-item">
                    <i class="fas fa-list"></i> Requests
                    </a>



                <div class="dash-nav-dropdown ">
                    <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                        <i class="fas fa-file"></i> Profiles </a>
                        <div class="dash-nav-dropdown-menu">
                            <a href="<?= Url::to(['mro-profile/index']) ?>" class="dash-nav-dropdown-item">MROs</a>
                            <a href="<?= Url::to(['ao-profile/index']) ?>" class="dash-nav-dropdown-item">AO</a>
                        </div>
                </div>
                <div class="dash-nav-dropdown ">
                    <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                        <i class="fas fa-file"></i> Settings </a>
                        <div class="dash-nav-dropdown-menu">
                            <a href="<?= Url::to(['country/index']) ?>" class="dash-nav-dropdown-item">Countries</a>
                            <a href="<?= Url::to(['city/index']) ?>" class="dash-nav-dropdown-item">Cities</a>
                            <a href="<?= Url::to(['advert/index']) ?>" class="dash-nav-dropdown-item">Adverts</a>
                            <a href="<?= Url::to(['currency/index']) ?>" class="dash-nav-dropdown-item">Currencies</a>


                        </div>
                </div>
                <?php endif; ?>
                <?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'ao'): ?>

                    <div class="dash-nav-dropdown ">
                    <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                        <i class="fas fa-plane"></i> Requests </a>
                        <div class="dash-nav-dropdown-menu">
                            <a href="<?= Url::to(['requests/new-requests']) ?>" class="dash-nav-dropdown-item">New Requests</a>
                            <a href="<?= Url::to(['requests/open-requests']) ?>" class="dash-nav-dropdown-item">Open Requests</a>
                            <a href="<?= Url::to(['requests/closed-requests']) ?>" class="dash-nav-dropdown-item">Closed Requests</a>
                            <a href="<?= Url::to(['ao-appointments/index']) ?>" class="dash-nav-dropdown-item">My Appointments</a>
                            <a href="<?= Url::to(['ao-mro-dispute/index']) ?>" class="dash-nav-dropdown-item">Disputes</a>

                        </div>
                    </div>

                    <div class="dash-nav-dropdown ">
                    <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                        <i class="fas fa-user"></i> My Profile </a>
                        <div class="dash-nav-dropdown-menu">
                            <a href="<?= Url::to(['ao-profile/update', 'id' =>  Yii::$app->user->identity->getId()]) ?>" class="dash-nav-dropdown-item">Update Profile</a>
                            <a href="<?= Url::to(['ao-profile/reset-password', 'id' => Yii::$app->user->identity->getId()]) ?>" class="dash-nav-dropdown-item">Update Password</a>
                            <a href="<?= Url::to(['ao-aircrafts/index']) ?>" class="dash-nav-dropdown-item">Aircrafts</a>
                            <a href="<?= Url::to(['ao-notifications-preferences/index']) ?>" class="dash-nav-dropdown-item">Notifications</a>
                        </div>
                    </div>
                    <a href="<?= Url::to(['conversations/index']) ?>" class="dash-nav-item">
                            <i class="fas fa-comments"></i> Messages
                        </a>






                <?php endif; ?>


                <?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'mro'): ?>

                    <div class="dash-nav-dropdown">
    <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
        <i class="fas fa-plane"></i> Requests </a>
    <div class="dash-nav-dropdown-menu">
        <a href="<?= Url::to(['mro-requests/index']) ?>" class="dash-nav-dropdown-item">New Requests</a>
        <a href="<?= Url::to(['mro-applications/index']) ?>" class="dash-nav-dropdown-item">Open Requests</a>
        <a href="<?= Url::to(['mro-applications/closed-requests']) ?>" class="dash-nav-dropdown-item">Closed Requests</a>
        <a href="<?= Url::to(['mro-appointments/index']) ?>" class="dash-nav-dropdown-item">My Appointments</a>
        <a href="<?= Url::to(['ao-mro-dispute/index']) ?>" class="dash-nav-dropdown-item">Disputes</a>
    </div>
</div>
<div class="dash-nav-dropdown">
    <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
        <i class="fas fa-user"></i> My Profile </a>
    <div class="dash-nav-dropdown-menu">
        <a href="<?= Url::to(['mro-profile/update', 'id' => Yii::$app->user->identity->getId()]) ?>" class="dash-nav-dropdown-item">Update Profile</a>
        <a href="<?= Url::to(['mro-profile/reset-password', 'id' => Yii::$app->user->identity->getId()]) ?>" class="dash-nav-dropdown-item">Update Password</a>
        <a href="<?= Url::to(['mro-airports/index']) ?>" class="dash-nav-dropdown-item">Airports</a>
        <a href="<?= Url::to(['mro-certificates/index']) ?>" class="dash-nav-dropdown-item">NAA Approvals</a>
        <a href="<?= Url::to(['mro-aircraft-certificates/index']) ?>" class="dash-nav-dropdown-item">Certificates </a>
        <a href="<?= Url::to(['mro-profile/update-insurance', 'id' => Yii::$app->session->get('mro_id')]) ?>" class="dash-nav-dropdown-item">Insurance</a>

        <a href="<?= Url::to(['mro-notifications-preferences/index']) ?>" class="dash-nav-dropdown-item">Notifications</a>
    </div>
</div>


                    <a href="<?= Url::to(['conversations/index']) ?>" class="dash-nav-item">
                            <i class="fas fa-comments"></i> Messages
                        </a>





                <?php endif; ?>




  <!-- Logout Button -->
  <?php if (!Yii::$app->user->isGuest): ?>
        <div class="logout-container">
            <?= Html::beginForm(['site/logout'], 'post', ['class' => 'logout-form']) ?>
            <?= Html::submitButton('<i class="fas fa-sign-out-alt"></i> Logout', ['class' => 'btn btn-link logout-button text-white']) ?>
            <?= Html::endForm() ?>
        </div>
    <?php endif; ?>
            </nav>
        </div>
        <div class="dash-app">
            <header class="dash-toolbar">
                <a href="#!" class="menu-toggle">
                    <i class="fas fa-bars"></i>
                </a>

                <div class="tools">
                <a href="#!" class="tools-item" id="notification-link">
                    <i class="fas fa-bell"></i>
                    <i class="tools-item-count" id="notification-count">0</i>
                </a>

                <div class="dropdown tools-item">
                    <a href="#" class="" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu1">
                    <?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'ao'): ?>
                        <a href="<?= Url::to(['ao-profile/view', 'id' => Yii::$app->user->identity->getId()]) ?>" class="btn btn-link" style="text-align: left;">Profile</a>
                        <?php endif;?>
                        <?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'mro'): ?>
                        <a href="<?= Url::to(['mro-profile/view', 'id' => Yii::$app->user->identity->getId(),'fromMro'=>'truse']) ?>" class="btn btn-link" style="text-align: left;">Profile</a>
                        <?php endif;?>
                        <?= Html::beginForm(['site/logout'], 'post', ['class' => 'logout-form']) ?>
                        <?= Html::submitButton('Logout', ['class' => 'btn btn-link logout-button', 'style' => 'color: black;']) ?>
                        <?= Html::endForm() ?>                    </div>
                </div>
            </div>
            <!-- Notification Dropdown -->
            <div id="notification-dropdown" class="dropdown-menu dropdown-menu-right" aria-labelledby="notification-link">
                    <div class="notification-dropdown-header">
                        <h3 class="text-center">Notifications</h3>
                    </div>
                    <div id="notification-list" class="dropdown-item">
                        <!-- Notifications will be dynamically loaded here -->
                    </div>
                    <div class="notification-actions text-center">
                        <button id="mark-all-read-btn" class="btn btn-sm btn-primary">Mark All as Read</button>
                        <button id="delete-all-btn" class="btn btn-sm btn-danger delete-all">Delete All</button>
                    </div>
                </div>

        </header>




<?php

$notificationCountUrl = Url::to(['notification/notification-count']);
$notificationListUrl = Url::to(['notification/notification-list']);
$notificationUpdateUrl = Url::to(['notification/update-notification']);
$notificationDeleteUrl = Url::to(['notification/delete-notification']);
$deleteAllNotificationsUrl = Url::to(['notification/delete-all']);
$markllNotificationAsReadURL =  Url::to(['notification/mark-all-as-read']);
$js = <<<JS

    // Function to update notification count
    function updateNotificationCount() {
        fetch('$notificationCountUrl')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('notification-count').textContent = data.count;
                } else {
                    console.error('Failed to fetch notification count.');
                }
            })
            .catch(error => {
                console.error('Error fetching notification count:', error);
            });
    }
     // Call updateNotificationCount initially when the page loads
     document.addEventListener('DOMContentLoaded', function() {
                updateNotificationCount();
                    // Poll every 30 seconds (30000 ms)
    setInterval(updateNotificationCount, 5000);
            });

    // Function to fetch and display notifications
   function fetchNotifications() {
    fetch('$notificationListUrl')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const notificationList = document.getElementById('notification-list');
                notificationList.innerHTML = ''; // Clear existing notifications

                data.notifications.forEach(notification => {
                    let notificationItem = document.createElement('div');
                    notificationItem.classList.add('dropdown-item');

                    let content = '<div>' + notification.message + '</div><div class="notification-actions">';

                    // Add "View" button if actions field is not null
                    if (notification.actions) {
                                            const fullUrl =notification.actions;
                    content += '<a href="' + fullUrl + '" class="btn btn-sm btn-success ">View</a> ';
                    }

                    if (notification.read !== "read") {
                        content += '<button class="btn btn-sm btn-primary mark-as-read-btn" data-id="' + notification.id + '">Mark as Read</button> ';
                    }

                    content += '<button class="btn btn-sm btn-info delete-notification-btn" data-id="' + notification.id + '">Delete</button>';
                    content += '</div>';

                    notificationItem.innerHTML = content;
                    notificationList.appendChild(notificationItem);
                });
                
                document.getElementById('notification-dropdown').classList.add('show');
            } else {
                console.error('Failed to fetch notifications.');
            }
        })
        .catch(error => {
            console.error('Error fetching notifications:', error);
        });
}

    // Function to delete all notifications

// Function to mark all notifications as read
function markAllNotificationsAsRead() {
    fetch('$markllNotificationAsReadURL')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Add 'read-notification' class to all notification items
                document.querySelectorAll('.dropdown-item').forEach(item => {
                    item.classList.add('read-notification');
                });
                updateNotificationCount(); // Update notification count after marking all as read
                fetchNotifications();
                closeNotificationDropdown(); // Close the notification dropdown

            } else {
                console.error('Failed to mark all notifications as read.');
            }
        })
        .catch(error => {
            console.error('Error marking all notifications as read:', error);
        });
}

// Function to close the notification dropdown
function closeNotificationDropdown() {
    const notificationDropdown = document.getElementById('notification-dropdown');
    notificationDropdown.classList.remove('show');

}

    // Show notifications when notification link is clicked
    document.getElementById('notification-link').addEventListener('click', function(event) {
        event.preventDefault();
        document.getElementById('notification-dropdown').classList.toggle('show');
        if (document.getElementById('notification-dropdown').classList.contains('show')) {
            fetchNotifications();
        }
    });

    // Mark notification as read
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('mark-as-read-btn')) {
            let notificationId = event.target.getAttribute('data-id');
            fetch('$notificationUpdateUrl?id=' + notificationId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        event.target.closest('.dropdown-item').classList.add('read-notification');
                        updateNotificationCount(); // Update notification count after marking as read
                    } else {
                        console.error('Failed to mark notification as read.');
                    }
                })
                .catch(error => {
                    console.error('Error marking notification as read:', error);
                });
        }
    });
 // Event listener for 'Mark All as Read' button
    document.getElementById('mark-all-read-btn').addEventListener('click', function(event) {
        markAllNotificationsAsRead();
    });

    // Event listener for 'Delete All' button
 /*   document.getElementById('delete-all-btn').addEventListener('click', function(event) {
        deleteAllNotifications(); // Call the function to delete all notifications
    });*/
    // Delete notification
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('delete-notification-btn')) {
            let notificationId = event.target.getAttribute('data-id');
            fetch('$notificationDeleteUrl?id=' + notificationId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        event.target.closest('.dropdown-item').remove();
                        updateNotificationCount(); // Update notification count after deletion
                       // closeNotificationDropdown(); // Close the notification dropdown

                    } else {
                        console.error('Failed to delete notification.');
                    }
                })
                .catch(error => {
                    console.error('Error deleting notification:', error);
                });
        }
    });

        // Delete all notification
        document.addEventListener('click', function(event) {
        if (event.target.classList.contains('delete-all')) {
            fetch('$deleteAllNotificationsUrl')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Clear the notification list
                    const notificationList = document.getElementById('notification-list');
                    notificationList.innerHTML = '';
                    updateNotificationCount(); // Update notification count after deletion

                } else {
                    console.error('Failed to delete all notifications.');
                }
            })
            .catch(error => {
                console.error('Error deleting all notifications:', error);
            });
        }
    });

    // Example: Call updateNotificationCount on a timer (every 30 seconds)
    setInterval(updateNotificationCount, 30000); // Adjust interval as needed (in milliseconds)

    document.addEventListener('DOMContentLoaded', function() {
    // Ensure both dropdowns are open on page load
    const dropdownMenus = document.querySelectorAll('.dash-nav-dropdown-menu');
    dropdownMenus.forEach(menu => {
        menu.style.display = 'block'; // Show all dropdowns by default
    });

    const dropdownToggles = document.querySelectorAll('.dash-nav-dropdown-toggle');
    dropdownToggles.forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            const menu = this.nextElementSibling; // Get the corresponding dropdown menu
            menu.style.display = (menu.style.display === 'block') ? 'none' : 'block'; // Toggle the menu
        });
    });

    // Add click event listener for dropdown items
    const dropdownItems = document.querySelectorAll('.dash-nav-dropdown-menu a');
    dropdownItems.forEach(item => {
        item.addEventListener('click', function(e) {
            const menu = this.closest('.dash-nav-dropdown-menu');
            if (menu.style.display === 'none') {
                e.preventDefault(); // Prevent action if menu is closed
            } else {
                // Allow navigation since the menu is open
                console.log('Navigating to:', this.href);
                // Optionally, you can redirect here if you want
                // window.location.href = this.href;
            }
        });
    });
});




JS;

$this->registerJs($js, yii\web\View::POS_END);
?>



            
            <?php
$js = <<<JS
    $(document).on('click', '.logout-form button[type="submit"]', function() {
        $(this).closest('form').submit();
    });
JS;
$this->registerJs($js);
