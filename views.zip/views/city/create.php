<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;

$this->title = 'Add City';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">Add City</h1>
        <?php $form = ActiveForm::begin(); ?>
        
        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($city, 'city_name')->textInput(['maxlength' => true])->label($city->getAttributeLabel('city_name') . '<span class="text-danger">*</span>') ?>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($city, 'country_id')->dropDownList(
                    ArrayHelper::map($countries, 'country_id', 'country_name'),
                    ['prompt' => 'Select Country']
                )->label('Country Name' . '<span class="text-danger">*</span>') ?>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-lg-6">
                        <?= Html::submitButton('Add City', ['class' => 'btn btn-primary']); ?>
                    </div>
                    <div class="col-lg-2">
                    <?= Html::a('Back to City', ['index'], ['class' => 'btn btn-primary']) ?>
                    </div>
                </div>
            </div>
        </div>
        
        <?php ActiveForm::end(); ?>
    </div>
</main>
