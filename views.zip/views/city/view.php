<?php
use yii\helpers\Html;

$this->title = 'View City';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">View City</h1>
        <div class="row">
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>City Name:</strong> <?php echo Html::encode($city->city_name); ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Country:</strong> <?php echo Html::encode($city->country->country_name); ?>
                </li>
            </ul>
            <div class="row mt-3">
                <div class="col-lg-12">
                <?= Html::a('Back to City', ['index'], ['class' => 'btn btn-primary']) ?>
                </div>
            </div>
        </div>
    </div>
</main>
