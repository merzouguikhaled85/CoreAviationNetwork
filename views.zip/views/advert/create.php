<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\jui\DatePicker;

$this->title = 'Create Advert';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        
        <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>
        
        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($advert, 'admin_id')->dropDownList($adminList, ['prompt' => 'Select Admin'])->label('Admin Username' . '<span class="text-danger">*</span>') ?>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($advert, 'advert_type')->dropDownList(['photo' => 'Photo', 'video' => 'Video'], ['prompt' => 'Select Advert Type'])->label($advert->getAttributeLabel('advert_type') . '<span class="text-danger">*</span>') ?>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($advert, 'use_url')->checkbox(['id' => 'use-url-checkbox']) ?>
            </div>
        </div>

        <div id="file-input" style="display: none;">
            <div class="row">
                <div class="col-lg-6">
                    <?= $form->field($advert, 'content')->fileInput()->label($advert->getAttributeLabel('content') . '<span class="text-danger">*</span>') ?>
                </div>
            </div>
        </div>

        <div id="url-input" style="display: none;">
            <div class="row">
                <div class="col-lg-6">
                    <?= $form->field($advert, 'url')->textInput(['placeholder' => 'Enter URL'])->label($advert->getAttributeLabel('url') . '<span class="text-danger">*</span>') ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($advert, 'start_date')->widget(DatePicker::className(), [
                    'dateFormat' => 'yyyy-MM-dd',
                    'clientOptions' => [
                        'autoclose' => true,
                        'todayHighlight' => true
                    ],
                    'options' => ['class' => 'form-control']
                ])->label($advert->getAttributeLabel('start_date') . '<span class="text-danger">*</span>') ?>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($advert, 'end_date')->widget(DatePicker::className(), [
                    'dateFormat' => 'yyyy-MM-dd',
                    'clientOptions' => [
                        'autoclose' => true,
                        'todayHighlight' => true
                    ],
                    'options' => ['class' => 'form-control']
                ])->label($advert->getAttributeLabel('end_date') . '<span class="text-danger">*</span>') ?>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($advert, 'status')->dropDownList(['active' => 'Active', 'inactive' => 'Inactive'], ['prompt' => 'Select Status'])->label($advert->getAttributeLabel('status') . '<span class="text-danger">*</span>') ?>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <?= Html::submitButton('Create Advert', ['class' => 'btn btn-primary']) ?>
            </div>
        </div>

        <?php ActiveForm::end() ?>
    </div>
</main>

<?php
$script = <<< JS
$(document).ready(function(){
    // Function to show/hide file input or URL input based on checkbox status
    function toggleInputs() {
        if($('#use-url-checkbox').is(":checked")) {
            $('#file-input').hide();
            $('#url-input').show();
        } else {
            $('#file-input').show();
            $('#url-input').hide();
        }
    }
    
    // Call the function when the page loads
    toggleInputs();

    // Call the function whenever the checkbox status changes
    $('#use-url-checkbox').change(toggleInputs);
});
JS;
$this->registerJs($script);
?>
