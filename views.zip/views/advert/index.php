

<?php

use yii\helpers\Html;
use yii\widgets\LinkPager;


// Define custom CSS styles for pagination links
$this->registerCss("
    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    
    .pagination li {
        margin: 0 5px;
    }
    
    .pagination .active a {
        background-color: #007bff;
        color: #fff;
    }
    
    .pagination li a {
        color: #007bff;
        border: 1px solid #007bff;
        padding: 6px 12px;
        text-decoration: none;
        border-radius: 3px;
    }
    
    .pagination li a:hover {
        background-color: #f2f2f2;
    }
");
$this->title = 'Adverts';
?>

<main class="dash-content">
    <div class="container-fluid">
    <?php if (Yii::$app->session->hasFlash('message')): ?>
    <div class="alert alert-success">
        <?= Yii::$app->session->getFlash('message') ?>
    </div>
<?php endif; ?>
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        <div class="row" style="margin-bottom: 20px;">
        <div class="col-auto ml-auto" style="float: right; display: inline-block;">

        <?= Html::a('Create Advert', ['create'], ['class' => 'btn btn-outline-primary  btn-lg rounded-pill']) ?>
        </div>
</div>
        <div class="row" style="margin-top: 20px;">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Admin Username</th>
                        <th>Advert Type</th>
                        <th>Content</th>
                        <th>Timestamp</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($adverts as $advert): ?>
                        <tr>
                            <td><?= $advert->advert_id ?></td>
                            <td><?= $advert->admin ? Html::encode($advert->admin->username) : 'N/A' ?></td>
                            <td><?= Html::encode($advert->advert_type) ?></td>
                            <td>
                                <?php if ($advert->advert_type == 'photo'): ?>
                                    <?= Html::img('@web/uploads/' . $advert->content, ['style' => 'width:100px;']) ?>
                                <?php else: ?>
                                    <video width="100" controls>
                                        <source src="<?= Yii::getAlias('@web/uploads/' . $advert->content) ?>" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php endif; ?>
                            </td>
                            <td><?= Html::encode($advert->timestamp) ?></td>
                            <td><?= Html::encode($advert->start_date) ?></td>
                            <td><?= Html::encode($advert->end_date) ?></td>
                            <td><?= Html::encode($advert->status) ?></td>
                            <td>
                                <?= Html::a('Toggle Status', ['toggle-status', 'id' => $advert->advert_id], [  'class' => 'btn',
                                    'style' => 'background-color: violet; color: white;',]) ?>
                                <?= Html::a('View', ['view', 'id' => $advert->advert_id], ['class' => 'btn btn-info']) ?>
                                <?= Html::a('Modify', ['update', 'id' => $advert->advert_id], ['class' => 'btn btn-primary']) ?>
                                <?= Html::a('Remove', ['delete', 'id' => $advert->advert_id], [
                                    'class' => 'btn btn-secondary',
                                    'data' => [
                                        'confirm' => 'Are you sure you want to delete this item?',
                                        'method' => 'post',
                                    ],
                                ]) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="pagination-container">
            <?= LinkPager::widget(['pagination' => $pagination]) ?>
        </div>
    </div>
</main>
