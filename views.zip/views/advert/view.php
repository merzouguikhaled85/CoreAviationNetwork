<?php
use yii\helpers\Html;

$this->title = 'View Advert: ' . $advert->advert_id;
$this->params['breadcrumbs'][] = ['label' => 'Adverts', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <ul class="list-group">
            <li class="list-group-item">
                <strong>ID:</strong> <?= Html::encode($advert->advert_id) ?>
            </li>
            <li class="list-group-item">
                <strong>Admin Username:</strong> <?= $advert->admin ? Html::encode($advert->admin->username) : 'N/A' ?>
            </li>
            <li class="list-group-item">
                <strong>Advert Type:</strong> <?= Html::encode($advert->advert_type) ?>
            </li>
            <li class="list-group-item">
                <strong>Content:</strong>
                <?php if ($advert->advert_type == 'photo'): ?>
                    <?= Html::img('@web/uploads/' . $advert->content, ['style' => 'width:100px;']) ?>
                <?php else: ?>
                    <video width="100" controls>
                        <source src="<?= Yii::getAlias('@web/uploads/' . $advert->content) ?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                <?php endif; ?>
            </li>
            <li class="list-group-item">
                <strong>Timestamp:</strong> <?= Html::encode($advert->timestamp) ?>
            </li>
            <li class="list-group-item">
                <strong>Start Date:</strong> <?= Html::encode($advert->start_date) ?>
            </li>
            <li class="list-group-item">
                <strong>End Date:</strong> <?= Html::encode($advert->end_date) ?>
            </li>
            <li class="list-group-item">
                <strong>Status:</strong> <?= Html::encode($advert->status) ?>
            </li>
        </ul>

        <div class="row" style="margin-top: 20px;">
            <?= Html::a('Back to Adverts', ['index'], ['class' => 'btn btn-primary']) ?>

        </div>
    </div>
</main>
