<?php

use app\models\Requests;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Conversation Request : ' . Html::encode( $conversation->request_id);
?>
<style>

.message-header {
    display: flex;
    justify-content: center; /* Center the timestamp horizontally */
    margin-bottom: 5px;
}

.timestamp {
    padding: 4px 8px;
    border-radius: 5px;
    font-size: 12px;

}
.message {
    align-items: center;
    margin-bottom: 10px;
    font-size: 24px;

}
.sent-by-me {
    justify-content: flex-end;
    text-align: left;
}
.sent-by-others {
    justify-content: flex-start;
    text-align: left;
}

.sender {
    margin-right: 10px;
    font-weight: bold;
}

.message-body {
    padding: 8px;
    border-radius: 5px;
}
.message-ul {
    list-style-type: none; /* Remove list decoration */
    margin: 0;
    padding: 0;
}
.message-list-container {
    height: 400px; /* Adjust the height as needed */
    overflow-y: auto; /* Add vertical scroll if content exceeds container height */
}
</style>
<h1><?= Html::encode($this->title) ?></h1>

<div class="conversation-details">
<?php
        // Check for flash messages
        if (Yii::$app->session->hasFlash('message')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('message') . '</div>';
        }
        if (Yii::$app->session->hasFlash('error')) {
            echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
        }
        ?>
    <p><strong>Created At:</strong> <?= Yii::$app->formatter->asDatetime($conversation->timestamp) ?></p>
</div>

<div class="message-list-container">
    <div class="message-list" id="message-list">
        <?php if (!empty($messages)) : ?>
            <ul class="message-ul">
                <?php foreach ($messages as $message) : ?>
                    <?php if (!empty($message->message)) : ?>

                    <li>
                        <div class="message-header">
                            <div class="timestamp"><?= Yii::$app->formatter->asDatetime($message->timestamp) ?></div>
                        </div>
                        <div class="message <?= ($message->sender->username === Yii::$app->session->get('username')) ? 'sent-by-me' : 'sent-by-others' ?>">
                        <span class="sender"><?= ($message->sender->username === Yii::$app->session->get('username')) ? 'Me:' : Html::encode($message->sender->username) . ' :' ?></span>

                            <span class="message-body"><?= Html::encode($message->message) ?></span>
                        </div>
                    </li>

                    <?php endif; ?>

                <?php endforeach; ?>
            </ul>
        <?php else : ?>
            <p>No messages found.</p>
        <?php endif; ?>
    </div>
</div>





<div class="reply-form">
    <?php $form = ActiveForm::begin(['action' => ['conversations/reply', 'chat_id' => $conversation->chat_id]]); ?>

    <?= $form->field($newMessage, 'message')->textarea(['rows' => 2]) ?>

    <div class="form-group">
        <?= Html::submitButton('Send', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>
<?php
$conversationId = $conversation->chat_id; // e.g., passed from controller
$fetchUrl = \yii\helpers\Url::to(['conversations/fetch-messages', 'conversationId' => $conversationId]);
$js = <<<JS
setInterval(function() {
    $.ajax({
        url: '{$fetchUrl}',
        type: 'GET',
        success: function(data) {
            $('#message-list').html(data);
        }
    });
}, 5000); // every 5 seconds
JS;

$this->registerJs($js);
?>

<?php
$this->registerJs('
    $(document).ready(function() {
        var messageListContainer = $(".message-list-container");
        if (messageListContainer.length) {
            messageListContainer.scrollTop(messageListContainer[0].scrollHeight);
        }
    });
');
?>
