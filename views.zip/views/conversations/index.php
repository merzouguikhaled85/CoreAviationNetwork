<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\helpers\VarDumper;

$this->title = 'Messages';
?>
<div class="conversation-index">
    <h1><?= Html::encode($this->title) ?></h1>

    <?php if (!empty($groupedConversations)) : ?>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Request ID</th>
                    <th>Conversation With</th>
                    <th>Last Sender</th>
                    <th>Last Message</th>
                    <th>Timestamp</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($groupedConversations as $requestId => $conversations) : ?>
                    <?php
                        // Get the latest message in each request group
                        $lastMessage = reset($conversations);
                    ?>
                    <tr>
                        <td><?= Html::encode($requestId) ?></td>
                        <td><?= ($lastMessage->sender->username === Yii::$app->session->get('username')) ? Html::encode($lastMessage->receiver->username) : Html::encode($lastMessage->sender->username) ?></td>
                        <td><?= ($lastMessage->sender->username === Yii::$app->session->get('username')) ? 'Me' : Html::encode($lastMessage->sender->username) ?></td>
                        <td><?= Html::encode($lastMessage->message) ?></td>
                        <td><?= Yii::$app->formatter->asDatetime($lastMessage->timestamp) ?></td>
                        <td>
                            <?= Html::a('View', ['conversations/view', 'chat_id' => $lastMessage->chat_id], ['class' => 'btn btn-info']) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p>No conversations found.</p>
    <?php endif; ?>
</div>

<?php
// Add some basic styling for better presentation
$this->registerCss('
    .conversation-index {
        font-family: Arial, sans-serif;
    }
    .table-hover tbody tr:hover {
        background-color: #f5f5f5;
    }
    .table thead th {
        background-color: #f9f9f9;
    }
    .btn-info {
        background-color: #5bc0de;
        border-color: #46b8da;
    }
');
?>
