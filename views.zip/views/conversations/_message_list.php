<?php

use yii\helpers\Html;

 if (!empty($messages)) : ?>
    <ul class="message-ul">
        <?php foreach ($messages as $message) : ?>
            <?php if (!empty($message->message)) : ?>
                <li>
                    <div class="message-header">
                        <div class="timestamp"><?= Yii::$app->formatter->asDatetime($message->timestamp) ?></div>
                    </div>
                    <div class="message <?= ($message->sender->username === Yii::$app->session->get('username')) ? 'sent-by-me' : 'sent-by-others' ?>">
                        <span class="sender"><?= ($message->sender->username === Yii::$app->session->get('username')) ? 'Me:' : Html::encode($message->sender->username) . ' :' ?></span>
                        <span class="message-body"><?= Html::encode($message->message) ?></span>
                    </div>
                </li>
            <?php endif; ?>
        <?php endforeach; ?>
    </ul>
<?php else : ?>
    <p>No messages found.</p>
<?php endif; ?>
