<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

$this->title = 'Reply to Dispute';
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <?php
        // Check if there is a success flash message set
        if (Yii::$app->session->hasFlash('success')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
        }
        ?>

        <div class="dispute-reply-form">
            <?php $form = ActiveForm::begin(); ?>

            <?= $form->field($dispute, 'dispute_id')->hiddenInput()->label(false) ?>

            <?= $form->field($dispute, 'request_id')->textInput(['readonly' => true]) ?>

            <?= $form->field($dispute, 'description')->textarea(['rows' => 6, 'readonly' => true]) ?>

            <?= $form->field($dispute, 'timestamp')->textInput(['readonly' => true]) ?>

            <?= $form->field($dispute, 'ao_username')->textInput(['value' => $dispute->ao->username, 'readonly' => true]) ?>

            <?= $form->field($dispute, 'mro_username')->textInput(['value' => $dispute->mro->username, 'readonly' => true]) ?>


            <?= $form->field($dispute, 'ao_id')->hiddenInput()->label(false) ?>

            <?= $form->field($dispute, 'mro_id')->hiddenInput()->label(false) ?>

           <strong> <?= Html::a('Download PO', Yii::getAlias('@web/uploads/') . $dispute->po, ['target' => '_blank']) ?></strong>
    </br>    </br>



            <?= $form->field($dispute, 'created_by')->textInput(['readonly' => true]) ?>

            <?= $form->field($dispute, 'admin_response')->textarea(['rows' => 6]) ?>

            <?= $form->field($dispute, 'status')->dropDownList([
                'resolved' => 'Resolved',
                'open' => 'Not Resolved',
            ]) ?>

            <div class="form-group">
                <?= Html::submitButton('Submit Response', ['class' => 'btn btn-primary']) ?>
            </div>

            <?php ActiveForm::end(); ?>
        </div>
    </div>
</main>

<?php
// Generating URL for AJAX request to fetch dispute details
$fetchDetailsUrl = Url::to(['admin-disputes/fetch-details']);

// JavaScript section to handle onchange event of dispute_id dropdown
$script = <<< JS
$('#replymodel-dispute_id').on('change', function() {
    var disputeId = $(this).val();

    if (disputeId) {
        $.ajax({
            url: '{$fetchDetailsUrl}', // Using the generated URL
            type: 'GET',
            data: { disputeId: disputeId },
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    $('#replymodel-admin_response').val(data.admin_response);
                    $('#replymodel-status').val(data.status).trigger('change'); // Trigger change event if needed
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching dispute details:', error);
            }
        });
    }
});
JS;
$this->registerJs($script);
?>
