<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;

?>

<?php $this->title ='GlobaleMRO' ?>

            <main class="dash-content">
                <div class="container-fluid">
                    <h1 class="dash-title">View Country</h1>
                   <div class="row">
                   <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?php echo $country->country_name; ?>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?php echo $country->country_code; ?>

                        </li>
                    </ul>
                    <div class="row">
                    <?= Html::a('Back to Country', ['index'], ['class' => 'btn btn-primary']) ?>
                    </div>
                   </div>
                </div>
            </main>
        </div>
    </div>
 
