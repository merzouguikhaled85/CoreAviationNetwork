<?php 
use yii\helpers\Html;
use yii\widgets\LinkPager;
?>
<?php $this->title ='GlobaleMRO' ?>
<?php
$this->registerJs("
    $(document).on('click', 'a[data-confirm]', function(e) {
        var href = $(this).attr('href');
        var message = $(this).attr('data-confirm');
        if (!confirm(message)) {
            e.preventDefault();
        }
    });
");
// Define custom CSS styles for pagination links
$this->registerCss("
    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    
    .pagination li {
        margin: 0 5px;
    }
    
    .pagination .active a {
        background-color: #007bff;
        color: #fff;
    }
    
    .pagination li a {
        color: #007bff;
        border: 1px solid #007bff;
        padding: 6px 12px;
        text-decoration: none;
        border-radius: 3px;
    }
    
    .pagination li a:hover {
        background-color: #f2f2f2;
    }
    .search-container {
        display: flex;
        border-radius: 20px;
        overflow: hidden;
    }
    
    .search-input {
        flex: 1;
        border-top-left-radius: 20px;
        border-bottom-left-radius: 20px;
    }
    
    .search-button {
        border-top-right-radius: 20px;
        border-bottom-right-radius: 20px;
    }
    .search-input-lg {
        width: 100%; /* Set width to 100% to make it full width */
        height: 50px; /* Adjust height as needed */
        font-size: 18px; /* Increase font size for larger input */
    }
");
?>


<main class="dash-content">
    <?php if(yii::$app->session->hasFlash('message')): ?>
        <div class="alert alert-dismissible alert-success">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?php echo yii::$app->session->getFlash('message'); ?>
        </div>
    <?php endif; ?>

    <div class="container-fluid">
        
        <h1 class="dash-title">Countries</h1>
       
        <!-- put your rows / columns here -->
        <div class="row" style="margin-bottom: 20px;">
        <div class="col-lg-12">
        <?= Html::beginForm(['country/index'], 'get', ['class' => 'form-inline']) ?>
                <?= Html::textInput('search', Yii::$app->request->get('search'), ['class' => 'form-control search-input-lg search-input', 'placeholder' => 'Search by Country Name']) ?>

                <div class="input-group-append">
                    <?= Html::submitButton('Search', ['class' => 'btn btn-primary btn-lg search-button']) ?>

                </div>
            <?= Html::endForm() ?>
</div>

            <div class="col-auto ml-auto" style="float: right; display: inline-block;">
            </br></br></br>
                <?= Html::a('Add a country', ['country/create'], ['class' => 'btn btn-outline-primary  btn-lg rounded-pill']) ?>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card spur-card">
                    <div class="card-header">
                        <div class="spur-card-icon">
                            <i class="fas fa-table"></i>
                        </div>
                        <div class="spur-card-title">Countries</div>
                    </div>
                    <div class="card-body">



                        <table class="table table-hover table-in-card">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Country Name</th>
                                    <th scope="col">Country Code</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($countries) > 0 ): ?>
                                    <?php foreach($countries as $country):  ?>
                                        <tr>
                                            <th scope="row"><?php echo $country->country_id; ?> </th>
                                            <td><?php echo $country->country_name; ?></td>
                                            <td><?php echo $country->country_code; ?></td>
                                            <td>
                                                <span><?= Html::a('View',['view','id' =>$country->country_id], ['class' => 'btn btn-info']) ?></span>
                                                <span><?= Html::a('Modify',['update','id' =>$country->country_id], ['class' => 'btn btn-primary']) ?></span>
                                                <span><?= Html::a('Remove', ['delete', 'id' => $country->country_id], [
                                                    'class' => 'btn btn-secondary',
                                                    'data-confirm' => 'Are you sure you want to delete this item?',
                                                    'data-method' => 'post'
                                                ]) ?></span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4">No Records Found!</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <?= LinkPager::widget(['pagination' => $pagination]) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
