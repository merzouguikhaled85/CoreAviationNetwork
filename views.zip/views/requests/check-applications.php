<?php

use app\models\Currency;
use yii\helpers\Html;

$this->title = 'My Replies';
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<!-- Tooltip activation (JS) -->
<script>
    document.addEventListener("DOMContentLoaded", function(){
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-toggle="tooltip"]'))
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    });
</script>
<h1><?= Html::encode($this->title) ?></h1>
<?php
        if (Yii::$app->session->hasFlash('success')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
        }
        if (Yii::$app->session->hasFlash('error')) {
            echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
        }
        ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Request ID</th>
            <th>MRO</th>
<th style="width: 30%;">Description</th>
            <th>Price</th>
            <th>Currency</th>
            <th>attachment</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($applications as $application): ?>
            <tr>
                <td><?= $request->request_id ?></td>
                <td><?= $application->mro->username ?></td>
                <td><?= $application->Description ?></td>
                <td><?= $application->price ?></td>
                <td>
                    <?php
                        // Retrieve the currency object based on the currency code
                        $currency = Currency::findOne(['code' => $application->currency]);
                        
                        // Check if the currency object exists
                        if ($currency !== null) {
                            // Display the currency name
                            echo $currency->name;
                        } else {
                            // Display a placeholder if the currency object is not found
                            echo 'Unknown Currency';
                        }
                    ?>
                </td>
<!-- Assuming you are displaying this in a table row -->
<td>

    <?php if ($application->attachment): ?>
        <?= Html::a('Download Attachment', Yii::getAlias('@web/')  . $application->attachment, ['target' => '_blank']) ?>
    <?php else: ?>
        No Attachment Available
    <?php endif; ?>
</td>

                <td>
<?= Html::a('<i class="bi bi-check-circle"></i>', ['load-po', 'id' => $application->id], [
    'class' => 'btn btn-primary',
    'title' => 'Accept',
    'data-toggle' => 'tooltip'
]) ?>

<?= Html::a('<i class="bi bi-chat-dots"></i>', ['contact', 'id' => $application->id], [
    'class' => 'btn btn-info',
    'title' => 'Contact',
    'data-toggle' => 'tooltip'
]) ?>

<?= Html::a('<i class="bi bi-x-circle"></i>', ['deny', 'id' => $application->id], [
    'class' => 'btn btn-secondary',
    'title' => 'Deny',
    'data-toggle' => 'tooltip',
    'data' => [
        'confirm' => 'Are you sure you want to deny this application?',
        'method' => 'post',
    ],
]) ?>

<?= Html::a('<i class="bi bi-person-badge"></i>', ['mro-profile/view', 'id' => $application->mro_id, 'fromApplication' => $application->id], [
    'class' => 'btn btn-info',
    'title' => 'View MRO Profile',
    'data-toggle' => 'tooltip'
]) ?>

                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
