<?php

use yii\helpers\Html;

$this->title = 'View PO';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        
        <div class="row">
            <div class="col-md-12">
                <h3>Request ID: <?= $request->request_id ?></h3>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
            <table class="table table-bordered">
    <thead>
        <tr>
            <th>MRO Username</th>
            <th>Application  Description</th>
            <th>PO File</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($aoRequestsApplications as $aoRequestApplication): ?>
            <tr>
                <td><?= Html::encode($aoRequestApplication->application->mro->username) ?></td>
                <td><?= Html::encode($aoRequestApplication->application->Description) ?></td>
                <td><?= Html::a('Download PO', ['download-po', 'id' => $aoRequestApplication->id]) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

            </div>
        </div>
    </div>
</main>
