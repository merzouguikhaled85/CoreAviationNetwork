<?php
use app\models\AoRequestsApplications;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\LinkPager;

$this->title = $title;

$this->registerCss("

    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    
    .pagination li {
        margin: 0 5px;
    }
    
    .pagination .active a {
        background-color: #007bff;
        color: #fff;
    }
    
    .pagination li a {
        color: #007bff;
        border: 1px solid #007bff;
        padding: 6px 12px;
        text-decoration: none;
        border-radius: 3px;
    }
    
    .pagination li a:hover {
        background-color: #f2f2f2;
    }
    
    .search-container {
        display: flex;
        border-radius: 20px;
        overflow: hidden;
    }
    
    .search-input {
        flex: 1;
        border-top-left-radius: 20px;
        border-bottom-left-radius: 20px;
    }
    
    .search-button {
        border-top-right-radius: 20px;
        border-bottom-right-radius: 20px;
    }
    .search-input-lg {
        width: 100%; /* Set width to 100% to make it full width */
        height: 50px; /* Adjust height as needed */
        font-size: 18px; /* Increase font size for larger input */
    }
");
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<script>
document.addEventListener('DOMContentLoaded', function () {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
});
</script>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= $title ?></h1>

        <?php
        if (Yii::$app->session->hasFlash('message')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('message') . '</div>';
        }
                if (Yii::$app->session->hasFlash('success')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
        }
        
        if (Yii::$app->session->hasFlash('error')) {
            echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
        }
        ?>
        <div class="row" style="margin-bottom: 20px;">
        <div class="col-auto ml-auto" style="float: right; display: inline-block;">
            <?php if($title =='New requests'):?>
            <?= Html::a('Add Request', ['create'],['class' => 'btn btn-outline-primary  btn-lg rounded-pill'])  ?>
            <?php endif; ?>
            </div>
        </div>


        <div class="row">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>MRO</th>
                        <th>Aircraft Model</th>

                        <th>Aircraft Registration</th>
                        <th>Aircraft Serial Number</th>
                        <th>ETA</th>
                        <th>ETD</th>


                        <th>Maintenance Location</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $request): ?>
                        <tr>
                            <td><?= Html::a($request->request_id, ['view', 'id' => $request->request_id]) ?></td>
                            

                            <td>
    <?= $request->mroApplication && $request->mroApplication->getMro() ? $request->mroApplication->getMro()->username : '' ?>
</td>
                            <td><?= $request->getAircraft()->one()->model ?></td>
                            <td><?= Html::encode($request->aircraft_registration) ?></td>
                            <td><?= Html::encode($request->serial_number) ?></td>
<td><?= Html::encode($request->eta ? date('d M Y H:i', strtotime($request->eta)) : '') ?></td>
<td><?= Html::encode($request->etd ? date('d M Y H:i', strtotime($request->etd)) : '') ?></td>



                            <td><?= Html::encode($request->location) ?></td>
                            <td>
    <?php
    $status = $request->status;
    $formattedStatus = ucwords(str_replace('_', ' ', $status));
    ?>
                                <?php if ($request->status === 'answered'): ?>
                                    <?= Html::a(ucfirst($request->status), ['check-applications', 'id' => $request->request_id]) ?>
                                <?php elseif ($request->status === 'po_loaded'): ?>
                                    <?= Html::a('PO Loaded', ['view-po', 'id' => $request->request_id]) ?>
                                <?php elseif ($request->status === 'report_submitted' || $request->status === 'work_started' || $request->status === 'closed'|| $request->status === 'canceled'): ?>
                                    <?= Html::a('View CRS', ['view-reports', 'id' => $request->request_id]) ?>
                                    <?php elseif ($request->status === 'update_request' ): ?>
                                        <?= Html::a('Update Request', ['update', 'id' => $request->request_id,'status' =>$request->status]) ?>
                                <?php else: ?>
        <?= Html::encode($formattedStatus) ?>
                                <?php endif; ?>
                            </td>

                            <td>                            
                               <?= Html::a(
    '<i class="bi bi-eye"></i>',
    ['view', 'id' => $request->request_id],
    ['class' => 'btn btn-info', 'title' => 'View', 'data-toggle' => 'tooltip']
) ?>

<?php if ($request->status === 'work_accepted' || $request->status === 'work_started'): ?>
    <?= Html::a(
        '<i class="bi bi-pencil-square"></i>',
        ['update-request', 'id' => $request->request_id],
        [
            'class' => 'btn',
            'style' => 'background-color: violet; color: white;',
            'title' => 'Update Request',
            'data-toggle' => 'tooltip'
        ]
    ) ?>
<?php endif; ?>

<?php
$existingApplication = AoRequestsApplications::find()
    ->where(['request_id' => $request->request_id])
    ->exists();
$application = AoRequestsApplications::find()
    ->where(['request_id' => $request->request_id])
    ->orderBy(['id' => SORT_DESC])
    ->one();
?>

<?php if ($existingApplication && ($request->status !== 'answered' || $request->status !== 'created' || $request->status !== 'po_loaded')): ?>
    <?= Html::a(
        '<i class="bi bi-chat-dots"></i>',
        ['contact', 'id' => $application->application_id],
        ['class' => 'btn btn-secondary', 'title' => 'Contact', 'data-toggle' => 'tooltip']
    ) ?>
<?php endif; ?>

<?php if (in_array($request->status, ['answered', 'created', 'po_loaded'])): ?>
    <?= Html::a(
        '<i class="bi bi-pencil"></i>',
        ['update', 'id' => $request->request_id],
        ['class' => 'btn btn-primary', 'title' => 'Update', 'data-toggle' => 'tooltip']
    ) ?>
    <?= Html::a(
        '<i class="bi bi-trash"></i>',
        ['delete', 'id' => $request->request_id],
        [
            'class' => 'btn btn-danger',
            'title' => 'Delete',
            'data-toggle' => 'tooltip',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]
    ) ?>
<?php endif; ?>


                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="pagination-container">
            <?= LinkPager::widget(['pagination' => $pagination]) ?>
        </div>
    </div>
</main>
