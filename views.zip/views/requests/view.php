<?php

use app\models\AoRequestsApplications;
use yii\helpers\Html;

$this->title = 'Request: ' . $request->request_id;
$this->params['breadcrumbs'][] = ['label' => 'Requests', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<script>
document.addEventListener("DOMContentLoaded", function() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-toggle="tooltip"]'))
    tooltipTriggerList.map(function (el) {
        return new bootstrap.Tooltip(el)
    });
});
</script>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <div class="row">
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Request ID:</strong>
                    <?= Html::encode($request->request_id) ?>
                </li>

                <?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'mro'): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Aircraft Operator/CAMO:</strong>
                    <?= Html::encode($request->getAO()->one()->username) ?>
                </li>
                <?php endif;?>

                <?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'ao'): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>MRO:</strong>

    <?= $request->mroApplication && $request->mroApplication->getMro() ? $request->mroApplication->getMro()->username : '' ?>
                </li>
                <?php endif;?>

                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Aircraft:</strong>
                    <?= Html::encode($request->getAircraft()->one()->manufacturer) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Model:</strong>
                    <?= Html::encode($request->getAircraft()->one()->model) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Aircraft Registration:</strong>
                    <?= Html::encode($request->getAircraft()->one()->registration_number) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Aircraft Serial Number:</strong>
                    <?= Html::encode($request->getAircraft()->one()->serial_number) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>ETD:</strong>
                    <?= Html::encode( date('d M Y H:i', strtotime($request->etd))) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>ETA:</strong>
                    <?= Html::encode( date('d M Y H:i', strtotime($request->eta))) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Maintenance Location:</strong>
                    <?= Html::encode($request->location) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>National Aviation Authority : </strong>
                    <?= Html::encode($request->getAircraft()->one()->getCertificateType()->one()->type) ?>
                </li>
                <?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'ao'): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Status:</strong>
                    <?php if ($request->status === 'answered'): ?>
                                    <?= Html::a($request->status, ['check-applications', 'id' => $request->request_id]) ?>
                                <?php elseif ($request->status === 'po_loaded'): ?>
                                    <?= Html::a($request->status, ['view-po', 'id' => $request->request_id]) ?>
                                <?php elseif ($request->status === 'report_submitted' || $request->status === 'work_started' || $request->status === 'closed'|| $request->status === 'canceled'): ?>
                                    <?= Html::a('View CRS', ['view-reports', 'id' => $request->request_id]) ?>
                                    <?php elseif ($request->status === 'update_request' ): ?>
                                        <?= Html::a($request->status, ['update', 'id' => $request->request_id,'status' =>$request->status]) ?>
                                <?php else: ?>
                                    <?= $request->status ?>
                                <?php endif; ?>                </li>
                                <?php endif;?>

                                <?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'mro'): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Status:</strong>
                    <?= $request->status ?>

                </li>
                                <?php endif;?>

                <li class="list-group-item d-flex justify-content-between align-items-center">
    <div class="d-flex flex-column"> <!-- Container for attachments -->
        <strong>Attachments:</strong>
    </div>

    <div class="ml-auto"> <!-- Container for work packs and CRS on the right -->
    <?php if (!empty($request->attachment)): ?>
                <a href="<?= Html::encode('../'.$request->attachment) ?>" target="_blank"> Request Attachment  </a>
            <?php else: ?>
                <span>  Request Attachment </span>
            <?php endif; ?>


    <?php if (!empty($poAttachment)): ?>
                <a href="<?= Html::encode('../uploads/'.$poAttachment) ?>" target="_blank">PO  </a>
            <?php else: ?>
                <span> PO </span>
            <?php endif; ?>

            <?php if (!empty($invoice)): ?>
                <a href="<?= Yii::$app->urlManager->createUrl(['mro-applications/view-answer', 'id' => $invoice]) ?>" target="_blank"> Invoice </a>
                <?php else: ?>
                <span>  Invoice </span>
            <?php endif; ?>
       

        <?php if (!empty($crs)): ?>
            <a href="<?= Html::encode('../uploads/'.$crs) ?>" target="_blank"> CRS  </a>
        <?php else: ?>
            <span>  CRS </span>
        <?php endif; ?>
    </div>
</li>



<?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'ao'): ?>

<li class="list-group-item d-flex justify-content-between align-items-center">
    <div class="d-flex flex-column">
        <strong>Actions:</strong>
    </div>

    <div class="ml-auto d-flex gap-1"> <!-- Button container with spacing -->

        <?php if ($request->status === 'work_accepted' || $request->status === 'work_started') {
            echo Html::a('<i class="bi bi-pencil-square"></i>', ['update-request', 'id' => $request->request_id], [
                'class' => 'btn',
                'style' => 'background-color: violet; color: white;',
                'title' => 'Update Request',
                'data-toggle' => 'tooltip'
            ]);
        } ?>

        <?php
        $existingApplication = AoRequestsApplications::find()
            ->where(['request_id' => $request->request_id])
            ->exists();
        $application = AoRequestsApplications::find()
            ->where(['request_id' => $request->request_id])
            ->orderBy(['id' => SORT_DESC])
            ->one();
        ?>

        <?php if ($existingApplication && ($request->status !== 'answered' || $request->status !== 'created' || $request->status !== 'po_loaded')): ?>
            <?= Html::a('<i class="bi bi-chat-dots"></i>', ['contact', 'id' => $application->application_id], [
                'class' => 'btn btn-info',
                'title' => 'Contact',
                'data-toggle' => 'tooltip'
            ]) ?>
        <?php endif; ?>
        <?php if ($request->status == 'answered' ): ?>
           <?= Html::a(
    '<i class="bi bi-check-square"></i>',
    ['check-applications', 'id' => $request->request_id],
    [
        'class' => 'btn btn-success', // green button for “accept”
        'title' => 'Accept',
        'data-toggle' => 'tooltip',
        'escape' => false              // allow the <i> tag
    ]
) ?>

        <?php endif; ?>
        <?php if (in_array($request->status, ['answered', 'created', 'po_loaded'])) {
            echo Html::a('<i class="bi bi-pencil"></i>', ['update', 'id' => $request->request_id], [
                'class' => 'btn btn-primary',
                'title' => 'Update',
                'data-toggle' => 'tooltip'
            ]);
            echo Html::a('<i class="bi bi-trash"></i>', ['delete', 'id' => $request->request_id], [
                'class' => 'btn btn-secondary',
                'title' => 'Delete',
                'data-toggle' => 'tooltip',
                'data' => [
                    'confirm' => 'Are you sure you want to delete this item?',
                    'method' => 'post',
                ],
            ]);
        } ?>
    </div>
</li>

<?php endif; ?>


<?php if (!Yii::$app->user->isGuest && Yii::$app->session->get('user_type') === 'mrox'): ?>

<li class="list-group-item d-flex justify-content-between align-items-center">
    <div class="d-flex flex-column"> <!-- Container for attachments -->
        <strong>Actions:</strong>
    </div>

<div class="ml-auto d-flex gap-1"> <!-- Container for work packs and CRS on the right -->

    <?= Html::a('<i class="bi bi-check2-circle"></i>', ['mro-requests/apply', 'id' => $request->request_id], [
        'class' => 'btn btn-info',
        'title' => 'Apply',
        'data-toggle' => 'tooltip'
    ]) ?>

    <?= Html::a('<i class="bi bi-person-plus"></i>', ['mro-requests/recommend-mro', 'id' => $request->request_id], [
        'class' => 'btn btn-secondary',
        'title' => 'Recommend Other MRO',
        'data-toggle' => 'tooltip'
    ]) ?>

</div>

</li>
<?php endif; ?>


                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Request informations:</strong>
                    <?= Html::encode($request->request_details) ?>
                </li>
            
              


            </ul>

                <div class="row">
                    <a href="javascript:void(0);" class="btn btn-primary" onclick="window.history.back();">Back to Requests</a>
                </div>


        </div>
    </div>
</main>
