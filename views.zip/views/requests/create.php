<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;
use app\models\Aircrafts;
use app\models\Airports;
use kartik\datetime\DateTimePicker;

$this->title = 'Create Request';


?>
<style>


</style>




<main class="dash-content">
    <div class="container-fluid">
<!-- Multi-step progress bar -->
<div class="progress-bar-container">
   <span class="progress-bar-step step-active">Create a Request</span>
    <span class="progress-bar-step ">MRO Quote</span>
    <span class="progress-bar-step ">PO Loaded</span>
    <span class="progress-bar-step ">PO Accepted By MRO</span>
    <span class="progress-bar-step">Work Started</span>
    <span class="progress-bar-step">MRO Report</span>
    <span class="progress-bar-step ">AO Feedback</span>
    <span class="progress-bar-step">Request Closed</span>
</div>
</br>
        <h1 class="dash-title">Create Request</h1>

        <?php
        if (Yii::$app->session->hasFlash('success')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
        }

        if (Yii::$app->session->hasFlash('error')) {
            echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
        }
        ?>
        <?php $form = ActiveForm::begin(['id' => 'create-request-form',     'options' => ['class' => 'background-form'], // add a class
]); ?>

        <div id="loading-spinner" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999;">
    <img src="<?= Yii::getAlias('@web/img/spinner.gif') ?>" alt="Loading..." />
</div>

        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($request, 'aircraft_id')->dropDownList(
                        ArrayHelper::map(
                            Aircrafts::find()
                                ->where(['ao_id' => Yii::$app->session->get('ao_id')])
                                ->all(),
                            'aircraft_id',
                            function($model) {
                                return $model->manufacturer . ' - ' . $model->model . ' - ' . $model->serial_number . ' - ' . $model->registration_number. ' - ' . $model->getCertificateType()->one()->type;
                            }
                        ),
                        ['prompt' => 'Select Aircraft', 'id' => 'aircraft-dropdown']
                        )->label("Aircraft" . '<span class="text-danger">*</span>') ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($request, 'aircraft_registration')->textInput(['maxlength' => true, 'disabled' => true, 'id' => 'aircraft-registration']) ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($request, 'serial_number')->textInput(['maxlength' => true, 'disabled' => true, 'id' => 'serial-number']) ?>
                </div>
            </div>
        </div>
        <div class="row">
    <div class="form-group">
        <div class="col-lg-6">
            <?= $form->field($request, 'required_certificates')->textInput(['maxlength' => true, 'disabled' => true, 'id' => 'required-certificates'])->label("National Aviation Authority" ) ?>
        </div>
    </div>
</div>

        <div class="row" id="destination-row">
            <div class="form-group">
                <div class="col-lg-6">
                <?= $form->field($request, 'destination')->widget(Select2::classname(), [
    'options' => [
        'placeholder' => 'Type to search for an airport',
        'id' => 'destination-dropdown',
    ],
    'pluginOptions' => [
        'allowClear' => true,
        'minimumInputLength' => 3,
        'ajax' => [
            'url' => \yii\helpers\Url::to(['requests/search-airports']),
            'dataType' => 'json',
            'delay' => 250, // Delay for the debounce
            'data' => new \yii\web\JsExpression('function(params) { return { term: params.term }; }'),
            'processResults' => new \yii\web\JsExpression('function(data) {
                return {
                    results: data
                };
            }'),
        ],
        'escapeMarkup' => new \yii\web\JsExpression('function(markup) { return markup; }'),
        'templateResult' => new \yii\web\JsExpression('function(data) { return data.text; }'),
        'templateSelection' => new \yii\web\JsExpression('function(data) { return data.text; }'),
    ],
])->label("ICAO (Airport)" . '<span class="text-danger">*</span>') ?>

                </div>
            </div>
        </div>

        <?= $form->field($request, 'aircraft_registration')->hiddenInput(['id' => 'aircraftregistration'])->label(false) ?>
        <?= $form->field($request, 'serial_number')->hiddenInput(['id' => 'serialnumber'])->label(false) ?>
        <?= $form->field($request, 'required_certificates')->hiddenInput(['id' => 'requiredcertificates'])->label(false) ?>


        <?php
$this->registerJs('
    document.getElementById("aircraft-dropdown").addEventListener("change", function() {
        var selectedAircraft = this.options[this.selectedIndex];
        var aircraftText = selectedAircraft.textContent;

        console.log("Selected Aircraft Text: ", aircraftText); // Debugging line

        // Split the text content to extract relevant parts
        var parts = aircraftText.split(" - ");
        var aircraftRegistration = parts[3] || ""; // Fallback to empty string if undefined
        var aircraftSerialNumber = parts[2] || ""; // Fallback to empty string if undefined
        var certificateType = parts[4] || ""; // Fallback to empty string if undefined



        // Populate input fields with extracted values
        document.getElementById("aircraft-registration").value = aircraftRegistration;
        document.getElementById("serial-number").value = aircraftSerialNumber;
        document.getElementById("required-certificates").value = certificateType; // Updated to use the correct attribute name
        document.getElementById("serialnumber").value = aircraftSerialNumber;
        document.getElementById("aircraftregistration").value = aircraftRegistration;
    });
');
?>




<div class="row">
    <div class="form-group">
        <div class="col-lg-6">
            <?= $form->field($request, 'eta')->widget(DateTimePicker::class, [
                'options' => ['placeholder' => 'Select date and time...'],
                'pluginOptions' => [
                    'format' => 'dd M yyyy hh:ii',
                    'autoclose' => true,
                    'todayHighlight' => true
                ]
            ])->label($request->getAttributeLabel('eta') . '<span class="text-danger">*</span>') ?>
        </div>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <div class="col-lg-6">
            <?= $form->field($request, 'etd')->widget(DateTimePicker::class, [
                'options' => ['placeholder' => 'Select date and time...', 'id' => 'etd'],
                'pluginOptions' => [
                    'format' => 'dd M yyyy hh:ii',
                    'autoclose' => true,
                    'todayHighlight' => true
                ]
            ])->label($request->getAttributeLabel('etd') . '<span class="text-danger">*</span>') ?>
        </div>
    </div>
</div>
        <div class="row">
                <div class="form-group">
            <div class="col-lg-6">
            <?= $form->field($request, 'attachment')->fileInput(['accept' => 'image/*'])->label($request->getAttributeLabel('attachment') ) ?>
            </div>
        </div>
<div class="row">
    <div class="form-group">
        <div class="col-lg-6">
            <?= $form->field($request, 'request_details')->textarea([
                'rows' => 12, // You can adjust the number of rows as needed
            ])->label($request->getAttributeLabel('request_details') . '<span class="text-danger">*</span>') ?>
        </div>
    </div>
</div>



        </div>

        
       





        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($request, 'status')->hiddenInput(['value' => 'created'])->label(false) ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($request, 'ao_id')->hiddenInput(['value' => Yii::$app->session->get('ao_id')])->label(false) ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="form-group col-lg-8">
                <div class="row">
                    <div class="col-lg-6">
                        <?= Html::submitButton('Create Request', ['class' => 'btn btn-primary','id' => 'submit-button']) ?>
                    </div>
                    <div class="col-lg-2">
                        <?= Html::a('Back to Requests', ['index'], ['class' => 'btn btn-primary']) ?>
                    </div>
                </div>
            </div>
        </div>



        <?php ActiveForm::end(); ?>
    </div>
</main>
<?php
$this->registerJs('
var submitButton = document.getElementById("submit-button");
var loadingIndicator = document.getElementById("loading-spinner");
console.log(loadingIndicator);
if (submitButton) {
    submitButton.addEventListener("click", function() {
        this.disabled = true; // Disable the button
        loadingIndicator.style.display = "block"; // Show the loading indicator
        this.form.submit(); // Submit the form
    });
}
');

?>
<?php
$this->registerJs('

document.getElementById("create-request-form").addEventListener("submit", function(event) {
    var eta = document.getElementById("eta").value;
    var etd = document.getElementById("etd").value;

    if (eta && etd && new Date(etd) <= new Date(eta)) {
        document.getElementById("etd").value = null;
        var eta = document.getElementById("eta").value = null;

        event.preventDefault();
        alert("ETD must be after ETA.");
    }
});

document.getElementById("same-location-checkbox").addEventListener("change", function() {
    var locationRow = document.getElementById("location-row");
    var locationField = document.getElementById("location-field");
    var destinationField = document.getElementById("destination-dropdown");

    if (this.checked) {
        locationRow.style.display = "none";
        locationField.value = destinationField.options[destinationField.selectedIndex].text;
    } else {
        locationRow.style.display = "block";
        locationField.value = "";
    }
});


');
?>
