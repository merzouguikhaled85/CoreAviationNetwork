<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Load PO File';
$this->params['breadcrumbs'][] = ['label' => 'Requests', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<h1><?= Html::encode($this->title) ?></h1>
</br>

<!-- Multi-step progress bar -->
<div class="progress-bar-container">
  <span class="progress-bar-step ">Create a Request</span>
    <span class="progress-bar-step ">MRO Quote</span>
    <span class="progress-bar-step step-active">PO Loaded</span>
    <span class="progress-bar-step ">PO Accepted By MRO</span>
    <span class="progress-bar-step">Work Started</span>
    <span class="progress-bar-step">MRO Report</span>
    <span class="progress-bar-step ">AO Feedback</span>
    <span class="progress-bar-step">Request Closed</span>
</div>
</br>
<div class="ao-request-form" style="margin-left: 20px;">
    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($aoRequest, 'po')->fileInput(['accept' => 'application/pdf'])->label('PO' . '<span class="text-danger">*</span>') ?>
    <?= $form->field($aoRequest, 'request_id')->hiddenInput(['value' => $aoRequest->request_id])->label(false) ?>
    <div class="form-group">
<label ><strong> Check Certificate : </strong></label>
            
    <?= Html::a('Check Certificate', '#', ['class' => '', 'id' => 'check-certificate-link']) ?>
    </div>
    <div class="form-group ">
        <div class="form-check">
            <input type="checkbox" class="form-check-input"  id="acknowledgment-checkbox">
            <label class="form-check-label background-form" for="acknowledgment-checkbox">
              By proceeding, I confirm that I have conducted all necessary checks to ensure that the maintenance organisation’s certificates and approvals are appropriate for the scope of work to be undertaken. While this platform may carry out checks from time to time, it does not guarantee the accuracy or applicability of such documentation.
            </label>
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Upload', ['class' => 'btn btn-primary', 'id' => 'submit-button']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>

<!-- Modal for displaying certificate information -->
<div class="modal fade" id="certificateModal" tabindex="-1" role="dialog" aria-labelledby="certificateModalLabel" aria-hidden="true" <?= $certificateModal ? 'style="display: block;"' : '' ?>>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="certificateModalLabel">MRO Certificate Information</h5>
                <button type="button" class="close" id="modal-close-button" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Certificate information will be populated here -->
                <?php if ($mroCertificate): ?>
                    <h4>NAA certificate</h4>
                    <p><strong>Certificate ID:</strong> <?= Html::encode($mroCertificate->certificate_id) ?></p>
                    <p><strong>Certificate NAA:</strong> <?= Html::encode($mroCertificate->type) ?></p>
                    <p><strong>Certificate File:</strong> <?= $mroCertificate->certificate ? Html::a(Html::encode('View Certificate'), Yii::getAlias('@web') . '/' . $mroCertificate->certificate, ['target' => '_blank']) : 'N/A' ?></p>
              
                    <?php endif; ?>
                        <?php if ($mroAircraftCertificate): ?>
                    <h4>Aircraft Model certificate</h4>
                    <p><strong>Certificate ID:</strong> <?= Html::encode($mroAircraftCertificate->aircraft_certificate_id) ?></p>
                    <p><strong>Certificate Manufacturer:</strong> <?= Html::encode($mroAircraftCertificate->getAircraftModel()->one()->manufacturer) ?></p>
                    <p><strong>Certificate Type:</strong> <?= Html::encode($mroAircraftCertificate->getAircraftModel()->one()->model) ?></p>
                    <p><strong>Certificate File:</strong> <?= $mroAircraftCertificate->certificate ? Html::a(Html::encode('View Certificate'), Yii::getAlias('@web') . '/' . $mroAircraftCertificate->certificate, ['target' => '_blank']) : 'N/A' ?></p>
              
                    <?php else: ?>
                    <p>Certificate not found.</p>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" id="modal-close-footer-button">Close</button>
            </div>
        </div>
    </div>
</div>

<?php
$js = <<<JS
$(document).ready(function() {
    $('#submit-button').on('click', function(e) {
        if (!$('#acknowledgment-checkbox').is(':checked')) {
            alert('You must acknowledge the certification and approval requirement before submitting.');
            return false; // Prevent form submission
        }
    });
    $('#check-certificate-link').on('click', function(e) {
        e.preventDefault(); // Prevent the default link behavior
        $('#certificateModal').modal('show');
    });

    $('#modal-close-button, #modal-close-footer-button').on('click', function() {
        $('#certificateModal').modal('hide');
    });

    // Show modal if $certificateModal is true
    var certificateModal = '{$certificateModal}';
    if (certificateModal === "1") {
        $('#certificateModal').modal('show');
    }
});
JS;
$this->registerJs($js);
?>
