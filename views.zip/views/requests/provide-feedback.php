<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Provide Feedback';
$this->params['breadcrumbs'][] = ['label' => 'View Reports', 'url' => ['view-reports', 'id' => $report->getRequest()->request_id]];
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
.stars_holder {
    display: flex;
    flex-direction: row; /* Ensure items flow from left to right */
}

.stars {
    display: flex;
    flex-direction: row-reverse; /* Ensure items flow from left to right */
}

.stars input[type="radio"] {
    display: none; /* Hide the radio inputs */
}

.stars label {
    font-size: 50px;
    color: #ddd;
    padding: 5px;
    cursor: pointer;
}

.stars label:before {
    content: '\2605'; /* Unicode character for star */
}

.stars input[type="radio"]:checked~label {
    color: #f8d150; /* Color of selected stars */
}

.stars label:hover {
    color: #f8d150; /* Color of stars on hover */
}

.containers {
    margin-top: -50px;
    margin-left: 30px;
}
</style>

<h1><?= Html::encode($this->title) ?></h1>
<!-- Multi-step progress bar -->
<div class="progress-bar-container">
 <span class="progress-bar-step ">Create a Request</span>
    <span class="progress-bar-step ">MRO Quote</span>
    <span class="progress-bar-step ">PO Loaded</span>
    <span class="progress-bar-step ">PO Accepted By MRO</span>
    <span class="progress-bar-step">Work Started</span>
    <span class="progress-bar-step">MRO Report</span>
    <span class="progress-bar-step ">AO Feedback</span>
    <span class="progress-bar-step step-active">Request Closed</span>
</div>
<br>
<div class="row">
    <div class="col-md-12 containers">
        <?php $form = ActiveForm::begin(); ?>
        <table>
        <!-- Hidden input for "Kept to agreed schedule rating" -->
        <?= $form->field($feedback, 'kept_to_agreed_schedule_rating')->hiddenInput(['id' => 'kept_to_agreed_schedule_rating'])->label(false) ?>
        <!-- Star rating section for "Kept to agreed schedule rating" -->
        <div class="stars_holder">
            <tr>
            <td><h4>Capability & Certifications: <span class="text-danger">*</span><h6>Type Approvals, Scope of Services, and Experience with Your Fleet. </h6></h4></td>

            <td>
            <div class="stars" id="kept-to-agreed-schedule-rating-input">
                <input type="radio" id="schedule-star1" name="schedule-star" value="5" /><label for="schedule-star1"></label>
                <input type="radio" id="schedule-star2" name="schedule-star" value="4" /><label for="schedule-star2"></label>
                <input type="radio" id="schedule-star3" name="schedule-star" value="3" /><label for="schedule-star3"></label>
                <input type="radio" id="schedule-star4" name="schedule-star" value="2" /><label for="schedule-star4"></label>
                <input type="radio" id="schedule-star5" name="schedule-star" value="1" /><label for="schedule-star5"></label>
            </div>
            </td>
            </tr>
        </div>

        <!-- Hidden input for "Kept to agreed cost rating" -->
        <?= $form->field($feedback, 'kept_to_agreed_cost_rating')->hiddenInput(['id' => 'kept_to_agreed_cost_rating'])->label(false) ?>

        <!-- Star rating section for "Kept to agreed cost rating" -->
        <div class="stars_holder">
            <tr>
            <td><h4>Turnaround Time & Reliability: <span class="text-danger">*</span><h6>Service Efficiency, AOG Support, and Location & Logistics. </h6></h4></td>
            <td>
            <div class="stars" id="kept-to-agreed-cost-rating-input">
                <input type="radio" id="cost-star1" name="cost-star" value="5" /><label for="cost-star1"></label>
                <input type="radio" id="cost-star2" name="cost-star" value="4" /><label for="cost-star2"></label>
                <input type="radio" id="cost-star3" name="cost-star" value="3" /><label for="cost-star3"></label>
                <input type="radio" id="cost-star4" name="cost-star" value="2" /><label for="cost-star4"></label>
                <input type="radio" id="cost-star5" name="cost-star" value="1" /><label for="cost-star5"></label>
            </div>
            </td>
            </tr>
        </div>

        <!-- Hidden input for "Overall communication rating" -->
        <?= $form->field($feedback, 'overall_communication_rating')->hiddenInput(['id' => 'overall_communication_rating'])->label(false) ?>

        <!-- Star rating section for "Overall communication rating" -->
        <div class="stars_holder">
            <tr>
            <td><h4>Pricing & Contract Terms: <span class="text-danger">*</span><h6>Cost Transparency, Warranty & Support, and Regulatory Compliance. </h6></h4></td>
            </td>
            <td>
            <div class="stars" id="overall-communication-rating-input">
                <input type="radio" id="communication-star1" name="communication-star" value="5" /><label for="communication-star1"></label>
                <input type="radio" id="communication-star2" name="communication-star" value="4" /><label for="communication-star2"></label>
                <input type="radio" id="communication-star3" name="communication-star" value="3" /><label for="communication-star3"></label>
                <input type="radio" id="communication-star4" name="communication-star" value="2" /><label for="communication-star4"></label>
                <input type="radio" id="communication-star5" name="communication-star" value="1" /><label for="communication-star5"></label>
            </div>
            </td>
            </tr>
        </div>
        </table>

        <?= $form->field($feedback, 'feedback_text')->textarea(['rows' => 6])->label('Feedback (Optional)') ?>

        <div class="form-group">
            <?= Html::submitButton('Submit Feedback', ['class' => 'btn btn-primary', 'id' => 'submit-feedback-btn']) ?>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
</div>

<?php
$js = <<<JS
$(document).ready(function() {
    // Function to update "Kept to agreed schedule rating" hidden input
    $('#kept-to-agreed-schedule-rating-input input[type="radio"]').change(function() {
        var rating = $(this).val();
        $('#kept_to_agreed_schedule_rating').val(rating);
    });

    // Function to update "Kept to agreed cost rating" hidden input
    $('#kept-to-agreed-cost-rating-input input[type="radio"]').change(function() {
        var rating = $(this).val();
        $('#kept_to_agreed_cost_rating').val(rating);
    });

    // Function to update "Overall communication rating" hidden input
    $('#overall-communication-rating-input input[type="radio"]').change(function() {
        var rating = $(this).val();
        $('#overall_communication_rating').val(rating);
    });

    // Validate form before submission
    $('#submit-feedback-btn').click(function(e) {
        // Check if all star ratings are selected
        if (!$('#kept_to_agreed_schedule_rating').val() || 
            !$('#kept_to_agreed_cost_rating').val() || 
            !$('#overall_communication_rating').val()) {
            e.preventDefault(); // Prevent form submission if ratings are not selected
            alert('Please select ratings for all fields.');
        }
    });
});
JS;
$this->registerJs($js);
?>
