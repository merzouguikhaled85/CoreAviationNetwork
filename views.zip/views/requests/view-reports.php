<?php

use yii\helpers\Html;

$this->title = 'View CRS';
$this->params['breadcrumbs'][] = ['label' => 'Requests', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $request->request_id, 'url' => ['view', 'id' => $request->request_id]];
$this->params['breadcrumbs'][] = $this->title;

?>
<style>
    .report-column {
        width: 30%!important; /* Makes the column three times wider */
        max-width: 300px; /* Adjust this value as needed */
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .report-column:hover {
        overflow: visible;
        white-space: normal;
    }
</style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<script>
document.addEventListener('DOMContentLoaded', function () {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
});
</script>
<h1><?= Html::encode($this->title) ?></h1>
<?php
        if (Yii::$app->session->hasFlash('success')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
        }
        if (Yii::$app->session->hasFlash('error')) {
            echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
        }
        ?>
<div class="row">
    <div class="col-md-12">
        <h3>Request Details</h3>
        <table class="table table-bordered">
            <tr>
                <th>Request ID <?= Html::encode($request->request_id) ?></th>
            </tr>
            <!-- Add more details as needed -->
        </table>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <h3>CRS Report</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>CRS ID</th>
                    <th>MRO</th>
                    <th class="report-column">Report</th>
                    <th>CRS Attachment</th>
                    <th>Actions</th>
                    <!-- Add more columns as needed -->
                </tr>
            </thead>
            <tbody>
                <?php foreach ($repairReports as $report): ?>
                    <tr>
                         <td><?= $report->repair_report_id ?></td>
                         <td><?= $report->getMro()->username ?></td>
                        <td class="report-column"><?= Html::encode($report->report) ?></td>
                        <td>
                                <?= Html::a('Download Attachment', Yii::getAlias('@web/uploads/')  . $report->CRS_attachment, ['target' => '_blank']) ?>
                    
                        </td>

                                           
                      <td>
    <?php
    $existingDescription = \app\models\RepairReport::find()
        ->where(['mro_request_apply_id' => $report->mro_request_apply_id])
        ->andWhere(['not', ['AO_description' => null]])
        ->exists();
    ?>

    <?php if (
        $report->getRequest()->status != 'closed' &&
        ($report->quote_approved != 0 || $report->quote_approved === null) &&
        $report->CRSed != 0
    ): ?>
        <?php \yii\widgets\ActiveForm::begin([
            'method' => 'post',
            'action' => ['view-reports', 'id' => $request->request_id],
            'options' => ['style' => 'display:inline']
        ]); ?>
            <?= Html::hiddenInput('report_id', $report->repair_report_id) ?>
<?= Html::submitButton('<i class="bi bi-check-lg"></i>', [
    'class' => 'btn btn-primary btn-sm',
    'name' => 'approve',
    'value' => 'yes',
    'title' => 'Accept',
    'data-toggle' => 'tooltip'
]) ?>

        <?php \yii\widgets\ActiveForm::end(); ?>

        <?php \yii\widgets\ActiveForm::begin([
            'method' => 'post',
            'action' => ['view-reports', 'id' => $request->request_id],
            'options' => ['style' => 'display:inline']
        ]); ?>
            <?= Html::hiddenInput('report_id', $report->repair_report_id) ?>
<?= Html::submitButton('<i class="bi bi-arrow-repeat"></i>', [
    'class' => 'btn btn-secondary btn-sm',
    'name' => 'approve',
    'value' => 'no',
    'title' => 'Request CRS Change',
    'data-toggle' => 'tooltip'
]) ?>

        <?php \yii\widgets\ActiveForm::end(); ?>
    <?php endif; ?>

    <?php if ($report->mro_quote && $report->getRequest()->status != 'closed') : ?>
        <?= Html::a('Approve Quote', ['approve-quote', 'id' => $report->repair_report_id], ['class' => 'btn btn-info btn-sm']) ?>
    <?php endif; ?>

    <?php
    $existingfeedback = \app\models\Feedback::find()
        ->where(['request_id' => $report->getRequest()->request_id])
        ->exists();
    ?>

    <?php if (
        $report->getRequest()->status == 'closed' &&
        !$existingfeedback &&
        $report->quote_approved == 1
    ) : ?>
<?= Html::a('<i class="bi bi-chat-dots"></i>', ['provide-feedback', 'id' => $report->repair_report_id], [
    'class' => 'btn btn-secondary btn-sm',
    'title' => 'Provide Feedback',
    'data-toggle' => 'tooltip'
]) ?>
    <?php endif; ?>
</td>
                        <!-- Add more cells as needed -->
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
