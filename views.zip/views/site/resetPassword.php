<?php 
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Reset Password';
?>

<h1><?= Html::encode($this->title) ?></h1>

<div class="reset-password-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'password')->passwordInput() ?>

    <?= $form->field($model, 'confirm_password')->passwordInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
