<?php

use yii\helpers\Html;
use yii\helpers\Url;

use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\bootstrap5\Modal;
use kartik\select2\Select2;


$this->title = 'MRO Signup';
$this->params['breadcrumbs'][] = $this->title;

?>
<style>
.is-invalid {
    border-color: #ff0000 !important; /* your custom red */
}
    .help-block {
    border-color: #ff4d4d!important;
}
.help-block {
    color: #ff4d4d!important;
}
</style>
<div class="container">
<br>
    <h1><?= Html::encode($this->title) ?></h1>

<br><br>
    <div class="row">
        <div class="col-md-8">
            <div class="ao-profiles-form">
                        <!-- Flash Messages -->
        <?php if (Yii::$app->session->hasFlash('message')): ?>
    <div class="alert alert-success">
        <?= Yii::$app->session->getFlash('message') ?>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('usernameError')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('usernameError') ?>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('passwordError')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('passwordError') ?>
    </div>
<?php endif; ?>
                <?php $form = ActiveForm::begin(['options' => ['class' => 'row g-3','enctype' => 'multipart/form-data' ]]); ?>
                <?= \yii\helpers\Html::hiddenInput(Yii::$app->request->csrfParam, Yii::$app->request->csrfToken) ?>

                <!-- Step 1: User Information -->
                <div id="step-1">
                    <div class="col-md-8">
                        <?= $form->field($model, 'username')->textInput(['maxlength' => false, 'class' => 'form-control form-control-lg'])->label('Username'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'password')->passwordInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'password'])->label('Password'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'confirm_password')->passwordInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'confirm_password'])->label('Confirm Password'. '<span class="text-danger">*</span>') ?>
                        <div id="confirm-password-error" class="error-message" style="display: none;"></div>
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'email')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'email'])->label('Email'. '<span class="text-danger">*</span>') ?>
                        <div class="error-message" id="email-error" style="display: none;"></div>
                    </div>

                    <div class="col-8">
                        <button type="button" class="btn btn-primary" id="next-step-1">Next</button>
                    </div>
                </div>

                <!-- Step 2: Personal Information -->
                <div id="step-2" style="display: none;">
                    <div class="col-8">
                        <?= $form->field($model, 'first_name')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg','id' => 'first_name'])->label('First Name'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'last_name')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg','id' => 'last_name'])->label('Last Name'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'contact_number')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg','id' => 'contact_number'])->label('Contact Number'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'profile_photo')->fileInput(['class' => 'form-control form-control-lg', 'accept' => 'image/*'])->label('Profile Photo') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'company_name')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg','id' => 'company_name'])->label('Company Name'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'company_photo')->fileInput(['class' => 'form-control form-control-lg', 'accept' => 'image/*'])->label('Company Photo') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'country_id')->dropDownList(
                            ArrayHelper::map($countries, 'country_id', 'country_name'),
                            [
                                'prompt' => 'Select Country',
                                'id' => 'country-select',
                                'class' => 'form-select form-select-lg'
                            ])->label('Country'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'city_id')->dropDownList(
                            [],
                            [
                                'prompt' => 'Select City',
                                'id' => 'city-select',
                                'class' => 'form-select form-select-lg'
                            ])->label('City'. '<span class="text-danger">*</span>') ?>
                        <div id="selected-city-value" class="selected-city-value"></div> <!-- Add this line -->
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'address')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'address'])->label('Address' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-8">
    <?= $form->field($model, 'zip_code')->textInput([
        'maxlength' => true,
        'class' => 'form-control form-control-lg',
        'id' => 'zip_code'
    ])->label('Zip Code' . '<span class="text-danger">*</span>') ?>
</div>

                    <div class="col-8 d-flex justify-content-between">
                        <button type="button" class="btn btn-secondary" id="prev-step-2">Previous</button>
                        <button type="button" class="btn btn-primary" id="next-step-2">Next</button>

                    </div>
                </div>

                <!-- Step 3: Certificate Information and Terms -->
                <div id="step-3" style="display: none;">
                    <div class="col-md-8">
                    <h4>NAA</h4>

                        <?= $form->field($certificate, 'certificate')->fileInput(['class' => 'form-control form-control-lg','maxlength' => true, 'accept' => '.pdf', 'id' => 'naa'])->label("NAA Certificate" . '<span class="text-danger">* (Max file size 5 Mb)</span>') ?>
                    </div>

            <div class="col-md-8">
            <h4>Insurance Documents</h4>
                <?= $form->field($model, 'insurance_document')->fileInput(['class' => 'form-control form-control-lg', 'id' => 'insurance','maxlength' => true, 'accept' => '.pdf'])->label($model->getAttributeLabel('insurance_document') . '<span class="text-danger"> * (Max file size 5 Mb)</span>') ?>
            </div>
<div class="col-md-8">
    <?= $form->field($certificate, 'type')->dropDownList(
        ArrayHelper::map(
            \app\models\CertificateTypes::find()
                ->orderBy(['type' => SORT_ASC]) // ✅ Alphabetical order
                ->all(),
            'type',
            'type'
        ),
        ['prompt' => 'Select Type', 'id' => 'certificate-type-dropdown']
    )->label('NAA' . '<span class="text-danger">*</span>') ?>
</div>

                    <?= $form->field($certificate, 'certificate_type_id')->hiddenInput()->label(false) ?>

                    <div class="col-lg-8">
                    <h4>Aircraft certificate</h4>

                    <?= $form->field($mroaircraftcertificate, 'manufacturer')->dropDownList(
                    ArrayHelper::map(\app\models\AircraftModel::find()->select('manufacturer')->distinct()->all(), 'manufacturer', 'manufacturer'),
                    [
                        'prompt' => 'Select Manufacturer',
                        'id' => 'manufacturer-dropdown',
                    ]
                )->label('Manufacturer<span class="text-danger">*</span>') ?>
                                    </div>

                    <div class="col-lg-8">
                    <?= $form->field($mroaircraftcertificate, 'aircraft_model_id')->dropDownList([], [
                    'prompt' => 'Select Aircraft Model',
                    'id' => 'model-dropdown',
                ])->label('Aircraft Model<span class="text-danger">*</span>') ?>                   
                 </div>
                    <div class="col-lg-8">
                    <?= $form->field($mroaircraftcertificate, 'certificate')->fileInput(['class' => 'form-control form-control-lg','id'=>'mroaircraftcertificate-certificate','maxlength' => true, 'accept' => '.pdf'])->label($certificate->getAttributeLabel('certificate') . '<span class="text-danger">* (Max file size 5 Mb)</span>') ?>            
                    </div>



                    <div class="col-lg-8">
                    <h4>Airport</h4>

                    <?= $form->field($mroairport, 'airport_id')->widget(Select2::classname(), [
    'options' => ['placeholder' => 'Select Airport'],
    'pluginOptions' => [
        'allowClear' => true,
        'minimumInputLength' => 2,  // Require at least 2 characters before search
        'ajax' => [
            'url' => \yii\helpers\Url::to(['site/airport-search']),
            'dataType' => 'json',
            'data' => new \yii\web\JsExpression('function(params) { return {q:params.term}; }'),
            'processResults' => new \yii\web\JsExpression('function(data) { return {results: data.results}; }'),
        ],
    ],
])->label($mroairport->getAttributeLabel('airport_name') . '<span class="text-danger">*</span>') ?>



                    <!-- Display Terms -->
                    <div class="col-10">
                        <div class="form-check">
                            <?= Html::checkbox('terms', false, ['class' => 'form-check-input', 'id' => 'terms-check']) ?>
                            <?= Html::label('I agree to the terms and conditions <span class="text-danger">*</span> ', null, ['class' => 'form-check-label']) ?>
                            <?= Html::button('Show Terms', ['class' => 'btn btn-primary', 'id' => 'show-terms-btn']) ?>
                        </div>
                        <div class="terms-content" style="display: none;">
                            <?= $terms ?>
                        </div>
                    </div>

                    <div class="col-8 d-flex justify-content-between">
                        <button type="button" class="btn btn-secondary" id="prev-step-3">Previous</button>
                        <?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'id' => 'submit-btn', 'disabled' => true]) ?>

                    </div>
                </div>

                <?php ActiveForm::end(); ?>
            </div>
        </div>

    </div>
</div>

<?php
$this->registerJs("
    // File size validation for all three file inputs
    function validateFileSize(inputId) {
        var fileInput = document.getElementById(inputId);
        fileInput.addEventListener('change', function(event) {
            var file = event.target.files[0];
            if (file && file.size > 5242880) { // 5MB = 5 * 1024 * 1024 = 5242880 bytes
                alert('The file size exceeds the 5MB limit.');
                event.target.value = ''; // Clear the file input
            }
        });
    }

    // Validate file size for each input
    validateFileSize('naa');
    validateFileSize('insurance');
    validateFileSize('mroaircraftcertificate-certificate');

    // Existing dropdown change logic
    $('#certificate-type-dropdown').change(function() {
        var selectedType = $(this).val();
        $.ajax({
            url: '" . \yii\helpers\Url::to(['certificate-types/get-certificate-type-id']) . "',
            type: 'GET',
            data: {type: selectedType},
            success: function(data) {
                $('#certificates-certificate_type_id').val(data.certificate_type_id); // Set 'certificate_type_id' field value
            },
            error: function() {
                alert('Error fetching certificate type ID.');
            }
        });
    });
");
?>
<?php
$this->registerJs("
    $('#manufacturer-dropdown').change(function() {
        var selectedManufacturer = $(this).val();
        $.ajax({
            url: '" . Url::to(['mro-aircraft-certificates/get-models-by-manufacturer']) . "',
            type: 'GET',
            data: { manufacturer: selectedManufacturer },
            success: function(data) {
                var modelDropdown = $('#model-dropdown');
                modelDropdown.empty(); // Clear previous options
                modelDropdown.append('<option value=\"\">Select Aircraft Model</option>');

                $.each(data, function(index, model) {

                    modelDropdown.append('<option value=\"' + model.id + '\">' + model.name + '</option>');
                });
            },
            error: function(xhr, status, error) {
                console.error('Error fetching models:', error);
                alert('Error fetching models. Please check console for details.');
            }
        });
    });

   
");
?>
<?php
$this->registerJs("
    // Step Navigation
    $('#next-step-1').click(function() {
        var username = $('#mroprofile-username').val();
        var password = $('#password').val();
        var confirmPassword = $('#confirm_password').val();
        var email = $('#email').val();
        var isValid = true;

        // Validate Step 1
        if (username === '' || password === '' || confirmPassword === '' || email === '') {
            isValid = false;
            alert('Please fill in all required fields.');
        } else if (password !== confirmPassword) {
            isValid = false;
            alert('Passwords do not match.');
        }

        if (isValid) {
            $('#step-1').hide();
            $('#step-2').show();
        }
    });

    $('#prev-step-2').click(function() {
        $('#step-2').hide();
        $('#step-1').show();
    });

    $('#next-step-2').click(function() {
    
    
    var firstname = $('#first_name').val(); 
    var lastname = $('#last_name').val(); 
    var companyname = $('#company_name').val(); 
    var contactnumber = $('#contact_number').val(); 


    var countryId = $('#country-select').val();
    var cityId = $('#city-select').val();
    var address = $('#address').val();
    var zip = $('#zip_code').val();
    var isValid = true;



    // Validate Step 2
    if (countryId === '' || cityId === '' || address === ''|| zip === '' || firstname === ''|| lastname === ''|| companyname === ''|| contactnumber === '') {
        isValid = false;
        alert('Please fill in all required fields.');
    }

    if (isValid) {
        $('#step-2').hide();
        $('#step-3').show();
    }
    });

    $('#prev-step-3').click(function() {
        $('#step-3').hide();
        $('#step-2').show();
    });

    // Show Terms
    $('#show-terms-btn').click(function() {
        $('.terms-content').toggle();
    });
  // Validate Step 3 fields before submission
    $('#submit-btn').click(function(e) {
        var naa = $('#naa').val();
        var insurance = $('#insurance').val();
        var manufacturer = $('#manufacturer-dropdown').val();
        var model = $('#model-dropdown').val();
        var certificateType = $('#certificate-type-dropdown').val();
        var aircraftCertificate = $('#mroaircraftcertificate-certificate').val(); // Aircraft certificate field ID
        var isValid = true;

        // Validate NAA, insurance, manufacturer, model, certificate type, and aircraft certificate
        if (naa === '') {
            isValid = false;
            alert('Please upload the NAA certificate.');
        } else if (insurance === '') {
            isValid = false;
            alert('Please upload the insurance document.');
        } else if (manufacturer === '') {
            isValid = false;
            alert('Please select a manufacturer.');
        } else if (model === '') {
            isValid = false;
            alert('Please select an aircraft model.');
        } else if (certificateType === '') {
            isValid = false;
            alert('Please select a certificate type.');
        } else if (aircraftCertificate === '') {
            isValid = false;
            alert('Please upload the aircraft certificate.');
        }

        // Prevent form submission if any field is invalid
        if (!isValid) {
            e.preventDefault(); // Prevent the form from submitting
        }
    });


    // Enable Submit Button when Terms are Accepted
    $('#terms-check').change(function() {
        $('#submit-btn').prop('disabled', !this.checked);
    });
");
?>
<?php
// Register JavaScript to handle the city dropdown update and client-side validation
$script = <<<JS
    var citiesByCountry = $citiesByCountryJson;

    // Ensure country-select element exists before adding event listener
    var countrySelect = document.getElementById('country-select');
    var citySelect = document.getElementById('city-select');
    var selectedCityValue = document.getElementById('selected-city-value');

    if (countrySelect && citySelect  && selectedCityValue) {
    countrySelect.addEventListener('change', function() {
        var countryId = this.value;
        citySelect.innerHTML = '<option value="">Select City</option>'; // Reset city options

if (countrySelect && citySelect && selectedCityValue) {
    countrySelect.addEventListener('change', function() {
        var countryId = this.value;
        citySelect.innerHTML = '<option value="">Select City</option>';

        if (countryId) {
fetch('/web/site/get-cities?countryId=' + countryId)
                .then(response => response.json())
                .then(cities => {
                    cities.forEach(city => {
                        var option = document.createElement('option');
                        option.value = city.city_id;
                        option.textContent = city.city_name;
                        citySelect.appendChild(option);
                    });
                })
                .catch(err => console.error('Error loading cities:', err));
        }
    });
}

    });
}

JS;

$this->registerJs($script);
?>
