<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\bootstrap5\Modal;

$this->title = 'Aircraft Operator Signup';
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
.is-invalid {
    border-color: #ff0000 !important; /* your custom red */
}
    .help-block {
    border-color: #ff4d4d!important;
}
.help-block {
    color: #ff4d4d!important;
}
</style>
<div class="container" style=" padding-top: 30px!important;">
    <h1><?= Html::encode($this->title) ?></h1>



<br>
    <div class="row" >
        <div class="col-md-8">
            <div class="ao-profiles-form">
                        <!-- Flash Messages -->
        <?php if (Yii::$app->session->hasFlash('message')): ?>
    <div class="alert alert-success">
        <?= Yii::$app->session->getFlash('message') ?>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('usernameError')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('usernameError') ?>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('passwordError')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('passwordError') ?>
    </div>
<?php endif; ?>
                <?php $form = ActiveForm::begin(['options' => ['id' => 'ao-profile-form', 'class' => 'row g-3']]); ?>

                <!-- Step 1: Account Information -->
                <div id="step-1" class="step active">
                    <h3>Account Information</h3>
                    <div class="col-md-8">
                        <?= $form->field($model, 'username')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'username'])->label('Username' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'password')->passwordInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'password'])->label('Password' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'confirm_password')->passwordInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'confirm_password'])->label('Confirm Password' . '<span class="text-danger">*</span>') ?>
                        <div id="confirm-password-error" class="error-message" style="display: none;"></div>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'email')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'email'])->label('Email' . '<span class="text-danger">*</span>') ?>
                        <div id="email-error" class="error-message" style="display: none;"></div>
                    </div>
                    <button type="button" class="btn btn-primary" id="next-button">Next</button>


                </div>

                <!-- Step 2: Company Information -->
                <div id="step-2" class="step" style="display: none;">
                    <h3>Company Information</h3>
                    <div class="col-md-8">
                        <?= $form->field($model, 'company_name')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg'])->label('Company Name') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'profile_photo')->fileInput(['class' => 'form-control form-control-lg'])->label('Profile Photo') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'first_name')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg','id' => 'first_name'])->label('First Name' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'last_name')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg','id' => 'last_name'])->label('Last Name' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'contact_number')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg','id' => 'contact_number'])->label('Contact Number' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'country_id')->dropDownList(
                            ArrayHelper::map($countries, 'country_id', 'country_name'),
                            [
                                'prompt' => 'Select Country',
                                'id' => 'country-select',
                                'class' => 'form-select form-select-lg'
                            ])->label('Country'. '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($model, 'city_id')->dropDownList(
                            [],
                            [
                                'prompt' => 'Select City',
                                'id' => 'city-select',
                                'class' => 'form-select form-select-lg'
                            ])->label('City'. '<span class="text-danger">*</span>') ?>
                        <div id="selected-city-value" class="selected-city-value"></div> <!-- Add this line -->
                    </div>
                    <div class="col-8">
                        <?= $form->field($model, 'address')->textInput(['maxlength' => true, 'class' => 'form-control form-control-lg', 'id' => 'address'])->label('Address' . '<span class="text-danger">*</span>') ?>
                    </div>
                                        <div class="col-8">
    <?= $form->field($model, 'zip_code')->textInput([
        'maxlength' => true,
        'class' => 'form-control form-control-lg',
        'id' => 'zip_code'
    ])->label('Zip Code' . '<span class="text-danger">*</span>') ?>
</div>
                    <div class="col-8 d-flex justify-content-between">
                        <button type="button" class="btn btn-secondary" id="back-button-step-2">Back</button>
                        <button type="button" class="btn btn-primary" id="next-to-step-3-button">Next</button>
                    </div>

                </div>

                <!-- Step 3: Aircraft Information -->
                <div id="step-3" class="step" style="display: none;">
                    <h3>Aircraft Information</h3>
                    <div class="col-md-8">
                        <?= $form->field($airplaneModel, 'manufacturer')->dropDownList(
                            ArrayHelper::map($manufacturers, 'manufacturer', 'manufacturer'),
                            ['prompt' => 'Select Manufacturer', 'class' => 'form-select form-select-lg', 'id' => 'manufacturer', 'onchange' => 'updateModelDropdown(this.value)']
                        )->label('Manufacturer <span style="color: red;">*</span>', ['encode' => false]) ?>
 
                    </div>
                    <?= $form->field($airplaneModel, 'aircraft_model_id')->hiddenInput(['id' => 'aircraft-model-id'])->label(false) ?>

                    <div class="col-md-8">
                        <?= $form->field($airplaneModel, 'model')->dropDownList([], ['prompt' => 'Select Model', 'class' => 'form-select form-select-lg', 'id' => 'model-dropdown'])->label('Model' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($airplaneModel, 'serial_number')->textInput([ 'id' => 'serial_number'])->label('Serial Number' . '<span class="text-danger">*</span>') ?>
                    </div>
                    <div class="col-md-8">
                        <?= $form->field($airplaneModel, 'registration_number')->textInput([ 'id' => 'registration_number'])->label('Registration Number' . '<span class="text-danger">*</span>') ?>
                    </div>

                <div class="col-lg-8">
                    <?= $form->field($airplaneModel, 'certificate_type_id')->dropDownList(
                        ArrayHelper::map(\app\models\CertificateTypes::find()->orderBy(['type' => SORT_ASC])->all(), 'certificate_type_id', 'type'), // Displaying 'type' from CertificateTypes
                        [
                            'prompt' => 'Select Certificate Type',
                            'id' => 'certificate-type-dropdown',
                        ]
                    )->label($airplaneModel->getAttributeLabel('certificate_type_id') . '<span class="text-danger">*</span>') ?>
                </div>

                    <div class="col-8">
                        <div class="form-check">
                            <?= Html::checkbox('terms', false, ['class' => 'form-check-input', 'id' => 'terms-check']) ?>
                            <?= Html::label('I agree to the terms and conditions <span class="text-danger">*</span>', null, ['class' => 'form-check-label']) ?>
                            <?= Html::button('Show Terms', ['class' => 'btn btn-primary', 'id' => 'show-terms-btn']) ?>
                        </div>
                        <div class="terms-content" style="display: none;">
                            <?= $terms ?>
                        </div>
                    </div>
                    <div class="col-8 d-flex justify-content-between">
                        <button type="button" class="btn btn-secondary" id="back-button-step-3">Back</button>
                        <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
                    </div>

                </div>

                <?php ActiveForm::end(); ?>
            </div>
        </div>

    </div>
</div>

<!-- JavaScript for Multi-Step Form and Modal -->
<script>
    // Next button for navigating to the second step
    document.getElementById('next-button').addEventListener('click', function() {
        document.getElementById('step-1').style.display = 'none';
        document.getElementById('step-2').style.display = 'block';
    });

    // Next button for navigating to the third step
    document.getElementById('next-to-step-3-button').addEventListener('click', function() {
        document.getElementById('step-2').style.display = 'none';
        document.getElementById('step-3').style.display = 'block';
    });
    // Back button for navigating to the previous step in step 1
document.getElementById('back-button-step-2').addEventListener('click', function() {
    document.getElementById('step-1').style.display = 'block';
    document.getElementById('step-2').style.display = 'none';
});

// Back button for navigating to the previous step in step 2
document.getElementById('back-button-step-3').addEventListener('click', function(){
    document.getElementById('step-2').style.display = 'block';
    document.getElementById('step-3').style.display = 'none';});

    // Function to add flash message
function addFlashMessage(type, message) {
    var flashMessagesContainer = document.getElementById('flash-messages');
    var flashMessageDiv = document.createElement('div');
    flashMessageDiv.className = 'alert alert-' + type;
    flashMessageDiv.textContent = message;
    flashMessagesContainer.appendChild(flashMessageDiv);
}

// Function to check if a field is empty
function isFieldEmpty(field) {
    return !field.value.trim();
}

// Function to check if a field is valid (handles text inputs, dropdowns, and checkboxes)
function isFieldValid(field) {
    if (field.tagName === 'SELECT') {
        // For dropdown lists, check if the selected value is not empty or the default option
        return field.value.trim() !== '' && field.selectedIndex !== 0;
    } else if (field.type === 'checkbox') {
        // For checkboxes, check if it is checked
        return field.checked;
    } else {
        // For text inputs, check if the value is not empty
        return field.value.trim() !== '';
    }
}

// Function to toggle the state of the button based on field validity
function toggleButtonState(button, stepFields) {
    // Check if every field is valid
    const allFieldsValid = stepFields.every(field => isFieldValid(field));
    button.disabled = !allFieldsValid; // Enable button if all fields are valid
}

// Function to initialize event listeners and initial button state
function initializeStepValidation(stepFields, button) {
    stepFields.forEach(field => {
        // Adding event listener for both input and change events
        field.addEventListener('input', function() {
            toggleButtonState(button, stepFields);
        });
        field.addEventListener('change', function() {
            toggleButtonState(button, stepFields);
        });
    });
    // Initial check to disable button if fields are empty
    toggleButtonState(button, stepFields);
}

// Get elements for step 1
let step1NextButton = document.getElementById('next-button');
let step1Fields = [
    document.getElementById('username'),
    document.getElementById('password'),
    document.getElementById('confirm_password'),
    document.getElementById('email')
];



// Get elements for step 2
let step2NextButton = document.getElementById('next-to-step-3-button');
let step2Fields = [
        document.getElementById('contact_number'),
    document.getElementById('first_name'),
    document.getElementById('last_name'),

    document.getElementById('country-select'),
    document.getElementById('city-select'),
    document.getElementById('address'),
    document.getElementById('zip_code')
];

// Get elements for step 3
let submitButton = document.querySelector('button[type="submit"]');
let step3Fields = [
    document.getElementById('manufacturer'),
    document.getElementById('serial_number'),
    document.getElementById('registration_number'),
    document.getElementById('terms-check')
];

// Initialize validation for each step
initializeStepValidation(step1Fields, step1NextButton);
initializeStepValidation(step2Fields, step2NextButton);
initializeStepValidation(step3Fields, submitButton);





    // Update model dropdown based on selected manufacturer
    function updateModelDropdown(selectedManufacturer) {
        var modelDropdown = document.getElementById('model-dropdown');
        var aircraftModelIdInput = document.getElementById('aircraft-model-id');
        modelDropdown.innerHTML = '';
        <?php foreach ($models as $model): ?>
            if ('<?= $model->manufacturer ?>' === selectedManufacturer) {
                var option = document.createElement('option');
                option.value = '<?= $model->model ?>';
                option.text = '<?= $model->model ?>';
                modelDropdown.appendChild(option);
                aircraftModelIdInput.value = '<?= $model->aircraft_model_id ?>';
            }
        <?php endforeach; ?>
    }

    // Add Airplane Button
    document.getElementById('add-airplane-btn').addEventListener('click', function() {
        $('#add-airplane-modal').modal('show');
    });

    // Show Terms
    document.getElementById('show-terms-btn').addEventListener('click', function() {
        const termsContent = document.querySelector('.terms-content');
        if (termsContent.style.display === 'none') {
            termsContent.style.display = 'block';
            this.textContent = 'Hide Terms';
        } else {
            termsContent.style.display = 'none';
            this.textContent = 'Show Terms';
        }
    });
</script>
<?php
// Register JavaScript to handle the city dropdown update and client-side validation
$script = <<<JS
    var citiesByCountry = $citiesByCountryJson;

    // Ensure country-select element exists before adding event listener
    var countrySelect = document.getElementById('country-select');
    var citySelect = document.getElementById('city-select');
    var selectedCityValue = document.getElementById('selected-city-value');

    if (countrySelect && citySelect  && selectedCityValue) {
    countrySelect.addEventListener('change', function() {
        var countryId = this.value;
        citySelect.innerHTML = '<option value="">Select City</option>'; // Reset city options

if (countrySelect && citySelect && selectedCityValue) {
    countrySelect.addEventListener('change', function() {
        var countryId = this.value;
        citySelect.innerHTML = '<option value="">Select City</option>';

        if (countryId) {
fetch('/web/site/get-cities?countryId=' + countryId)
                .then(response => response.json())
                .then(cities => {
                    cities.forEach(city => {
                        var option = document.createElement('option');
                        option.value = city.city_id;
                        option.textContent = city.city_name;
                        citySelect.appendChild(option);
                    });
                })
                .catch(err => console.error('Error loading cities:', err));
        }
    });
}

    });
}

    // Client-side validation for confirming password
    var confirmPassword = document.getElementById('confirm_password');
    if (confirmPassword) {
        confirmPassword.addEventListener('input', function() {
            var password = document.getElementById('password').value;
            var confirm_password = this.value;
            var errorElem = document.getElementById('confirm-password-error');
            if (password !== confirm_password) {
                errorElem.textContent = 'Passwords do not match';
                errorElem.style.color = 'red'; // Change the color to red
                errorElem.style.display = 'block';

                addFlashMessage('danger', 'Passwords do not match.');
            } else {
                errorElem.textContent = '';
                errorElem.style.display = 'none';
            }
        });
    }

    // Client-side validation for email format
    var emailInput = document.getElementById('email');
    if (emailInput) {
        emailInput.addEventListener('input', function() {
            var email = this.value;
            var errorElem = document.getElementById('email-error');
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                errorElem.textContent = 'Invalid email format';
                errorElem.style.display = 'block';
                errorElem.style.color = 'red'; // Red color for error
                addFlashMessage('danger', 'Invalid email format.');

            } else {
                errorElem.textContent = '';
                errorElem.style.display = 'none';
            }
        });
    }

    var showTermsBtn = document.getElementById('show-terms-btn');
    if (showTermsBtn) {
        showTermsBtn.addEventListener('click', function() {
            var termsContent = document.querySelector('.terms-content');
            if (termsContent.style.display === 'none') {
                termsContent.style.display = 'block';
                termsContent.style.color = 'red'; // Red color for error
            } else {
                termsContent.style.display = 'none';
            }
        });
    }
    var form = document.querySelector('form'); // Select the form element

if (form) {
    form.addEventListener('submit', function(event) { // Listen for form submission
        var termsCheckbox = document.getElementById('terms-check'); // Select the terms checkbox

        if (!termsCheckbox.checked) { // Check if the terms checkbox is not checked
            event.preventDefault(); // Prevent form submission
            addFlashMessage('danger', 'Please agree to the terms and conditions.');
            alert('Please agree to the terms and conditions.'); // Display an alert message
        }
    });
}

$('#add-airplane-form').on('beforeSubmit', function(e) {
    var form = $(this);
    var formData = form.serialize();

    $.ajax({
        url: form.attr('action'),
        type: 'post',
        data: formData,
        success: function(response) {
            // Handle the success response
            $('#add-airplane-modal').modal('hide'); // Hide the modal
            // Optionally, update the page with the new airplane information
        },
        error: function(xhr) {
            // Handle errors
            console.log(xhr.responseText);
        }
    });

    return false;
});
$('#add-airplane-btn').click(function() {
    $('#add-airplane-modal').modal('show');
});
JS;

$this->registerJs($script);
?>
