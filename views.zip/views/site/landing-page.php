<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $content string */

$this->title = 'GlobalMROs';

?>
        <?php if (Yii::$app->session->hasFlash('message')): ?>
    <div class="alert alert-success">
        <?= Yii::$app->session->getFlash('message') ?>
    </div>
<?php endif; ?>
<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('error') ?>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('usernameError')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('usernameError') ?>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('passwordError')): ?>
    <div class="alert alert-danger">
        <?= Yii::$app->session->getFlash('passwordError') ?>
    </div>
<?php endif; ?>

<!-- Hero Section -->
<div class="hero-section" style="background: linear-gradient(90deg, rgba(19,63,98,1) 0%, rgba(75,111,135,1) 100%); 35%, rgba(81,150,230,1) 100%); height: 90vh; position: relative;">
    <div style="background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; display: flex; justify-content: center; align-items: center;">
        <!-- Centered Image -->
        <?= Html::img('@web/img/image.jpg', [
            'alt' => 'Airplane Image',
            'style' => 'width: 90%; height: 90%; object-fit: cover;',
        ]); ?>
    </div>
</div>

<!-- Vision Section -->
<div class="vision-section" style="background: linear-gradient(90deg, rgba(19,63,98,1) 0%, rgba(75,111,135,1) 100%); 35%, rgba(81,150,230,1) 100%); position: relative; padding: 100px 0;">
    <!-- Transparent Overlay -->
    <div class="text-center" id="about" style="background-color: rgba(255, 255, 255, 0.2); width: 90%; margin: 0 auto; padding: 50px; border-radius: 10px; ">
        <!-- Title -->
        <h2 style="text-align: center; font-size: 5rem; font-weight: bold; color: white;">About Us</h2>
        <!-- Paragraphs -->
        </br><p style="color: white; font-size: 1.2rem; line-height: 1.6;">
        At GlobalMROs we provide a centralised platform providing valuable resources for aviation professionals seeking maintenance stations worldwide. Whether you are looking for line maintenance, AOG support, routine inspections or repairs, having the right maintenance centre at your fingertips will save you time, money and ensure efficient operations. The ability to find maintenance stations worldwide is crucial for airlines, MRO facilities, and individual aircraft owners and we will ensure that no matter where your aircraft is located, suitable maintenance support is accessible.   </p>
    </br> <p style="color: white; font-size: 1.2rem; line-height: 1.6;">
        By considering specific requirements (such as aircraft type, service level, and certifications), GlobalMROS will match users with the most suitable maintenance stations. This personalised approach streamlines the decisionmaking process. Instead of manually searching for maintenance centres, users can rely on GlobalMROS to provide accurate and up to date information that suits their needs. Our services allow aviation professionals to focus on their core responsibilities and day to day tasks.
        </p>
    </div>
</div>

<!-- All Products Section -->
<div class="all-products-section" style="background: linear-gradient(90deg, rgba(19,63,98,1) 0%, rgba(75,111,135,1) 100%); 35%, rgba(81,150,230,1) 100%); position: relative; padding: 100px 0;">
    <!-- Transparent Overlay -->
    <div class="text-center" style="background-color: rgba(255, 255, 255, 0.2); width: 90%; margin: 0 auto; padding: 50px; border-radius: 10px;" id="products">
        <!-- Title -->
        <h2 style="text-align: center; font-size: 2.5rem; font-weight: bold; color: white;">All Products</h2>
        <!-- Products Grid -->
        <div class="row" style="margin-top: 50px;">
            <div class="col-md-4">
                <?= Html::img('@web/img/product1.jpg', ['alt' => 'Product 1', 'style' => 'width: 60%; border-radius: 10px;']) ?>
                <p style="color: white; font-size: 1.2rem; margin-top: 15px;">Aircraft Operator</p>
                <p style="color: white; font-size: .9rem; margin-top: 15px; width: 60%; margin: 0 auto; text-align: center;">Get connected with MROs at your location with the touch of a button.</p>

            </div>
            <div class="col-md-4">
                <?= Html::img('@web/img/product2.jpg', ['alt' => 'Product 2', 'style' => 'width: 60%; border-radius: 10px;']) ?>
                <p style="color: white; font-size: 1.2rem; margin-top: 15px;">MRO Centers</p>
                <p style="color: white; font-size: .9rem; margin-top: 15px; width: 60%; margin: 0 auto; text-align: center;">Lead the way in supporting Aircraft Operators to keep their aircraft flying.</p>
            </div>
            <div class="col-md-4">
                <?= Html::img('@web/img/product3.jpg', ['alt' => 'Product 3', 'style' => 'width: 60%; border-radius: 10px;']) ?>
                <p style="color: white; font-size: 1.2rem; margin-top: 15px;">Around The Globe</p>
                <p style="color: white; font-size: .9rem; margin-top: 15px; width: 60%; margin: 0 auto; text-align: center;">No matter where you are in the world, our aim is to provide support closest to you.</p>
            </div>
        </div>
    </div>
</div>

<!-- Footer Section -->
<div class="footer-section" style="background: linear-gradient(90deg, rgba(19,63,98,1) 0%, rgba(75,111,135,1) 100%); 35%, rgba(81,150,230,1) 100%); position: relative; padding: 100px 0;" id="help">
    <!-- Transparent Overlay -->
    <div class="text-center" style="background-color: rgba(255, 255, 255, 0.2); width: 90%; margin: 0 auto; padding: 50px; border-radius: 10px;">
        <!-- Big Title -->
        <h1 style="color: white; font-size: 5rem;  text-align: left;">
            Get in touch!
        </h1>
        
        <!-- Underlined Text -->
       <a href="#products"> <p style="color: white; font-size: .8rem; text-decoration: underline; margin-bottom: 50px; text-align: left;">
            Find out how our products can help <br> you be more productive
        </p></a>
    </br></br>
        <!-- Grid Layout -->
        <div style="display: flex; justify-content: space-between; text-align: left; color: white;">
            
            <!-- First Column: Contact Information -->
            <div style="flex: 1; padding: 0 20px;">
                <p>Phone: 0044 7824 388362</p>
                <p>Email: <a href="mailto:globalmros@gmail.com" style="color: white; text-decoration: none;">support@coreaviationnetwork.com</a></p>
                <div>
<!-- Social Media Icons -->
<div>
    <a href="https://instagram.com" target="_blank" style="margin-right: 10px;">
        <i class="fab fa-instagram" style="color: white; font-size: 30px;"></i>
    </a>
    <a href="https://facebook.com" target="_blank" style="margin-right: 10px;">
        <i class="fab fa-facebook-f" style="color: white; font-size: 30px;"></i>
    </a>
    <a href="https://twitter.com" target="_blank">
        <i class="fab fa-twitter" style="color: white; font-size: 30px;"></i>
    </a>
</div>

<!-- Add Font Awesome in the head section of your HTML file -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

                </div>
            </div>

            <!-- Second Column: Address Information -->
            <div style="flex: 1; padding: 0 20px;">
                <p>5 Stavedown Road, South Wanston, Winchester</p>
                <p>S021 3HA</p>
                <p>United Kingdom</p>
                <p>Registered in England and Wales</p>
                <p>Company No. 15789027</p>
            </div>

            <!-- Third Column: Company Information -->
            <div style="flex: 1; padding: 0 20px;">
                <div style="text-align: left; margin-bottom: 20px;">
                    <p>© 2024 GlobalMros Ltd</p>
                </div>
                <p><a href="<?= \yii\helpers\Url::to(['site/terms']) ?>" style="color: white; text-decoration: none;">Terms and Conditions</a></p>
                <p><a href="<?= \yii\helpers\Url::to(['site/privacy-policy']) ?>" style="color: white; text-decoration: none;">Privacy Policy</a></p>
                <p><a href="<?= \yii\helpers\Url::to(['site/cookie-policy']) ?>" style="color: white; text-decoration: none;">Cookie Policy</a></p>
                </div>

        </div>
    </div>
</div>


<!-- Main Content 
<div class="container mt-5">
    <div class="row">
        <div class="col-md-7 align-self-center">
            <h1 class="display-3 text-uppercase font-weight-bold">Keep flying in time and safety</h1>
            <p class="lead">With the best worldwide MROs</p>
        </div>
        <div class="col-md-5 d-flex justify-content-end">
            <w!-- Placeholder for airplane photo -w-x>
            /*<?= Html::img('@web/img/Airplane.jpg', ['alt' => 'Airplane Image', 'style' => 'width: 100%; border-top-left-radius: 100px;']); ?>*/-->