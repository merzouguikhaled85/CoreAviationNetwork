<?php 
use yii\helpers\Html;
?>
<?php $this->title ='GlobaleMRO' ?>

            <main class="dash-content">
                <?php if(yii::$app->session->hasFlash('message')): ?>
                    <div class="alert alert-dismissible alert-success">
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  <?php echo yii::$app->session->getFlash('message'); ?>
</div>
                    
                <?php endif; ?>
                <div class="container-fluid">
                    <h1 class="dash-title">Home</h1>



                    
                </div>
            </main>
        </div>
    </div>
 
