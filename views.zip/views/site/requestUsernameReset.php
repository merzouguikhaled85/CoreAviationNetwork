<?php

use yii\bootstrap5\ActiveForm;
use yii\bootstrap5\Html;

$this->title = 'Request Username';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-request-username-reset">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Please fill out your email and select your user type. A reminder of your username will be sent there.</p>

    <div class="row">
        <div class="col-lg-5">
            <?php $form = ActiveForm::begin(['id' => 'request-username-reset-form']); ?>

                <?= $form->field($model, 'email')->textInput(['autofocus' => true]) ?>

                <?= $form->field($model, 'usertype')->dropDownList([
                    'mro' => 'MRO',
                    'ao' => 'AO',
                ], ['prompt' => 'Select User Type']) ?>

                <div class="form-group">
                    <?= Html::submitButton('Send', ['class' => 'btn btn-primary']) ?>
                </div>

            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>
