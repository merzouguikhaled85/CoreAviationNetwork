<?php 
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Request Password Reset';
?>

<h1><?= Html::encode($this->title) ?></h1>

<p>Please fill out your email. A link to reset password will be sent there.</p>

<div class="password-reset-request-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'email')->textInput(['autofocus' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Send', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
