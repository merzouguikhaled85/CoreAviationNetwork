<?php

use yii\helpers\Html;

$this->title = 'View Aircraft: ' . $aircraft->aircraft_id;
$this->params['breadcrumbs'][] = ['label' => 'Aircrafts', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <div class="row">
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Aircraft ID:</strong>
                    <?= Html::encode($aircraft->aircraft_id) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Manufacturer:</strong>
                    <?= Html::encode($aircraft->manufacturer) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Model:</strong>
                    <?= Html::encode($aircraft->model) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Serial Number:</strong>
                    <?= Html::encode($aircraft->serial_number) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Registration Number:</strong>
                    <?= Html::encode($aircraft->registration_number) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Owner:</strong>
                    <?= Html::encode(Yii::$app->user->identity->username) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>certificate Type:</strong>
                    <?php
                        $certificateType = $aircraft->getCertificateType()->one(); // Fetch the certificate type
                        echo $certificateType ? Html::encode($certificateType->type) : 'N/A'; // Display the type or 'N/A'
                        ?>
                </li>





            </ul>
            <div class="row">
                <?= Html::a('Back to Aircrafts', ['index'],  ['class' => 'btn btn-primary']) ?>
            </div>
        </div>
    </div>
</main>
