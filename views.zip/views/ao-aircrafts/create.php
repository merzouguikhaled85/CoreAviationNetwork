<?php

use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;

$this->title = 'Create Aircraft';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">Create Aircraft</h1>
        <?php
        // Check if there is a success flash message set
        if (Yii::$app->session->hasFlash('success')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
        }


        ?>
        <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); // Enable file uploads ?>

        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                <?= $form->field($aircraftModel, 'manufacturer')->dropDownList(
    \yii\helpers\ArrayHelper::map($manufacturers, 'manufacturer', 'manufacturer'),
    [
        'prompt' => 'Select Manufacturer',
        'id' => 'manufacturer-dropdown', // Corrected ID
        'class' => 'form-select form-select-lg',
        'onchange' => 'updateModelDropdown(this.value)', // Call JavaScript function on change
        ])->label($aircraftModel->getAttributeLabel('manufacturer') . '<span class="text-danger">*</span>') ?>

                  </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                <?= $form->field($aircraftModel, 'model')->dropDownList(
    [], // Preload empty options, to be populated dynamically
    [
        'prompt' => 'Select Model',
        'id' => 'model-dropdown', // Corrected ID
        'class' => 'form-select form-select-lg'
        ])->label($aircraftModel->getAttributeLabel('model') . '<span class="text-danger">*</span>') ?>
                         </div>
            </div>
        </div>

        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($aircraftModel, 'serial_number')->textInput(['maxlength' => true])->label($aircraftModel->getAttributeLabel('serial_number') . '<span class="text-danger">*</span>') ?>
                    <?= $form->field($aircraftModel, 'aircraft_model_id')->hiddenInput(['id' => 'aircraft-model-id'])->label(false) ?>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($aircraftModel, 'registration_number')->textInput(['maxlength' => true])->label($aircraftModel->getAttributeLabel('registration_number') . '<span class="text-danger">*</span>') ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($aircraftModel, 'ao_id')->hiddenInput(['value' => Yii::$app->session->get('ao_id')])->label(false) ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group">
                <div class="col-lg-6">
                    <?= $form->field($aircraftModel, 'certificate_type_id')->dropDownList(
                        ArrayHelper::map(\app\models\CertificateTypes::find()->orderBy(['type' => SORT_ASC])->all(), 'certificate_type_id', 'type'), // Displaying 'type' from CertificateTypes
                        [
                            'prompt' => 'Select Certificate Type',
                            'id' => 'certificate-type-dropdown',
                        ]
                    )->label($aircraftModel->getAttributeLabel('certificate_type_id') . '<span class="text-danger">*</span>') ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="form-group col-lg-8">
                <div class="row">
                    <div class="col-lg-6">
                        <?= Html::submitButton('Create Aircraft', ['class' => 'btn btn-primary']) ?>
                    </div>
                    <div class="col-lg-2">
                        <?= Html::a('Back to Aircrafts', ['index'], ['class' => 'btn btn-primary']) ?>
                    </div>
                </div>
            </div>
        </div>

        <?php ActiveForm::end(); ?>
    </div>
</main>
<script>
function updateModelDropdown(selectedManufacturer) {
    // Get the model dropdown element
    var modelDropdown = document.getElementById('model-dropdown');
    var aircraftModelIdInput = document.getElementById('aircraft-model-id');

    // Clear existing options
    modelDropdown.innerHTML = '';

    // Append default prompt option
    var defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.text = 'Select Model';
    modelDropdown.appendChild(defaultOption);

    // Populate model dropdown with models corresponding to the selected manufacturer
    <?php foreach ($models as $model): ?>
        if ('<?= $model->manufacturer ?>' === selectedManufacturer) {
            var option = document.createElement('option');
            option.value = '<?= $model->model ?>';
            option.text = '<?= $model->model ?>';
            modelDropdown.appendChild(option);
            aircraftModelIdInput.value = '<?= $model->aircraft_model_id ?>';

        }
    <?php endforeach; ?>
}

</script>


<?php
// Register JavaScript to handle dynamic dropdown update
$script = <<<JS
$(document).ready(function(){
    $('#manufacturer-select').change(function(){
        var selectedManufacturer = $(this).val(); // Get the selected manufacturer
        $('#model-select option').each(function(){
            if ($(this).data('manufacturer') === selectedManufacturer || $(this).val() === '') {
                $(this).show(); // Show options matching the selected manufacturer or the default prompt
            } else {
                $(this).hide(); // Hide options not matching the selected manufacturer
            }
        });
    });
});
JS;

// Register the JavaScript code block
$this->registerJs($script);
