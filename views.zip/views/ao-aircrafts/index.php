<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;

$this->title = 'AO Aircrafts';

// Register custom CSS styles for pagination links and search input
$this->registerCss("
    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    
    .pagination li {
        margin: 0 5px;
    }
    
    .pagination .active a {
        background-color: #007bff;
        color: #fff;
    }
    
    .pagination li a {
        color: #007bff;
        border: 1px solid #007bff;
        padding: 6px 12px;
        text-decoration: none;
        border-radius: 3px;
    }
    
    .pagination li a:hover {
        background-color: #f2f2f2;
    }
    
    .search-container {
        display: flex;
        border-radius: 20px;
        overflow: hidden;
    }
    
    .search-input {
        flex: 1;
        border-top-left-radius: 20px;
        border-bottom-left-radius: 20px;
    }
    
    .search-button {
        border-top-right-radius: 20px;
        border-bottom-right-radius: 20px;
    }
    .search-input-lg {
        width: 100%; /* Set width to 100% to make it full width */
        height: 50px; /* Adjust height as needed */
        font-size: 18px; /* Increase font size for larger input */
    }
");
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title">AO Aircrafts</h1>

        <?php
        // Check for flash messages
        if (Yii::$app->session->hasFlash('message')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('message') . '</div>';
        }
        if (Yii::$app->session->hasFlash('error')) {
            echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
        }
        ?>

        <div class="row" style="margin-bottom: 20px;">
            <div class="col-lg-12">
                <?= Html::beginForm(['ao-aircrafts/index'], 'get', ['class' => 'form-inline']) ?>
                <?= Html::textInput('search', Yii::$app->request->get('search'), ['class' => 'form-control search-input search-input-lg', 'placeholder' => 'Search by Manufacturer, Model, or Registration Number']) ?>
                <div class="input-group-append">
                    <?= Html::submitButton('Search', ['class' => 'btn btn-primary btn-lg search-button']) ?>
                </div>
                <?= Html::endForm() ?>
            </div>
    
            <div class="col-auto ml-auto" style="float: right; display: inline-block;">
            </br></br></br>
                <?= Html::a('Add Aircraft', ['create'], ['class' => 'btn btn-outline-primary btn-lg rounded-pill']) ?>
            </div>
        </div>

        <div class="row">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Manufacturer</th>
                        <th>Model</th>
                        <th>Serial Number</th>
                        <th>Registration Number</th>
                        <th>certificate type</th>

                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($aircraftModels as $aircraftModel): ?>
                        <tr>
                            <td><?= $aircraftModel->aircraft_id ?></td>
                            <td><?= Html::encode($aircraftModel->manufacturer) ?></td>
                            <td><?= Html::encode($aircraftModel->model) ?></td>
                            <td><?= Html::encode($aircraftModel->serial_number) ?></td>
                            <td><?= Html::encode($aircraftModel->registration_number) ?></td>
                            <td>
    <?php 
    $certificateType = $aircraftModel->getCertificateType()->one(); // Fetch the certificate type
    echo $certificateType ? Html::encode($certificateType->type) : 'N/A'; // Display the type or 'N/A'
    ?>
</td>

                            <td>
                                <?= Html::a('View', ['view', 'id' => $aircraftModel->aircraft_id], ['class' => 'btn btn-info']) ?>
                                <?= Html::a('Update', ['update', 'id' => $aircraftModel->aircraft_id], ['class' => 'btn btn-primary']) ?>
                                <?= Html::a('Delete', ['delete', 'id' => $aircraftModel->aircraft_id], [
                                    'class' => 'btn btn-secondary',
                                    'data' => [
                                        'confirm' => 'Are you sure you want to delete this item?',
                                        'method' => 'post',
                                    ],
                                ]) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="pagination-container">
            <?= LinkPager::widget(['pagination' => $pagination]) ?>
        </div>
    </div>
</main>
