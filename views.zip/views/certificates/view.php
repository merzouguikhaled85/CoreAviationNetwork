<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var app\models\Certificates $model */

$this->title = 'View Certificate: ' . $model->certificate_id;
$this->params['breadcrumbs'][] = ['label' => 'Certificates', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

        <div class="row">
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Certificate ID:</strong>
                    <?= Html::encode($model->certificate_id) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>MRO Name:</strong>
                    <?= Html::encode($model->mro->username) ?> <!-- Assuming MRO username is the display name -->
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Type:</strong>
                    <?= Html::encode($model->type) ?>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <strong>Certificate File:</strong>
                    <?= Html::a('Download', Yii::$app->request->baseUrl . '/' . $model->certificate, ['target' => '_blank']) ?>
                </li>
            </ul>
            <div class="row">
              
                <?= Html::a('Back to Certificates', ['index'],  ['class' => 'btn btn-primary']) ?>
            </div>
        </div>
    </div>
</main>
