<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Currency;

$this->title = 'Update Request';

?>

<h1><?= Html::encode($this->title) ?></h1>

<?php
if (Yii::$app->session->hasFlash('success')) {
    echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('success') . '</div>';
}

if (Yii::$app->session->hasFlash('error')) {
    echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
}
?>
<!-- Multi-step progress bar -->
<div class="progress-bar-container">
    <span class="progress-bar-step step-realized">Create a Request</span>
    <span class="progress-bar-step step-realized">MRO Quote</span>
    <span class="progress-bar-step step-realized">PO Loaded</span>
    <span class="progress-bar-step step-realized ">PO Accepted By MRO</span>
    <span class="progress-bar-step step-realized">Work Started</span>
    <span class="progress-bar-step step-realized">Update Request</span>
    <span class="progress-bar-step step-active">MRO Quote</span>
    <span class="progress-bar-step ">MRO Report</span>
    <span class="progress-bar-step ">AO Feedback</span>
    <span class="progress-bar-step ">Request Closed</span>
</div>
</br>

<div class="mro-request-apply-form">

    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($model, 'Description')->textarea(['rows' => 6])->label('Description'. '<span class="text-danger">*</span>') ?>
    <?php
    // Retrieve the currencies from the Currency model
    $currencies = Currency::find()->all();

    // Convert currencies array to a suitable format for dropDownList
    $currencyList = [];
    foreach ($currencies as $currency) {
        $currencyList[$currency->code] = $currency->name . ' ' . $currency->symbol . ' (' . $currency->code . ')';
    }
    ?>

    <?= $form->field($model, 'currency')->dropDownList($currencyList, ['prompt' => 'Select Currency'])->label('Currency'. '<span class="text-danger">*</span>') ?>
    <?= $form->field($model, 'price')->textInput(['type' => 'number', 'step' => '0.01'])->label('Price'. '<span class="text-danger">*</span>') ?>



    <?= $form->field($model, 'attachment')->fileInput(['accept' => 'image/png, image/jpeg, application/pdf'])->label('Attach Quote') ?>

    <div class="form-group">
        <?= Html::submitButton('Update application', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
