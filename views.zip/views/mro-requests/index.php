<?php

use app\models\Airports;
use yii\helpers\Html;
use yii\helpers\Url;

$this->title = $title;
?>

<h1><?= Html::encode($this->title) ?></h1>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<script>
document.addEventListener('DOMContentLoaded', function () {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
});
</script>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Request ID</th>
            <th>Aircraft Operator/CAMO</th>
            <th>Aircraft Model</th>
            <th>Aircraft Registration</th>
            <th>Aircraft Serial Number</th>
            <th>ETA</th>
            <th>ETD</th>
            <th>Maintenance Loctation</th>
           

            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($requests as $request): ?>
            <tr>
            <td><?= Html::a($request->request_id, ['requests/view', 'id' => $request->request_id]) ?></td>

                <td>
                    <?php

                    // Fetch the associated aircraft model
                    $ao_username = \app\models\AoProfile::findOne($request->ao_id);
                    // Check if the aircraft model exists
                    if ($ao_username) {
                        // Output the aircraft model
                        echo $ao_username->username;
                    } else {
                        // Handle the case when the aircraft model is not found
                        echo "N/A";
                    }
                    ?>
                </td>  
   
                <td>
                    <?php
                    // Fetch the associated aircraft model
                    $aircraftModel = \app\models\Aircrafts::findOne($request->aircraft_id);
                    // Check if the aircraft model exists
                    if ($aircraftModel) {
                        // Output the aircraft model
                        echo $aircraftModel->model;
                    } else {
                        // Handle the case when the aircraft model is not found
                        echo "N/A";
                    }
                    ?>
                </td>                
                <td><?= $request->aircraft_registration ?></td>
                <td><?= $request->serial_number ?></td>
                <td><?= Html::encode($request->eta ? date('d M Y H:i', strtotime($request->eta)) : '') ?></td>
                <td><?= Html::encode($request->etd ? date('d M Y H:i', strtotime($request->etd)) : '') ?></td>

                <td><?= ($request->destinationAirport)->airport_name ?></td>
               
                <td>    <?= Html::encode(ucwords(str_replace('_', ' ', $request->status))) ?>
</td>
                <td>
                  <div class="ml-auto d-flex gap-1">

    <?= Html::a('<i class="bi bi-check2-circle"></i>', ['apply', 'id' => $request->request_id], [
        'class' => 'btn btn-info',
        'title' => 'Apply',
        'data-bs-toggle' => 'tooltip'
    ]) ?>

    <?= Html::a('<i class="bi bi-person-plus-fill"></i>', ['recommend-mro', 'id' => $request->request_id], [
        'class' => 'btn btn-secondary',
        'title' => 'Recommend Other MRO',
        'data-bs-toggle' => 'tooltip'
    ]) ?>

</div>


                    
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
