<?php
use yii\helpers\Html;

$this->title = 'View Feedback';
$this->params['breadcrumbs'][] = ['label' => 'Requests', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $request->request_id, 'url' => ['view', 'id' => $request->request_id]];
$this->params['breadcrumbs'][] = $this->title;
?>

<style>
    .stars {
        font-size: 36px; /* Adjust the size of stars */
    }

    .stars span {
        color: #f8d150; /* Golden color */
    }

</style>

<div class="request-view">
    <h1><?= Html::encode($this->title) ?></h1>

    <p><strong>Request ID:</strong> <?= Html::encode($request->request_id) ?></p>

    <!-- Display feedback details -->
    <h2>Feedback Details</h2>
    <ul>
        <li><strong>Feedback Date:</strong> <?= Html::encode(Yii::$app->formatter->asDate($feedback->timestamp)) ?></li>
        <li><strong>Feedback Summary:</strong> <?= Html::encode($feedback->feedback_text) ?></li>
    </ul>

    <table class="table">
        <th>Object</th>
        <th>Stars</th>
        <th>Rating</th>

        <tr>
            <td>Kept to Agreed Schedule Rating:</td>
            <td><?= displayStars($feedback->kept_to_agreed_schedule_rating) ?></td>
            <td><?= Html::encode($feedback->kept_to_agreed_schedule_rating) ?> / 5</td>
        </tr>
        <tr>
            <td>Kept to Agreed Cost Rating:</td>
            <td><?= displayStars($feedback->kept_to_agreed_cost_rating) ?></td>
            <td><?= Html::encode($feedback->kept_to_agreed_cost_rating) ?> / 5</td>
        </tr>
        <tr>
            <td>Overall Communication Rating:</td>
            <td><?= displayStars($feedback->overall_communication_rating) ?></td>
            <td><?= Html::encode($feedback->overall_communication_rating) ?> / 5</td>
        </tr>
        <tr>
            <td><strong>Overall Rating:</strong></td>
            <td><?= displayStars($feedback->rating) ?></td>
            <td><strong><?= Html::encode($feedback->rating) ?> / 5</strong></td>
        </tr>
    </table>

<?= Html::a('<i class="bi bi-arrow-left"></i> Back', 'javascript:history.back()', [
    'class' => 'btn btn-primary',
    'title' => 'Go back to the previous page'
]) ?>
</div>

<?php
// Function to display stars based on rating
function displayStars($rating)
{
    $stars = '';
    for ($i = 1; $i <= $rating; $i++) {
        $stars .= '<span>&#x2605;</span>'; // Full star
    }
    for ($i = $rating + 1; $i <= 5; $i++) {
        $stars .= '<span>&#x2606;</span>'; // Empty star
    }
    return '<div class="stars">' . $stars . '</div>';
}
?>
