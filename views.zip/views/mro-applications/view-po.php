<?php

use yii\helpers\Html;

$this->title = 'View PO';
?>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>

<!-- Multi-step progress bar -->
<div class="progress-bar-container">
    <span class="progress-bar-step ">Create a Request</span>
    <span class="progress-bar-step ">MRO Quote</span>
    <span class="progress-bar-step ">PO Loaded</span>
    <span class="progress-bar-step step-active">PO Accepted By MRO</span>
    <span class="progress-bar-step">Work Started</span>
    <span class="progress-bar-step">MRO Report</span>
    <span class="progress-bar-step">AO Feedback</span>
    <span class="progress-bar-step">Request Closed</span>
</div>
</br>
        <div class="row">
            <div class="col-md-12">
                <h3>Request ID: <?= $aoRequestsApplications[0]->application->request_id ?></h3>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>MRO Username</th>
                            <th>Reply Description</th>
                            <th>PO File</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($aoRequestsApplications as $aoRequestApplication): ?>
                            <tr>
                                <td><?= Html::encode($aoRequestApplication->application->mro->username) ?></td>
                                <td><?= Html::encode($aoRequestApplication->application->Description) ?></td>
                                <td><?= Html::a('Download PO', ['requests/download-po', 'id' => $aoRequestApplication->id]) ?></td>
                                <td><?= Html::a('Accept PO', ['accept-po', 'id' => $aoRequestApplication->id], ['class' => 'btn btn-secondary']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="form-group">
        <?= Html::a('Back to Applied Requests', ['index'], ['class' => 'btn btn-primary']) ?>
    </div>
            </div>
        </div>
    </div>
</main>
