<?php

use app\models\AoRequestsApplications;
use app\models\RepairReport;
use yii\helpers\Html;
use yii\helpers\VarDumper;
use yii\widgets\ActiveForm;

$this->title = $title;

?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<script>
document.addEventListener('DOMContentLoaded', function () {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
});
</script>
<h1><?= Html::encode($this->title) ?></h1>

<?php if (Yii::$app->session->hasFlash('success')): ?>
    <div class="alert alert-success"><?= Yii::$app->session->getFlash('success') ?></div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger"><?= Yii::$app->session->getFlash('error') ?></div>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
        <th>Request ID</th>
            <th>Aircraft Operator/CAMO</th>
            <th>Aircraft Model</th>
            <th>Aircraft Registration</th>
            <th>Aircraft Serial Number</th>
            <th>ETA</th>
            <th>ETD</th>
            <th>Maintenance Loctation</th>
            <th>Invoice details</th>
          
            <th>PO</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($appliedRequests as $request): ?>
            <tr>
                <td><?= Html::a($request->getRequest()->one()->request_id, ['requests/view', 'id' => $request->getRequest()->one()->request_id]) ?></td>
                <td><?= Html::encode( $request->getRequest()->one()->getAO()->one()->username) ?></td>
                <td><?= Html::encode($request->getRequest()->one()->getAircraft()->one()->model) ?></td>
                <td><?= Html::encode($request->getRequest()->one()->aircraft_registration) ?></td>
                <td><?= Html::encode($request->getRequest()->one()->serial_number) ?></td>
                <td><?= Html::encode(date('d M Y H:i', strtotime($request->getRequest()->one()->eta))) ?></td>
                <td><?= Html::encode( date('d M Y H:i', strtotime($request->getRequest()->one()->etd)) ) ?></td>

                <td><?= Html::encode($request->getRequest()->one()->destinationAirport->airport_name ?? 'N/A') ?></td>

                <td><?=Html::a('Details', ['view-answer', 'id' => $request->id]) ?></td>
                
                <td>
                    <?php
                    // Find the last AoRequestsApplications for this request_id
                    $lastApplication = AoRequestsApplications::find()
                        ->where(['request_id' => $request->getRequest()->one()->request_id])
                        ->orderBy(['id' => SORT_DESC])
                        ->one();

                   // Display the last application PO file if found
                   if ($lastApplication && $lastApplication->po) {
                    echo Html::a('Download PO', '@web/uploads/' .$lastApplication->po);
                } else {
                    echo 'N/A'; // Display N/A if no application found or no PO available
                }
                ?>
                    
                </td>
             
<td>
    <?php
    $status = $request->getRequest()->one()->status;

    if ($status === 'answered') {
        echo Html::a('answered', ['view-answer', 'id' => $request->id]);
    } elseif ($status === 'report_submitted') {
        echo Html::a('View CRSs', ['view-reports', 'id' => $request->id]);
    } elseif ($status === 'update_request') {
        echo Html::a('View Updated Request', ['requests/view', 'id' => $request->getRequest()->one()->request_id]);
    } elseif ($status === 'update_request_accepted') {
        echo Html::a('Update Quotation', ['mro-requests/applyupdate', 'id' => $request->id]);
    } else {
        // Convert enum to human-readable format
        $formattedStatus = ucwords(str_replace('_', ' ', $status));
        echo Html::encode($formattedStatus);
    }
    ?>
</td>

<td>
    <?php if ($request->getRequest()->one()->status === 'po_loaded'): ?>
        <?= Html::a('<i class="bi bi-check-circle"></i>', ['accept-po', 'id' => $lastApplication->id], [
            'class' => 'btn btn-secondary',
            'title' => 'Accept PO',
        ]) ?>
    <?php endif; ?>

    <?php if ($request->getRequest()->one()->status === 'work_accepted'): ?>
        <?= Html::a('<i class="bi bi-play-circle"></i>', ['start-work', 'id' => $request->getRequest()->one()->request_id], [
            'class' => 'btn btn-info',
            'title' => 'Start Working',
            'data' => ['confirm' => 'Are you sure you want to start work?', 'method' => 'post'],
        ]) ?>
    <?php endif; ?>

    <?php if ($request->getRequest()->one()->status === \app\models\Requests::STATUS_UPDATE_REQUEST): ?>
        <?= Html::a('<i class="bi bi-check-square"></i>', ['accept-update', 'id' => $request->request_id], [
            'class' => 'btn btn-info',
            'title' => 'Accept Updated Request',
            'data' => ['confirm' => 'Are you sure?', 'method' => 'post'],
        ]) ?>
        <?= Html::a('<i class="bi bi-trash"></i>', ['deny-request', 'id' => $request->request_id], [
            'class' => 'btn btn-secondary',
            'title' => 'Delete Request',
            'data' => ['confirm' => 'Are you sure you want to deny this request?', 'method' => 'post'],
        ]) ?>
    <?php endif; ?>

    <?php
    $existingReport = RepairReport::find()->where(['mro_request_apply_id' => $request->id])->exists();
    $lastReport = RepairReport::find()
        ->where(['mro_request_apply_id' => $request->id])
        ->orderBy(['updated_at' => SORT_DESC])
        ->one();
    ?>
    <?php if (
        ($request->getRequest()->one()->status === 'work_started' || $request->getRequest()->one()->status === 'report_submitted')
        && (!$existingReport || ($existingReport && $lastReport->quote_approved == 0))
    ): ?>
        <?= Html::a('<i class="bi bi-upload"></i>', ['submit-report', 'id' => $request->id], [
            'class' => 'btn btn-info',
            'title' => 'Upload CRS',
        ]) ?>
    <?php endif; ?>

    <?php
    $existingfeedback = \app\models\Feedback::find()
        ->where(['request_id' => $request->getRequest()->one()->request_id])
        ->exists();
    ?>
    <?php if ($request->getRequest()->one()->status == 'closed' && $existingfeedback): ?>
        <?= Html::a('<i class="bi bi-chat-square-text"></i>', ['view-feedback', 'id' => $request->getRequest()->one()->request_id], [
            'class' => 'btn btn-secondary',
            'title' => 'View Feedback',
        ]) ?>
    <?php endif; ?>

    <?php if ($request->getRequest()->one()->status !== 'closed'): ?>
        <?= Html::a('<i class="bi bi-envelope"></i>', ['contact', 'id' => $request->id], [
            'class' => 'btn btn-info',
            'title' => 'Contact',
        ]) ?>
        <?= Html::a('<i class="bi bi-calendar-event"></i>', ['set-appointment', 'app_request_id' => $request->id], [
            'class' => 'btn btn-primary',
            'title' => 'Set Appointment',
        ]) ?>
    <?php endif; ?>

    <?php if (in_array($request->getRequest()->one()->status, ['answered', 'created', 'po_loaded'])): ?>
        <?= Html::a('<i class="bi bi-x-circle"></i>', ['cancel-application', 'id' => $request->id], [
            'class' => 'btn btn-secondary',
            'title' => 'Cancel',
            'data' => ['confirm' => 'Are you sure you want to cancel this application?', 'method' => 'post'],
        ]) ?>
    <?php endif; ?>
</td>

            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php
$this->registerJs("
    $('a[data-confirm]').on('click', function (e) {
        var message = $(this).data('confirm');



    });
");
?>
