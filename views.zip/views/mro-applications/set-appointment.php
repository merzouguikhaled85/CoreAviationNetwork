<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\datetime\DateTimePicker;

$this->title = 'Set Appointment';
?>

<h1><?= Html::encode($this->title) ?></h1>

<div class="appointment-form">

    <?php $form = ActiveForm::begin(); ?>
    <div id="loading-spinner" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999;">
    <img src="<?= Yii::getAlias('@web/img/spinner.gif') ?>" alt="Loading..." />
</div>
  <?= $form->field($appointment, 'appointment_date')->widget(DateTimePicker::class, [
    'options' => [
        'name' => 'Appointment[appointment_date]',
        'value' => $appointment->appointment_date
            ? date('d M Y H:i', strtotime($appointment->appointment_date))
            : '',
    ],
    'pluginOptions' => [
        'format' => 'dd M yyyy HH:ii', // e.g. 16 Jul 2025 08:30
        'autoclose' => true,
        'todayHighlight' => true,
    ],
])->label($appointment->getAttributeLabel('appointment_date') . '<span class="text-danger">*</span>') ?>

    <?= Html::hiddenInput('ao_requests_applications_id', $application->id) ?>

        
      
    <div class="form-group">
        <?= Html::submitButton('Set Appointment', ['class' => 'btn btn-primary','id' => 'submit-button']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
<?php
$this->registerJs('
var submitButton = document.getElementById("submit-button");
var loadingIndicator = document.getElementById("loading-spinner");
console.log(loadingIndicator);
if (submitButton) {
    submitButton.addEventListener("click", function() {
        this.disabled = true; // Disable the button
        loadingIndicator.style.display = "block"; // Show the loading indicator
        this.form.submit(); // Submit the form
    });
}
');

?>