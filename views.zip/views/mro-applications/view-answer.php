<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

$this->title = 'View Answer';
$this->params['breadcrumbs'][] = ['label' => 'Applied Requests', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

?>

<div class="mro-request-view">
    <h1><?= Html::encode($this->title) ?></h1>

    <table class="table table-bordered">
        <tbody>

            <tr>
                <th>MRO ID</th>
                <td><?= Html::encode($mroRequestApplication->mro_id) ?></td>
            </tr>
            <tr>
                <th>Request ID</th>
                <td><?= Html::encode($mroRequestApplication->request_id) ?></td>
            </tr>
            <tr>
                <th>Description</th>
                <td><?= Html::encode($mroRequestApplication->Description) ?></td>
            </tr>
            <tr>
                <th>Price</th>
                <td><?= Html::encode($mroRequestApplication->price) ?></td>
            </tr>
            <!-- Add more rows for additional attributes as needed -->
        </tbody>
    </table>


</div>
