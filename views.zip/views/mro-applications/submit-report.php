<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Submit CRS';
?>
<h1><?= Html::encode($this->title) ?></h1>


<!-- Multi-step progress bar -->
<div class="progress-bar-container">
    <span class="progress-bar-step">Create a Request</span>
    <span class="progress-bar-step ">MRO Quote</span>
    <span class="progress-bar-step ">PO Loaded</span>
    <span class="progress-bar-step ">PO Accepted By MRO</span>
    <span class="progress-bar-step">Work Started</span>
    <span class="progress-bar-step step-active">MRO Report</span>
    <span class="progress-bar-step">AO Feedback</span>
    <span class="progress-bar-step">Request Closed</span>
</div>
</br>
<div class="repair-report-form">

<?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data', 'id' => 'repair-report-form']]); ?>
<div id="loading-spinner" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999;">
    <img src="<?= Yii::getAlias('@web/img/spinner.gif') ?>" alt="Loading..." />
</div>
<div class="row">
    <div class="col-md-3">
      <div class="form-group">
    <label class="form-label">Request ID</label>
    <input type="text" class="form-control background-form" value="<?= Html::encode($model->getRequest()->request_id) ?>" readonly>
</div>

    </div>

    <div class="col-md-9 ">
        <?= $form->field($model, 'CRS_attachment')->fileInput([
            'accept' => 'image/png, image/jpeg, application/pdf'
        ])->label('CRS Attachments' . '<span class="text-danger">*</span>') ?>
    </div>
</div>


<?= $form->field($model, 'report')->textarea(['rows' => 12])->label('Report') ?>

<?= $form->field($model, 'CRSed')->checkbox(['id' => 'crsed-checkbox', 'label' => 'CERTIFICATE OF RELEASE TO SERVICE: Certifies that the work specified except as otherwise specified was carried out in accordance with Part 145 and in respect to that work the aircraft/aircraft component is considered ready for release to service.

']) ?>

<div class="form-group">
    <?= Html::submitButton('Submit', ['class' => 'btn btn-primary','id' => 'submit-button']) ?>
</div>

<?php ActiveForm::end(); ?>
</div>

<?php
$this->registerJs('
    var form = document.getElementById("repair-report-form");
    var submitButton = document.getElementById("submit-button");
    var loadingIndicator = document.getElementById("loading-spinner");

    submitButton.addEventListener("click", function(event) {
        event.preventDefault(); // Prevent default submission

        var fileInput = document.getElementById("repairreport-crs_attachment");
        var checkbox = document.getElementById("crsed-checkbox");

        if (!fileInput.value) {
            alert("Please upload a CRS attachment.");
            return;
        }

        if (!checkbox.checked) {
            alert("You must confirm that the work pack is complete.");
            return;
        }

        // Passed validation
        submitButton.disabled = true;
        loadingIndicator.style.display = "block";
        form.submit(); // Submit after validation
    });
');
?>


