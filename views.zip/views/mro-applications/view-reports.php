<?php

use yii\helpers\Html;

$this->title = 'View Reports';
$this->params['breadcrumbs'][] = ['label' => 'Requests', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $request->request_id, 'url' => ['view', 'id' => $request->request_id]];
$this->params['breadcrumbs'][] = $this->title;

?>
<style>
    .report-column {
        width: 30%!important; /* Makes the column three times wider */
        max-width: 300px; /* Adjust this value as needed */
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .report-column:hover {
        overflow: visible;
        white-space: normal;
    }
</style>
<h1><?= Html::encode($this->title) ?></h1>

<div class="row">
    <div class="col-md-12">
        <h3>Request Details</h3>
        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <td><?= Html::encode($request->request_id) ?></td>
            </tr>
            <!-- Add more details as needed -->
        </table>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <h3>Repair Reports</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="report-column">Report</th>
                    <th>CRS Attachment</th>


                    <!-- Add more columns as needed -->
                </tr>
            </thead>
            <tbody>
                <?php foreach ($repairReports as $report): ?>
                    <tr>
                        <td  class="report-column"><?= Html::encode($report->report) ?></td>
                        <td>
                                <?= Html::a('Download', '@web/uploads/' . $report->CRS_attachment) ?>

                        </td>
                      
                            <?php if (!empty($report->AO_description) && !$existingMro_quote): ?>
                                <?= Html::a('Provide New Quote', ['provide-new-quote', 'id' => $report->repair_report_id], ['class' => 'btn btn-primary']) ?>
                            <?php endif; ?>
                        </td>
                        <!-- Add more cells as needed -->
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
