<?php

namespace app\controllers;

use app\models\AoRequestsApplications;
use Yii;
use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;
use yii\web\Controller;
use yii\data\Pagination;
use yii\web\NotFoundHttpException;
use app\models\Dispute;
use app\models\AoProfile;
use app\models\MroProfile;
use app\models\MroRequestApply;
use app\models\Requests;

class AoMroDisputeController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // Only authenticated users
                        'matchCallback' => function ($rule, $action) {
                            // Allow access only to users with specific user types
                            return in_array(Yii::$app->session->get('user_type'), ['ao', 'mro']);
                        }
                    ],
                ],
            ],
        ];
    }

    // Index action to view all disputes
    public function actionIndex()
    {
        $search = Yii::$app->request->get('search');
        $userId = Yii::$app->user->identity->id; // Assuming this gives the current user's ID
        
        $query = Dispute::find()
            ->leftJoin('ao_profiles', 'disputes.ao_id = ao_profiles.ao_id')
            ->leftJoin('mro_profiles', 'disputes.mro_id = mro_profiles.mro_id')
            ->leftJoin('requests', 'disputes.request_id = requests.request_id')
            ->where(['or',
                ['ao_profiles.ao_id' => $userId],
                ['mro_profiles.mro_id' => $userId],
            ]);
    
        // Apply search filter if search query is provided
        if ($search !== null) {
            $query->andFilterWhere(['like', 'disputes.description', $search])
                ->orFilterWhere(['like', 'disputes.status', $search])
                ->orFilterWhere(['like', 'disputes.created_by', $search])
                ->orFilterWhere(['like', 'disputes.admin_response', $search]);
        }
    
        $countQuery = clone $query;
        $totalCount = $countQuery->count();
    
        $pagination = new Pagination(['totalCount' => $totalCount, 'pageSize' => 20]);
    
        $disputes = $query->offset($pagination->offset)
            ->limit($pagination->limit)
            ->all();
    
        return $this->render('index', [
            'disputes' => $disputes,
            'pagination' => $pagination,
        ]);
    }
    
    
    

    // View a single dispute
    public function actionView($id)
    {
        $dispute = $this->findModel($id);
        return $this->render('view', ['dispute' => $dispute]);
    }

    // Create a new dispute
    public function actionCreate()
    {
        $dispute = new Dispute();
        
        // Load the request data based on user type (AO or MRO)
        if (Yii::$app->session->get('user_type') == 'ao') {
            $aoId = Yii::$app->user->identity->id;
            $requests = AoRequestsApplications::find()
                ->select('ao_requests_applications.request_id, MAX(ao_requests_applications.id) AS max_id')
                ->leftJoin('requests', 'ao_requests_applications.request_id = requests.request_id')
                ->where(['requests.ao_id' => $aoId])
                ->groupBy('ao_requests_applications.request_id')
                ->orderBy(['max_id' => SORT_DESC])
                ->all();
            $requests = ArrayHelper::map($requests, 'request_id', 'request_id');
            $aoProfiles = ArrayHelper::map(AoProfile::find()->all(), 'ao_id', 'username');
            $mroProfiles = [];
        } elseif (Yii::$app->session->get('user_type') == 'mro') {
            $mroId = Yii::$app->user->identity->id;
            $requests = MroRequestApply::find()
                ->select('request_id, MAX(id) AS max_id')
                ->where(['mro_id' => $mroId])
                ->groupBy('request_id')
                ->orderBy(['max_id' => SORT_DESC])
                ->all();
            $requests = ArrayHelper::map($requests, 'request_id', 'request_id');
            $mroProfiles = ArrayHelper::map(MroProfile::find()->all(), 'mro_id', 'username');
            $aoProfiles = [];
        } else {
            $requests = Requests::find()->all();
            $requests = ArrayHelper::map($requests, 'request_id', 'request_id');
            $aoProfiles = ArrayHelper::map(AoProfile::find()->all(), 'ao_id', 'username');
            $mroProfiles = ArrayHelper::map(MroProfile::find()->all(), 'mro_id', 'username');
        }
    
        // Handle form submission
        if ($dispute->load(Yii::$app->request->post()) && $dispute->save()) {
            if (Yii::$app->session->get('user_type') == 'ao') {

            Yii::$app->mailer->compose('dispute_created', ['dispute' => $dispute])
            ->setTo($dispute->getMro()->one()->email)
            
            ->setSubject('dispute created')
            ->send();
    
              //platform notification
                // Call the action to save the notification
                Yii::$app->runAction('notification/save-notification', [
                    'recipientType' => 'mro',
                    'recipientId' => $dispute->mro_id,
                    'message' => 'dispute created.',
                    'actions' => Yii::$app->request->baseUrl . '/disputes,' // Or any route you want

                ]);
            }else if (Yii::$app->session->get('user_type') == 'mro') {

                Yii::$app->mailer->compose('dispute_created', ['dispute' => $dispute])
                ->setTo($dispute->getAo()->one()->email)
                
                ->setSubject('admin dispute respose')
                ->send();
        
                  //platform notification
                    // Call the action to save the notification
                    Yii::$app->runAction('notification/save-notification', [
                        'recipientType' => 'ao',
                        'recipientId' => $dispute->ao_id,
                        'message' => 'admin dispute respose received.',
                        'actions' => Yii::$app->request->baseUrl . '/disputes,' // Or any route you want

                    ]);
                }

            Yii::$app->session->setFlash('success', 'Dispute created successfully.');
            return $this->redirect(['index']);
        }
    
        return $this->render('create', [
            'dispute' => $dispute,
            'requests' => $requests,
            'aoProfiles' => $aoProfiles,
            'mroProfiles' => $mroProfiles,
        ]);
    }
    
    

    // Update an existing dispute
    public function actionUpdate($id)
    {
        $dispute = $this->findModel($id);

        if ($dispute->load(Yii::$app->request->post()) && $dispute->save()) {
            Yii::$app->session->setFlash('success', 'Dispute updated successfully.');
            return $this->redirect(['index']);
        }

        $aoProfiles = AoProfile::find()->all();
        $mroProfiles = MroProfile::find()->all();
        $requests = Requests::find()->all();

        return $this->render('update', [
            'dispute' => $dispute,
            'aoProfiles' => $aoProfiles,
            'mroProfiles' => $mroProfiles,
            'requests' => $requests,
        ]);
    }

    // Close a dispute
    public function actionClose($id)
    {
        $dispute = $this->findModel($id);
        $dispute->status = 'resolved';

        if ($dispute->save()) {
            Yii::$app->session->setFlash('success', 'Dispute closed successfully.');
        } else {
            Yii::$app->session->setFlash('error', 'Failed to close the dispute.');
        }

        return $this->redirect(['index']);
    }

    // Remove a dispute
    public function actionDelete($id)
    {
        $dispute = $this->findModel($id);

        if ($dispute->delete()) {
            Yii::$app->session->setFlash('success', 'Dispute removed successfully.');
        } else {
            Yii::$app->session->setFlash('error', 'Failed to remove the dispute.');
        }

        return $this->redirect(['index']);
    }

    // Find a dispute model by ID
    protected function findModel($id)
    {
        if (($model = Dispute::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested dispute does not exist.');
    }


    public function actionFetchDetails($requestId)
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;

        // Fetch details based on $requestId
        $details = $this->fetchDetails($requestId);

        if ($details === false) {
            return ['success' => false, 'message' => 'Details not found'];
        }

        return [
            'success' => true,
            'ao_id' => $details['ao_id'],
            'mro_id' => $details['mro_id'],
            'po' => $details['po'],
            'mro_username' => $details['mro_username'],
            'ao_username' => $details['ao_username'],

        ];
    }

    /**
     * Fetches AO and MRO details based on the selected request_id.
     * 
     * @param integer $requestId The selected request_id
     * @return array|false An array containing ao_id, mro_id, and po on success, or false on failure
     */
    protected function fetchDetails($requestId)
    {
        // Fetch ao_id and po from AoRequestsApplications
        $aoRequest = AoRequestsApplications::find()
            ->select(['request_id', 'po'])
            ->where(['request_id' => $requestId])
            ->orderBy(['id' => SORT_DESC])
            ->limit(1)
            ->one();

        if ($aoRequest !== null) {
            $aoId =  Requests::findOne($aoRequest->request_id)->ao_id ;
            $po = $aoRequest->po;

            // Fetch mro_id from MroRequestApply using ao_id and request_id
            $mroRequest = MroRequestApply::find()
                ->select(['mro_id'])
                ->where(['request_id' => $requestId])
                ->orderBy(['id' => SORT_DESC])
                ->limit(1)
                ->one();

            if ($mroRequest !== null) {
                $mroId = $mroRequest->mro_id;
                $ao_username = AoProfile::findOne($aoId)->username;
                $mro_username = MroProfile::findOne($mroId)->username;

                return ['mro_username' => $mro_username, 'ao_username' => $ao_username, 'ao_id' => $aoId, 'mro_id' => $mroId, 'po' => $po];
            }
        }

        return false; // Return false if either ao_id or mro_id is not found
    }

}
