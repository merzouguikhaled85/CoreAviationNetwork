<?php

namespace app\controllers;

use app\models\AoNotificationsPreferences;
use app\models\AoProfile;
use app\models\MroAircraftCertificate;
use Yii;
use yii\db\ActiveRecord;
use yii\web\Controller;
use app\models\Requests;
use app\models\Certificates;
use app\models\Conversations;
use app\models\Chat;
use app\models\MroProfile;
use app\models\MroprofileAirport;
use app\models\MroRequestApply;
use yii\helpers\VarDumper;
use yii\web\UploadedFile;
use yii\filters\AccessControl;

class MroRequestsController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // Only authenticated users
                        'matchCallback' => function ($rule, $action) {
                            // Allow access only to users with specific user types
                            return in_array(Yii::$app->session->get('user_type'), ['mro']);
                        }
                    ],
                ],
            ],
        ];
    }
    public function actionIndex()
    {
        // Get the MRO's ID from the session
        $mro_id = Yii::$app->session->get('mro_id');
    
        // Fetch requests with status "answered" or "created"
        $requests = Requests::find()
            ->where(['status' => ['answered', 'created']])
            ->andWhere([
                'IN',
                'required_certificates',
                Certificates::find()
                    ->select('type')
                    ->where(['mro_id' => $mro_id])
            ])
            // Filter requests where location matches MroprofileAirport->airport_id
            ->andWhere([
                'destination' => MroprofileAirport::find()
                    ->select('airport_id')
                    ->where(['mro_id' => $mro_id])
            ])
            // Add condition to check if MRO has the aircraft model ID for each request
            ->andWhere([
                'EXISTS',
                MroAircraftCertificate::find()
                    ->where('mro_aircraft_certificate.aircraft_model_id = aircrafts.aircraft_model_id') // Assuming you will join aircrafts
                    ->andWhere(['mro_aircraft_certificate.mro_id' => $mro_id])
                    ->andWhere(['aircrafts.aircraft_id' => new \yii\db\Expression('requests.aircraft_id')]) // Join condition for aircraft_id
            ])
            ->joinWith('aircraft') // Ensure that you join the aircraft relation
            ->orderBy(['request_id' => SORT_DESC]) // Order by request_id descending

            ->all();
    
        $title = "New requests";
    
        // Render the view with the fetched requests
        return $this->render('index', [
            'requests' => $requests,
            'title' => $title,
        ]);
    }
    

 
    

    public function actionContact($id)
    {
        // Check if a conversation already exists for the given request
        $conversation = Conversations::findOne(['request_id' => $id]);
    
        // If conversation does not exist, create a new one
        if (!$conversation) {
            // Create a new chat
            $chat = new Chat();
            $chat->mro_id = Yii::$app->session->get('mro_id');
            $chat->ao_id = Requests::findOne(['request_id' => $id])->ao_id;
            $chat->request_id = $id;

            $chat->save();
    
            // Create a new conversation
            $conversation = new Conversations();
            $conversation->request_id = $id;
            $conversation->chat_id = $chat->chat_id;
            $conversation->sender_id = Yii::$app->session->get('mro_id');
            $conversation->sender_type ='mro';
            $conversation->receiver_id = $chat->ao_id;
            $conversation->receiver_type ='ao';
            // Additional attributes initialization if needed
            $conversation->save();

              //platform notification
              $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $chat->ao_id]);
              if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_by_platform) {
                // Call the action to save the notification
                Yii::$app->runAction('notification/save-notification', [
                    'recipientType' => 'ao',
                    'recipientId' => $chat->ao_id,
                    'message' => 'New message recived.',
                    'actions' =>  Yii::$app->request->baseUrl .'/conversations/view?chat_id=' . $conversation->chat_id, // Or any route you want
                ]);
            }
        }
    
        // Redirect to view the conversation
        return $this->redirect(['conversations/view', 'chat_id' => $conversation->chat_id]);
    }
    

// In your controller file, add the Apply action method
public function actionApply($id)
{
    // Load the request by its ID
    $request = Requests::findOne($id);

    // Create a new instance of the MRO request apply model
    $model = new MroRequestApply();
    $model->mro_id = Yii::$app->session->get('mro_id');
    // Set the request ID
    $model->request_id = $id;
    // Check if the form is submitted and the model is validated
    if ($model->load(Yii::$app->request->post()) && $model->validate()) {
                // Handle file upload
                $model->attachment = UploadedFile::getInstance($model, 'attachment');

                if ($model->attachment) {
                    // Generate a unique filename
                    $fileName = Yii::$app->security->generateRandomString(20) . '.' . $model->attachment->extension;
        
                    // Save the file to web/uploads folder
                    $uploadPath = Yii::getAlias('@webroot/uploads/');
                    $model->attachment->saveAs($uploadPath . $fileName);
        
                    // Set the file path in the model attribute
                    $model->attachment = 'uploads/' . $fileName;
                }
        // Set the MRO ID
        $model->mro_id = Yii::$app->session->get('mro_id');
        // Set the request ID
        $model->request_id = $id;

        // Save the model
        if ($model->save()) {


            $ao = $request->aO;
            $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $ao->ao_id]);
            if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_mro_replies && $aoNotificationsPreferences->notify_by_email) {
                Yii::$app->mailer->compose('mro_replies', ['MroRequestApply' => $model])
                    ->setTo($ao->email)
                    
                    ->setSubject('New request application')
                    ->send();
                }
                                                  //platform notification
                                                  if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_mro_replies && $aoNotificationsPreferences->notify_by_email) {
                                                    // Call the action to save the notification
                                                    Yii::$app->runAction('notification/save-notification', [
                                                        'recipientType' => 'ao',
                                                        'recipientId' => $ao->ao_id,
                                                        'message' => 'New request application recived.',
                                                        'actions' =>  Yii::$app->request->baseUrl .'/requests/new-requests', // Or any route you want

                                                    ]);
                                                }

              // Update the request status to "answered"
              $request->status = 'answered';
              $request->save();
              
            // Redirect to a relevant page (e.g., view page, index page)
            Yii::$app->session->setFlash('success', 'Reply and quote saved successfully.');
            return $this->redirect(['index']);
        } else {
            Yii::$app->session->setFlash('error', 'Failed to save reply and quote.');

        }
    }

    // Render the apply view with the request and model
    return $this->render('apply', [
        'request' => $request,
        'model' => $model,
    ]);
}
// In your controller file, add the Apply action method
public function actionApplyupdate($id)
{
    // Load the request by its ID
    //VarDumper::dump($id); die();

    // Create a new instance of the MRO request apply model
    $model = MroRequestApply::findOne($id);
    $request = Requests::findOne($model->request_id);

    // Check if the form is submitted and the model is validated
    if ($model->load(Yii::$app->request->post()) && $model->validate()) {
                // Handle file upload
                $model->attachment = UploadedFile::getInstance($model, 'attachment');

                if ($model->attachment) {
                    // Generate a unique filename
                    $fileName = Yii::$app->security->generateRandomString(20) . '.' . $model->attachment->extension;
        
                    // Save the file to web/uploads folder
                    $uploadPath = Yii::getAlias('@webroot/uploads/');
                    $model->attachment->saveAs($uploadPath . $fileName);
        
                    // Set the file path in the model attribute
                    $model->attachment = 'uploads/' . $fileName;
                }
        // Set the MRO ID
        $model->mro_id = Yii::$app->session->get('mro_id');


        // Save the model
        if ($model->save()) {


            $ao = $request->aO;
            $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $ao->ao_id]);
            if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_mro_replies && $aoNotificationsPreferences->notify_by_email) {
                Yii::$app->mailer->compose('mro_replies', ['MroRequestApply' => $model])
                    ->setTo($ao->email)
                    
                    ->setSubject('New request application')
                    ->send();
                }
                                                  //platform notification
                                                  if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_mro_replies && $aoNotificationsPreferences->notify_by_email) {
                                                    // Call the action to save the notification
                                                    Yii::$app->runAction('notification/save-notification', [
                                                        'recipientType' => 'ao',
                                                        'recipientId' => $ao->ao_id,
                                                        'message' => 'New request application recived.',
                                                        'actions' =>  Yii::$app->request->baseUrl .'/requests/new-requests', // Or any route you want

                                                    ]);
                                                }

              // Update the request status to "answered"
              $request->status = 'answered';
              $request->save();
              
            // Redirect to a relevant page (e.g., view page, index page)
            Yii::$app->session->setFlash('success', 'Reply and quote saved successfully.');
            return $this->redirect(['index']);
        } else {
            Yii::$app->session->setFlash('error', 'Failed to save reply and quote.');

        }
    }

    // Render the apply view with the request and model
    return $this->render('applyupdate', [
        'request' => $request,
        'model' => $model,
    ]);
}

    public function actionRecommendMro($id)
    {
        $mro_id = Yii::$app->session->get('mro_id');
        $request = Requests::findOne($id);
        $model = new MroProfile();
    
        // Fetch all certificates where type matches required_certificates from request
        $certifs = Certificates::find()
            ->where(['type' => $request->required_certificates])
            ->asArray()
            ->all();
    
        $mro_ids = array_column($certifs, 'mro_id');
        $mros = MroProfile::find()
            ->where(['mro_id' => $mro_ids])
            ->andWhere(['<>', 'mro_id', $mro_id])
            ->all();
    
        if (Yii::$app->request->isPost) {
            $selectedMroId = Yii::$app->request->post('MroProfile')['mro_id'];

            if ($selectedMroId) {
                // Fetch the aircraft owner email using ao_id
                $aircraftOwner = AoProfile::findOne($request->ao_id);
                if ($aircraftOwner) {
                    $aoEmail = $aircraftOwner->email;
                    // Check AO's notification preferences
                    $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $aircraftOwner->ao_id]);

                    // Check if preferences exist and AO has opted for email notifications for MRO recommendations
                    if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_mro_recommendations && $aoNotificationsPreferences->notify_by_email) {
     
                    Yii::$app->mailer->compose('mro_profile_recommendation', [
                        'request' => $request->request_id,
                        'recommendationFrom' => MroProfile::findOne($mro_id)->username,
                        'recommendedMro' => MroProfile::findOne($selectedMroId)->username,
                    ])->setTo($aoEmail)
                        
                        ->setSubject('MRO Profile Recommendation')
                        ->send();
                    }

                                                  //platform notification
                                                  if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_mro_recommendations && $aoNotificationsPreferences->notify_by_platform) {
                                                    // Call the action to save the notification
                                                    Yii::$app->runAction('notification/save-notification', [
                                                        'recipientType' => 'ao',
                                                        'recipientId' => $aircraftOwner->ao_id,
                                                        'message' => 'New mro recommendation recived.',
                                                        'actions' =>  Yii::$app->request->baseUrl .'/conversations', // Or any route you want

                                                    ]);
                                                }
                    // Set a success flash message
                    Yii::$app->session->setFlash('success', 'MRO profile recommended successfully and email sent to the aircraft owner.');
    
                    // Check if a conversation already exists for the given request
                    $conversation = Conversations::findOne(['request_id' => $id]);
    
                    // If conversation does not exist, create a new one
                    if (!$conversation) {
                        // Create a new chat
                        $chat = new Chat();
                        $chat->mro_id = $mro_id;
                        $chat->ao_id = $request->ao_id;
                        $chat->request_id = $id;
                        $chat->save();
    
                        // Create a new conversation
                        $conversation = new Conversations();
                        $conversation->request_id = $id;
                        $conversation->chat_id = $chat->chat_id;
                        $conversation->sender_id = $chat->mro_id;
                        $conversation->sender_type = 'mro';
                        $conversation->receiver_id = $chat->ao_id;
                        $conversation->receiver_type = 'ao';
                        $conversation->message ="Dear Aircraft Owner, We have recommended the following MRO profile for your aircraft request Mro username : ".MroProfile::findOne($selectedMroId)->username;
                        $conversation->save();
                    }
    
                    // Redirect to view the conversation
                    return $this->redirect(['conversations/view', 'chat_id' => $conversation->chat_id]);
                } else {
                    Yii::$app->session->setFlash('error', 'Aircraft owner not found.');
                }
            } else {
                Yii::$app->session->setFlash('error', 'No MRO selected.');
            }
    
            return $this->redirect(['index']);
        }
    
        return $this->render('recommend-mro', [
            'requests' => $mros,
            'model' => $model,
        ]);
    }
    
    
    
    
}
