<?php

namespace app\controllers;

use app\models\AoNotificationsPreferences;
use app\models\AoProfile;
use app\models\AoRequestsApplications;
use app\models\Appointment;
use app\models\Chat;
use app\models\Conversations;
use app\models\Feedback;
use app\models\RepairReport;
use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use app\models\MroRequestApply;
use app\models\Requests;
use yii\helpers\VarDumper;
use yii\web\NotFoundHttpException;
use yii\web\UploadedFile;

class MroApplicationsController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // Only authenticated users
                        'matchCallback' => function ($rule, $action) {
                            // Allow all actions for 'mro' user type
                            if (Yii::$app->session->get('user_type') == 'mro') {
                                return true; // Allow access to all actions for 'mro'
                            }
                            
                            // Allow 'view-answer' action for 'ao' user type
                            if (Yii::$app->session->get('user_type') == 'ao' && $action->id === 'view-answer') {
                                return true; // Allow access to 'view-answer' for 'ao'
                            }
                            
                            return false; // Deny access for other cases
                        }
                    ],
                ],
            ],
        ];
    }
    
    public function actionIndex()
    {
        // Retrieve the MRO user's ID
        $mro_id = Yii::$app->session->get('mro_id');
        
        // Query for all requests that the MRO is applied in
        $appliedRequests = MroRequestApply::find()
            ->where(['mro_id' => $mro_id])
            ->orderBy(['request_id' => SORT_DESC])// Order by request_id descending

            ->all();
             // Filter out applied requests where the corresponding Request record no longer exists
    $filteredRequests = [];
    foreach ($appliedRequests as $appliedRequest) {
        if (Requests::findOne($appliedRequest->request_id) !== null && !in_array(Requests::findOne($appliedRequest->request_id)->status, ['closed', 'created', 'answered'])) {
            $filteredRequests[] = $appliedRequest;
        }
    }
    $title = "Open Requests";

        // Render the view and pass the applied requests data
        return $this->render('index', [
            'appliedRequests' => $filteredRequests,
            'title' => $title,

        ]);
    }

    public function actionClosedRequests()
    {

          // Retrieve the MRO user's ID
          $mro_id = Yii::$app->session->get('mro_id');
        
          // Query for all requests that the MRO is applied in
          $appliedRequests = MroRequestApply::find()
              ->where(['mro_id' => $mro_id])
              ->all();
               // Filter out applied requests where the corresponding Request record no longer exists
      $filteredRequests = [];
      foreach ($appliedRequests as $appliedRequest) {
          if (Requests::findOne($appliedRequest->request_id) !== null && in_array(Requests::findOne($appliedRequest->request_id)->status, ['closed'])) {
              $filteredRequests[] = $appliedRequest;
          }
      }
      $title = "Closed Requests";

          // Render the view and pass the applied requests data
          return $this->render('index', [
              'appliedRequests' => $filteredRequests,
              'title' => $title,

          ]);
    
    }

    public function actionViewAnswer($id)
    {
        // Find the mroRequestsApplications record by ID
        $mroRequestApplication = MroRequestApply::findOne($id);

        if ($mroRequestApplication) {
            // You can render a view or perform any other necessary actions here
            return $this->render('view-answer', [
                'mroRequestApplication' => $mroRequestApplication,
            ]);
        } else {
            // Handle the case when the record is not found
            throw new \yii\web\NotFoundHttpException('The requested page does not exist.');
        }
    }
    public function actionCancelApplication($id)
{
    $mroRequestApplication = MroRequestApply::findOne($id);
    if ($mroRequestApplication) {
        $requestId = $mroRequestApplication->request_id;
        $mroRequestApplication->delete();

        // Check if there are no more applications for the request
        $applicationsCount = MroRequestApply::find()->where(['request_id' => $requestId])->count();
        if ($applicationsCount === 0) {
            // Update request status to 'created'
            $request = Requests::findOne($requestId);
            if ($request) {
                $request->status = 'created';
                $request->save();
            }
        }

        Yii::$app->session->setFlash('success', 'Application canceled successfully.');
    } else {
        Yii::$app->session->setFlash('error', 'Failed to cancel application.');
    }

    return $this->redirect(['index']);
}
public function actionViewPo($id)
{
    $aoRequestsApplications = AoRequestsApplications::find()->where(['application_id' => $id])->all();

    return $this->render('view-po', [
        'aoRequestsApplications' => $aoRequestsApplications,
    ]);
}
public function actionAcceptPo($id)
{
    // Find the AoRequestsApplications record by ID
    $aoRequestApplication = AoRequestsApplications::findOne($id);

    if ($aoRequestApplication) {
        // Update the request status to WORK_ACCEPTED
        $request = $aoRequestApplication->getRequest()->one();
        $request->status = 'work_accepted';
        $request->save();

        // Send email notification to the AO
        $ao = $request->aO;
        $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $ao->ao_id]);

        if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_po_acceptance && $aoNotificationsPreferences->notify_by_email) {
        Yii::$app->mailer->compose('ao_application_accepted', ['application' => $aoRequestApplication])
            ->setTo($ao->email)
            
            ->setSubject('PO Accepted')
            ->send();
        }
                              //platform notification
                              if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_po_acceptance && $aoNotificationsPreferences->notify_by_platform) {
                                // Call the action to save the notification
                                Yii::$app->runAction('notification/save-notification', [
                                    'recipientType' => 'ao',
                                    'recipientId' => $ao->ao_id,
                                    'message' => 'The PO has been accepted.',
                                'actions' =>  Yii::$app->request->baseUrl .'/requests/open-requests', // Or any route you want

                                ]);
                            }
        // You can perform any additional actions here, such as redirecting to another page or displaying a success message
        Yii::$app->session->setFlash('success', 'PO accepted successfully.');

        return $this->redirect(['index']); // Redirect to the index page of MRO applications
    } else {
        // Handle the case when the record is not found
        throw new \yii\web\NotFoundHttpException('The requested page does not exist.');
    }
}

public function actionSetAppointment($app_request_id)
{
    $appointment = new Appointment();
    $application = MroRequestApply::findOne($app_request_id);

    if (!$application) {
        throw new \yii\web\NotFoundHttpException('The requested application does not exist.');
    }

    if (Yii::$app->request->isPost) {

        $appointment->load(Yii::$app->request->post());
                    // Convert to proper MySQL DATETIME format
    if (!empty($appointment->appointment_date)) {
        $appointment->appointment_date = date('Y-m-d H:i:s', strtotime($appointment->appointment_date));
    }
        $appointment->mro_id = Yii::$app->session->get('mro_id');
        $appointment->ao_id = $application->getRequest()->one()->ao_id;
        $appointment->request_id = $application->request_id;
        $appointment->ao_requests_applications_id = $app_request_id;
        $appointment->status = 'waiting response';


        if ($appointment->save()) {
            // Send email notification to the AO
            $ao = AoProfile::findOne($appointment->ao_id) ;
            $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $ao->ao_id]);

            if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_appointment_requests && $aoNotificationsPreferences->notify_by_email) {
            Yii::$app->mailer->compose('appointment_created', ['application' => $appointment])
                ->setTo($ao->email)
                
                ->setSubject('New appointment request')
                ->send();
            }
                              //platform notification
                              if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_appointment_requests && $aoNotificationsPreferences->notify_by_platform) {
                                // Call the action to save the notification
                                Yii::$app->runAction('notification/save-notification', [
                                    'recipientType' => 'ao',
                                    'recipientId' => $ao->ao_id,
                                    'message' => 'A new appointment has been requested.',
                                        'actions' =>  Yii::$app->request->baseUrl .'/ao-appointments', // Or any route you want

                                ]);
                            }
            Yii::$app->session->setFlash('success', 'Appointment set successfully.');
            return $this->redirect(['mro-applications/index']);
        } else {
            Yii::$app->session->setFlash('error', 'Failed to set appointment.');
        }
    }

    return $this->render('set-appointment', [
        'appointment' => $appointment,
        'application' => $application,
    ]);
}

public function actionStartWork($id)
{
    $request = Requests::findOne($id);
    if ($request) {
        $request->status = 'work_started';
        if ($request->save()) {

            // Send email notification to the AO
            $ao = $request->aO;
            $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $ao->ao_id]);
            if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_work_start && $aoNotificationsPreferences->notify_by_email) {
                Yii::$app->mailer->compose('work_started', ['request' => $request])
                    ->setTo($ao->email)
                    
                    ->setSubject('Work Started')
                    ->send();
                }

                
                  //platform notification
                  if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_work_start && $aoNotificationsPreferences->notify_by_platform) {
                    // Call the action to save the notification
                    Yii::$app->runAction('notification/save-notification', [
                        'recipientType' => 'ao',
                        'recipientId' => $ao->ao_id,
                        'message' => 'The work has been started for your request',
                                                                'actions' =>  Yii::$app->request->baseUrl .'/requests/open-requests', // Or any route you want

                    ]);
                }

            Yii::$app->session->setFlash('success', 'Work has been started successfully');
        } else {
            Yii::$app->session->setFlash('error', 'Failed to start work.');
        }
    } else {
        Yii::$app->session->setFlash('error', 'Request not found.');
    }

    return $this->redirect(['index']);
}

public function actionSubmitReport($id)
{
    $request = MroRequestApply::findOne($id);

    if (!$request) {
        throw new NotFoundHttpException('Request not found.');
    }

    $model = new RepairReport();
    $model->mro_request_apply_id = $request->id;

    if ($model->load(Yii::$app->request->post())) {
        // Retrieve the uploaded file instance
        $model->CRS_attachment = UploadedFile::getInstance($model, 'CRS_attachment');
        // Check if the file was uploaded
        if ($model->CRS_attachment) {
            // Generate a unique file name
            $fileName = 'upload_' . Yii::$app->security->generateRandomString(10) . '.' . $model->CRS_attachment->extension;
            // Move the uploaded file to the desired location
            $model->CRS_attachment->saveAs('uploads/' . $fileName);
            // Set the full path to the model attribute
            $model->CRS_attachment =  $fileName;
        }
       // die();
        if ($model->save()) {
            // Send email notification to the AO
            $ao = Requests::findOne($request->request_id)->aO ;
            
            $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $ao->ao_id]);
            if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_report_submissions && $aoNotificationsPreferences->notify_by_email) {
                Yii::$app->mailer->compose('report_submissions', ['RepairReport' => $model])
                    ->setTo($ao->email)
                    
                    ->setSubject('New report submited')
                    ->send();
                }

                  //platform notification
                  if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_report_submissions && $aoNotificationsPreferences->notify_by_platform) {
                    // Call the action to save the notification
                    Yii::$app->runAction('notification/save-notification', [
                        'recipientType' => 'ao',
                        'recipientId' => $ao->ao_id,
                        'message' => 'A new report has been submitted for your request.',
                                                                                        'actions' =>  Yii::$app->request->baseUrl .'/requests/open-requests', // Or any route you want

                    ]);
            }

            // Update the status of the request if CRS is checked
           // if ($model->CRSed) {
                $brequest = $model->getRequest();
                $brequest->status = 'report_submitted';
                $brequest->save(false); // Save the request without validation
            //}

            Yii::$app->session->setFlash('success', 'Report submitted successfully.');
            return $this->redirect(['index']);
        }
    }

    return $this->render('submit-report', [
        'model' => $model,
    ]);
}
public function actionViewReports($id)
{
    // Find the request by ID
    $request = MroRequestApply::findOne($id);

    // Check if the request exists
    if (!$request) {
        throw new NotFoundHttpException('Request not found.');
    }

    // Find all repair reports related to the request
    $repairReports = RepairReport::find()->where(['mro_request_apply_id' => $id])->all();

    return $this->render('view-reports', [
        'request' => $request,
        'repairReports' => $repairReports,
    ]);
}
public function actionProvideNewQuote($id)
{
    $report = RepairReport::findOne($id);

    if (!$report) {
        throw new NotFoundHttpException('Report not found.');
    }

    // Check if the request has already been submitted
    if (!empty($report->mro_quote)) {
        Yii::$app->session->setFlash('error', 'A quote has already been provided for this report.');
        return $this->redirect(['view-reports', 'id' => $report->mro_request_apply_id]);
    }

    if (Yii::$app->request->isPost) {
        $post = Yii::$app->request->post();
        
        // Load the uploaded file into $mroAttachment
        $mroAttachment = UploadedFile::getInstance($report, 'mro_attachment');
        
        // Validate and save the provided quote and attachment to the repair report
        $report->mro_quote = $post['RepairReport']['mro_quote'];

        if ($mroAttachment !== null) {
            $uploadPath = Yii::getAlias('@webroot/uploads/');
            $fileName = Yii::$app->security->generateRandomString(12) . '.' . $mroAttachment->extension;
            $filePath = $uploadPath . $fileName;

            if ($mroAttachment->saveAs($filePath)) {
                $report->mro_attachment = 'uploads/' . $fileName;
            } else {
                Yii::$app->session->setFlash('error', 'Failed to upload attachment.');
                return $this->refresh(); // Reload the page to show errors
            }
        }

        if ($report->save()) {
            Yii::$app->session->setFlash('success', 'New quote provided successfully.');
            return $this->redirect(['view-reports', 'id' => $report->mro_request_apply_id]);
        } else {
            Yii::$app->session->setFlash('error', 'Failed to save the new quote.');
        }
    }

    return $this->render('provide-new-quote', [
        'report' => $report,
    ]);
}

public function actionAcceptUpdate($id)
{
    $request = Requests::findOne($id);

    $mroRequest = MroRequestApply::find()
    ->where(['request_id' => $id])
    ->orderBy(['id' => SORT_DESC])
    ->one();
    // Ensure the current status is update_request
    if ($request->status !== Requests::STATUS_UPDATE_REQUEST) {
        throw new NotFoundHttpException('Invalid request status.');
    }

    // Set status to update_request_accepted
    $request->status = Requests::STATUS_UPDATE_REQUEST_ACCEPTED;

    // Save the updated status
    if ($request->save()) {

        $ao = $request->aO;
        $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $ao->ao_id]);
        if ($aoNotificationsPreferences &&  $aoNotificationsPreferences->notify_by_email) {
            Yii::$app->mailer->compose('update_request_approved', ['request' => $request])
            ->setTo($request->aO->email)
            
            ->setSubject('Update Request Approved')
            ->send();
            }
                                              //platform notification
                                              if ($aoNotificationsPreferences &&  $aoNotificationsPreferences->notify_by_platform) {
                                                // Call the action to save the notification
                                                Yii::$app->runAction('notification/save-notification', [
                                                    'recipientType' => 'ao',
                                                    'recipientId' => $ao->ao_id,
                                                    'message' => 'Update request approved.',
                                                                                                                    'actions' =>  Yii::$app->request->baseUrl .'/requests/new-requests', // Or any route you want

                                                ]);
                                            }


        Yii::$app->session->setFlash('success', 'Update request accepted successfully.');
    } else {
        Yii::$app->session->setFlash('error', 'Failed to accept update request.');
    }

    return $this->redirect(['mro-requests/applyupdate', 'id' => $mroRequest->id]);
}
public function actionDenyRequest($id)
{
    $request = Requests::findOne($id);

    // Initially set the status to update_request_denied
    $request->status = Requests::STATUS_UPDATE_REQUEST_DENIED;

    // Save the updated status
    if ($request->save()) {
        $ao = $request->aO;
        $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $ao->ao_id]);

        // Sending email notification
        if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_by_email) {
            Yii::$app->mailer->compose('update_request_denied', ['request' => $request])
                ->setTo($request->aO->email)
                
                ->setSubject('Update Request Denied')
                ->send();
        }

        // Sending platform notification
        if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_by_platform) {
            Yii::$app->runAction('notification/save-notification', [
                'recipientType' => 'ao',
                'recipientId' => $ao->ao_id,
                'message' => 'Update request Denied.',
            ]);
        }


            $request->status = Requests::STATUS_WORK_STARTED;
            $message = 'Work continued successfully.';
       

        if ($request->save()) {
            Yii::$app->session->setFlash('success', $message);
        } else {
            Yii::$app->session->setFlash('error', 'Failed to update request status.');
        }
    } else {
        Yii::$app->session->setFlash('error', 'Failed to deny request update.');
    }

    return $this->redirect(['index']);
}

public function actionViewFeedback($id)
{
    // Load the request based on $id
    $request = Requests::findOne($id);

    if (!$request) {
        throw new NotFoundHttpException('The requested page does not exist.');
    }

    // Check if the request is closed and if there's existing feedback
    if ($request->status == 'closed') {
        $feedback = Feedback::findOne(['request_id' => $request->request_id]);

        if ($feedback) {
            // Render the view for feedback
            return $this->render('view-feedback', [
                'feedback' => $feedback,
                'request' =>$request,
            ]);
        } else {
            // If there's no feedback found, handle accordingly
            Yii::$app->session->setFlash('error', 'No feedback found for this request.');
        }
    } else {
        // Handle case where request is not closed
        Yii::$app->session->setFlash('error', 'Feedback can only be viewed for closed requests.');
    }

    // Redirect back to the request view or any appropriate action
    return $this->redirect(['index']);
}

public function actionContact($id)
{
    $mroRequestApplication = MroRequestApply::findOne($id);
    // Check if a conversation already exists for the given request
    $conversation = Conversations::findOne(['request_id' => $mroRequestApplication->request_id]);

    // If conversation does not exist, create a new one
    if (!$conversation) {
        // Create a new chat
        $chat = new Chat();
        $chat->mro_id =  $mroRequestApplication->mro_id;
        $chat->ao_id = $mroRequestApplication->getRequest()->one()->ao_id;
        $chat->request_id =  $mroRequestApplication->request_id;

        $chat->save();

        // Create a new conversation
        $conversation = new Conversations();
        $conversation->request_id =  $mroRequestApplication->request_id;
        $conversation->chat_id = $chat->chat_id;
        $conversation->sender_id = $chat->mro_id;
        $conversation->sender_type ='mro';
        $conversation->receiver_id = $chat->ao_id;
        $conversation->receiver_type ='ao';
        // Additional attributes initialization if needed
        $conversation->save();

          //platform notification
          $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $chat->ao_id]);
          if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_by_platform) {
            // Call the action to save the notification
            Yii::$app->runAction('notification/save-notification', [
                'recipientType' => 'ao',
                'recipientId' => $chat->ao_id,
                'message' => 'New message recived.',
            ]);
        }
    }

    // Redirect to view the conversation
    return $this->redirect(['conversations/view', 'chat_id' => $conversation->chat_id]);
}


}
