<?php
namespace app\controllers;

use app\models\AoProfile;
use Yii;
use yii\web\Controller;
use app\models\Appointment;
use yii\filters\AccessControl;
use yii\web\NotFoundHttpException;

class MroAppointmentsController extends Controller
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // Only authenticated users
                        'matchCallback' => function ($rule, $action) {
                            // Allow access only to users with specific user types
                            return in_array(Yii::$app->session->get('user_type'), ['mro']);
                        }
                    ],
                ],
            ],
        ];
    }
    public function actionIndex()
    {
        // Retrieve the MRO user's ID
        $mro_id = Yii::$app->session->get('mro_id');
        
        if (!$mro_id) {
            Yii::$app->session->setFlash('error', 'You are not logged in as an MRO.');
            return $this->redirect(['site/login']);
        }

        // Query for all appointments associated with the MRO
        $appointments = Appointment::find()
            ->where(['mro_id' => $mro_id])
            ->all();

        // Render the view and pass the appointments data
        return $this->render('index', [
            'appointments' => $appointments,
        ]);
    }
    public function actionRemoveAppointment($id)
{
    $appointment = Appointment::findOne($id);

    if ($appointment) {

        $ao =AoProfile::findOne($appointment->ao_id);
            
        Yii::$app->mailer->compose('appointment_deleted', ['appointment' => $appointment])
            ->setTo($ao->email)
            
            ->setSubject('appointment deleted')
            ->send();

              //platform notification
                // Call the action to save the notification
                Yii::$app->runAction('notification/save-notification', [
                    'recipientType' => 'ao',
                    'recipientId' => $ao->ao_id,
                    'message' => 'Your appointment has been deleted.',
                                                                            'actions' =>  Yii::$app->request->baseUrl .'/ao-appointments', // Or any route you want

                ]);
        

        // Delete the appointment
        if ($appointment->delete()) {
            Yii::$app->session->setFlash('success', 'Appointment removed successfully.');
        } else {
            Yii::$app->session->setFlash('error', 'Failed to remove appointment.');
        }
    } else {
        Yii::$app->session->setFlash('error', 'Appointment not found.');
    }

    return $this->redirect(['index']);
}
public function actionAcceptReschedule($id)
{
    $appointment = Appointment::findOne($id);

    if (!$appointment) {
        throw new NotFoundHttpException("Appointment not found with ID: $id");
    }

    if ($appointment->status === 'reschedule') {
        $appointment->appointment_date = $appointment->reschedule_appointment_date;
        $appointment->status = 'confirmed'; // Assuming you want to confirm the appointment after accepting the reschedule

        if ($appointment->save()) {
            $ao =AoProfile::findOne($appointment->ao_id);
            
        Yii::$app->mailer->compose('appointment_confirmed', ['appointment' => $appointment])
            ->setTo($ao->email)
            
            ->setSubject('appointment confirmed')
            ->send();

              //platform notification
                // Call the action to save the notification
                Yii::$app->runAction('notification/save-notification', [
                    'recipientType' => 'ao',
                    'recipientId' => $ao->ao_id,
                    'message' => 'Your appointment has been confirmed.',
                                                                                                'actions' =>  Yii::$app->request->baseUrl .'/ao-appointments', // Or any route you want

                ]);
        
            Yii::$app->session->setFlash('success', 'Appointment reschedule date accepted.');
        } else {
            Yii::$app->session->setFlash('error', 'Failed to accept reschedule appointment date.');
        }
    } else {
        Yii::$app->session->setFlash('error', 'Appointment cannot be accepted. Status is not "reschedule".');
    }

    return $this->redirect(['index']); // Redirect to appointments list page
}

}
