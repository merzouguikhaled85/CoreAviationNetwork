<?php

namespace app\controllers;

use Yii;
use app\models\MroProfile;
use app\models\MroAircraftCertificate;
use app\models\AircraftModel;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\UploadedFile;
use yii\data\Pagination;
use yii\helpers\VarDumper;
use yii\web\Response;

class MroAircraftCertificatesController extends Controller
{


    /**
     * Displays all aircraft certificates associated with a specific MRO profile.
     * @param int $mro_id
     * @return string
     * @throws NotFoundHttpException
     */
    public function actionIndex()
    {
        $mro_id = Yii::$app->session->get('mro_id');
    
        $mroProfile = MroProfile::findOne($mro_id);
        if (!$mroProfile) {
            throw new NotFoundHttpException('MRO profile not found.');
        }
    
        $query = MroAircraftCertificate::find()->where(['mro_id' => $mro_id]);
    
        // Handle search if search query parameter is provided
        $search = Yii::$app->request->get('search');
        if ($search) {
            // Join with the aircraft_model table to search for manufacturer or model name
            $query->joinWith('aircraftModel')
                  ->andWhere(['or', 
                      ['like', 'certificate', $search],
                      ['like', 'aircraft_model.manufacturer', $search],
                      ['like', 'aircraft_model.model', $search]
                  ]);
        }
    
        $pagination = new Pagination([
            'defaultPageSize' => 20,
            'totalCount' => $query->count(),
        ]);
    
        $certificates = $query->offset($pagination->offset)
            ->limit($pagination->limit)
            ->all();
    
        return $this->render('index', [
            'mroProfile' => $mroProfile,
            'certificates' => $certificates,
            'pagination' => $pagination,
        ]);
    }
    

    /**
     * Displays a specific aircraft certificate.
     * @param int $id
     * @return string
     * @throws NotFoundHttpException
     */
    public function actionView($id)
    {
        $certificate = MroAircraftCertificate::findOne($id);
        if (!$certificate) {
            throw new NotFoundHttpException('Aircraft certificate not found.');
        }

        return $this->render('view', [
            'certificate' => $certificate,
        ]);
    }

    /**
     * Creates a new aircraft certificate associated with an MRO profile.
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException
     */
    public function actionCreate()
    {
        $mro_id = Yii::$app->session->get('mro_id');

        $mroProfile = MroProfile::findOne($mro_id);
        if (!$mroProfile) {
            throw new NotFoundHttpException('MRO profile not found.');
        }

        $certificate = new MroAircraftCertificate();
        $certificate->mro_id = $mro_id;

        if ($certificate->load(Yii::$app->request->post())) {
                        // Set the file path for the uploaded certificate file
                        $certificateFile = UploadedFile::getInstance($certificate, 'certificate');
                        if ($certificateFile) {
                            $uploadPath = 'uploads/' . Yii::$app->security->generateRandomString() . '.' . $certificateFile->extension;
                            $certificateFile->saveAs($uploadPath);
                            $certificate->certificate = $uploadPath;
                        
                        }
            if ($certificate->validate() && $certificate->save()) {
                Yii::$app->session->setFlash('success', 'Aircraft certificate added successfully.');
                return $this->redirect(['index']);
            }
        }

        return $this->render('create', [
            'certificate' => $certificate,
            'mroProfile' => $mroProfile,
            'aircraftModels' => AircraftModel::find()->all(), // Assuming you want to display a list of aircraft models
        ]);
    }

    /**
     * Updates an existing aircraft certificate.
     * @param int $id
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException
     */
    public function actionUpdate($id)
    {
        $certificate = MroAircraftCertificate::findOne($id);
        if (!$certificate) {
            throw new NotFoundHttpException('Aircraft certificate not found.');
        }

        $mro_id = Yii::$app->session->get('mro_id');

        $mroProfile = MroProfile::findOne($mro_id);
        if (!$mroProfile) {
            throw new NotFoundHttpException('MRO profile not found.');
        }

        if ($certificate->load(Yii::$app->request->post())) {
            // Set the file path for the uploaded certificate file
            $certificateFile = UploadedFile::getInstance($certificate, 'certificate');
            if ($certificateFile) {
                $uploadPath = 'uploads/' . Yii::$app->security->generateRandomString() . '.' . $certificateFile->extension;
                $certificateFile->saveAs($uploadPath);
                $certificate->certificate = $uploadPath;
            
            }
if ($certificate->validate() && $certificate->save()) {
    Yii::$app->session->setFlash('success', 'Aircraft certificate added successfully.');
    return $this->redirect(['index']);
}
}


        return $this->render('update', [
            'certificate' => $certificate,
            'mroProfile' => $mroProfile,
            'aircraftModels' => AircraftModel::find()->all(), // Assuming you want to display a list of aircraft models
        ]);
    }

    /**
     * Deletes an aircraft certificate.
     * @param int $id
     * @return \yii\web\Response
     * @throws NotFoundHttpException
     */
    public function actionDelete($id)
    {
        $certificate = MroAircraftCertificate::findOne($id);
        if (!$certificate) {
            throw new NotFoundHttpException('Aircraft certificate not found.');
        }

        $mro_id = $certificate->mro_id;
        $certificate->delete();

        Yii::$app->session->setFlash('success', 'Aircraft certificate deleted successfully.');
        return $this->redirect(['index']);
    }

    public function actionGetModelsByManufacturer()
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        // Get the manufacturer from the request
        $manufacturer = Yii::$app->request->get('manufacturer');
       // VarDumper::dump($manufacturer);die();
        // Find the models by manufacturer
        $models = AircraftModel::find()
            ->where(['manufacturer' => $manufacturer])
            ->all();

        // Prepare the response data
        $data = [];
        foreach ($models as $model) {
            $data[] = [
                'id' => $model->aircraft_model_id, // Assuming this is the primary key
                'name' => $model->model, // Adjust if your model has a different attribute for the name
            ];
        }
        return $data;
    }
}
