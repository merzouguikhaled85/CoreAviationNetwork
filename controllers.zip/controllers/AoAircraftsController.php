<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use app\models\Aircrafts;
use app\models\AircraftModel;
use app\models\AoProfile;

use yii\data\Pagination;
use yii\web\NotFoundHttpException;
use yii\helpers\VarDumper;

class AoAircraftsController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // Only authenticated users
                        'matchCallback' => function ($rule, $action) {
                            // Allow access only to users with specific user types
                            return in_array(Yii::$app->session->get('user_type'), ['ao']);
                        }
                    ],
                ],
            ],
        ];
    }
    public function actionIndex()
    {
        // Fetch the AO ID from the session
        $ao_id = Yii::$app->session->get('ao_id');
    
        // Define the query with eager loading of owner information
        $query = Aircrafts::find()->with('owner')->orderBy(['manufacturer' => SORT_ASC]);
    
        // Handle search if search query parameter is provided
        $search = Yii::$app->request->get('search');
        if ($search) {
            // Assuming 'manufacturer', 'model', 'serial_number', and 'registration_number' are the attributes you want to search
            $query->andWhere(['or', 
                ['like', 'manufacturer', $search], 
                ['like', 'model', $search], 
                ['like', 'serial_number', $search], 
                ['like', 'registration_number', $search]
            ]);
        }
    
        // Filter the query by AO ID
        $query->andWhere(['ao_id' => $ao_id]);
    
        // Create a pagination object with a total count and a limit of 20 per page
        $pagination = new Pagination([
            'defaultPageSize' => 20,
            'totalCount' => $query->count(),
        ]);
    
        // Adjust the query using the pagination object
        $aircraftModels = $query->offset($pagination->offset)
            ->limit($pagination->limit)
            ->all();
    
        // Render the view, passing the aircraftModels and pagination objects
        return $this->render('index', [
            'aircraftModels' => $aircraftModels,
            'pagination' => $pagination,
        ]);
    }
    

    public function actionView($id)
    {
        $aircraft = Aircrafts::findOne($id);
        if (!$aircraft) {
            throw new NotFoundHttpException('Aircraft not found.');
        }

        return $this->render('view', [
            'aircraft' => $aircraft,
        ]);
    }
    public function actionCreate()
    {

        $ao_id = Yii::$app->session->get('ao_id');
        $owner = AoProfile::findOne(['ao_id' => $ao_id]);
   // VarDumper::dump($ao_id);die();
        $aircraftModel = new Aircrafts();
        $manufacturers = AircraftModel::find()->orderBy(['manufacturer' => SORT_ASC])->select('manufacturer')->distinct()->all();
        $models = AircraftModel::find()->orderBy(['model' => SORT_ASC])->all();
    
        if ($aircraftModel->load(Yii::$app->request->post()) ) {
            $aircraftModel->aircraft_model_id = AircraftModel::find()
            ->select('aircraft_model_id') // Select the aircraft_model_id
            ->where(['model' => $aircraftModel->model]) // Match on model
            ->andWhere(['manufacturer' => $aircraftModel->manufacturer]) // Match on manufacturer
            ->scalar(); // Get the scalar value (aircraft_model_id)
$aircraftModel->save();
            Yii::$app->session->setFlash('message', 'Aircraft Model created successfully!');
            return $this->redirect(['index']);
        } else {
            // Get the errors from the aircraftModel
            $errors = $aircraftModel->errors;
    
            // Concatenate all error messages into a single string
            $errorMessage = '';
            foreach ($errors as $errorMessages) {
                foreach ($errorMessages as $errorMessage) {
                    $errorMessage .= $errorMessage . '<br>';
                }
            }
    
            Yii::$app->session->setFlash('error', 'Failed to create aircraft model. Please check the submitted data.<br>' . $errorMessage);
        }
    
        return $this->render('create', [
            'aircraftModel' => $aircraftModel,
            'owner' => $owner,
            'manufacturers' => $manufacturers,
            'models' => $models,
        ]);
    }
    
    


    public function actionUpdate($id)
    {
        $ao_id = Yii::$app->session->get('ao_id');
        $owner = AoProfile::findOne(['ao_id' => $ao_id]);
    
        $aircraftModel = Aircrafts::findOne(['aircraft_id' => $id, 'ao_id' => $ao_id]);
        $manufacturers = AircraftModel::find()->orderBy(['manufacturer' => SORT_ASC])->select('manufacturer')->distinct()->all();
        $models = AircraftModel::find()->orderBy(['model' => SORT_ASC])->all();
    
        if ($aircraftModel->load(Yii::$app->request->post()) ) {
            $aircraftModel->aircraft_model_id = AircraftModel::find()
            ->select('aircraft_model_id') // Select the aircraft_model_id
            ->where(['model' => $aircraftModel->model]) // Match on model
            ->andWhere(['manufacturer' => $aircraftModel->manufacturer]) // Match on manufacturer
            ->scalar(); // Get the scalar value (aircraft_model_id)
            $aircraftModel->save();
            Yii::$app->session->setFlash('message', 'Aircraft Model created successfully!');
            return $this->redirect(['index']);
        } else {
            // Get the errors from the aircraftModel
            $errors = $aircraftModel->errors;
    
            // Concatenate all error messages into a single string
            $errorMessage = '';
            foreach ($errors as $errorMessages) {
                foreach ($errorMessages as $errorMessage) {
                    $errorMessage .= $errorMessage . '<br>';
                }
            }
    
            Yii::$app->session->setFlash('error', 'Failed to create aircraft model. Please check the submitted data.<br>' . $errorMessage);
        }
    
        return $this->render('update', [
            'aircraftModel' => $aircraftModel,
            'owner' => $owner,
            'manufacturers' => $manufacturers,
            'models' => $models,
        ]);
    }

    public function actionDelete($id)
    {
        // Fetch the AO ID from the session
        $ao_id = Yii::$app->session->get('ao_id');
    
        // Find the aircraft model by its ID and AO ID
        $aircraftModel = Aircrafts::findOne(['aircraft_id' => $id, 'ao_id' => $ao_id]);
    
        // Check if the aircraft model exists
        if (!$aircraftModel) {
            Yii::$app->session->setFlash('error', 'Aircraft model not found.');
            return $this->redirect(['index']);
        }
    
        // Attempt to delete the aircraft model
        if ($aircraftModel->delete()) {
            Yii::$app->session->setFlash('success', 'Aircraft model deleted successfully.');
        } else {
            Yii::$app->session->setFlash('error', 'Failed to delete aircraft model.');
        }
    
        // Redirect the user back to the index page
        return $this->redirect(['index']);
    }
    
}
