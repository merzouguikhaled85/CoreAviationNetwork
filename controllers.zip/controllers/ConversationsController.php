<?php

namespace app\controllers;

use app\models\AoNotificationsPreferences;
use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\Conversations;
use app\models\Requests;
use app\models\MroProfile;
use app\models\AoProfile;
use app\models\Chat;
use app\models\MroNotificationsPreferences;
use yii\helpers\VarDumper;
use yii\db\Expression;

use yii\web\NotFoundHttpException;

class ConversationsController extends Controller
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['home'],
                'rules' => [
                    [
                        'actions' => ['home'],
                        'allow' => true,
                        'roles' => ['@'], // Only authenticated users
                    ],
                ],
            ],
        ];
    }
    public function actionIndex()
    {
        $user_id = null;
        $user_type = null;
    
        if (Yii::$app->session->get('mro_id')) {
            $user_id = Yii::$app->session->get('mro_id');
            $user_type = 'mro';
        } elseif (Yii::$app->session->get('ao_id')) {
            $user_id = Yii::$app->session->get('ao_id');
            $user_type = 'ao';
        }
    
        if ($user_id === null || $user_type === null) {
            throw new \yii\web\ForbiddenHttpException('You are not authorized to view this page.');
        }
    
        // Fetch chats where the user is either the MRO or AO
        $chats = Chat::find()
            ->where(['or', ['mro_id' => $user_id], ['ao_id' => $user_id]])
            ->all();

        // Array to store conversations grouped by request_id
        $groupedConversations = [];

        // Iterate through each chat
        foreach ($chats as $chat) {
            // Fetch conversations for the current chat
            $conversations = Conversations::find()
                ->where(['chat_id' => $chat->chat_id])
                ->orderBy(['timestamp' => SORT_DESC])
                ->all();

            // Group conversations by request_id
            foreach ($conversations as $conversation) {
                // Check if the request_id exists in the groupedConversations array
                if (!isset($groupedConversations[$conversation->request_id])) {
                    // If not, initialize it as an empty array
                    $groupedConversations[$conversation->request_id] = [];
                }
                // Add the conversation to the corresponding request_id group
                $groupedConversations[$conversation->request_id][] = $conversation;
            }
        }
    
        return $this->render('index', [
            'chats' => $chats,
            'groupedConversations' => $groupedConversations,
        ]);
    }
    
    
    

    public function actionView($chat_id)
    {
        // Find the conversation based on the provided chat_id
        $conversation = Conversations::find()
            ->where(['chat_id' => $chat_id])
            ->one();
    
        // Check if the conversation exists
        if ($conversation === null) {
            throw new NotFoundHttpException('The requested conversation does not exist.');
        }
    
        // Create a new message instance
        $newMessage = new Conversations();
    
        // Check if the new message is submitted via POST request and is validated
        if ($newMessage->load(Yii::$app->request->post()) && $newMessage->validate()) {
            // Set the chat_id, request_id, sender_id, sender_type, receiver_id, and receiver_type for the new message
            $newMessage->chat_id = $chat_id;
            $newMessage->request_id = $conversation->request_id;
            $newMessage->sender_id = Yii::$app->session->get('mro_id');
            $newMessage->sender_type = 'mro';
            $newMessage->receiver_id = $conversation->receiver_id;
            $newMessage->receiver_type = 'ao';
    
            // Save the new message
            if ($newMessage->save()) {
                Yii::$app->session->setFlash('message', 'Message sent successfully.');
            } else {
                Yii::$app->session->setFlash('error', 'Failed to send message.');
            }
        }
    
        // Fetch all messages related to the provided chat_id
        $messages = Conversations::find()
        ->where(['chat_id' => $chat_id])
        ->orderBy(['timestamp' => SORT_ASC])
        ->all();
    
    
        return $this->render('view', [
            'conversation' => $conversation,
            'newMessage' => $newMessage,
            'messages' => $messages,
        ]);
    }
    
    
    public function actionReply($chat_id)
    {
        // Fetch the chat associated with the conversation
        $chat = Chat::findOne($chat_id);
    
        // Load the conversation by its ID
        $conversation = Conversations::findOne(['chat_id' => $chat_id]);
    
        // Check if the conversation exists
        if ($conversation === null) {
            throw new NotFoundHttpException('The requested conversation does not exist.');
        }
    
        // Create a new message for the conversation
        $newMessage = new Conversations();
    
        // Check if the new message is submitted via POST request
        if ($newMessage->load(Yii::$app->request->post())) {
            // Set the chat ID for the new message
            $newMessage->chat_id = $chat_id;
    
            // Set the sender and receiver IDs and types
            $newMessage->request_id = $conversation->request_id;
            $newMessage->sender_id = Yii::$app->session->get('mro_id') ? Yii::$app->session->get('mro_id') : Yii::$app->session->get('ao_id');
            $newMessage->sender_type = Yii::$app->session->get('mro_id') ? 'mro' : 'ao';
            $newMessage->receiver_id = Yii::$app->session->get('mro_id') ? $chat->ao_id : $chat->mro_id;
            $newMessage->receiver_type = Yii::$app->session->get('mro_id') ? 'ao' : 'mro';
    
            // Save the new message
            if ($newMessage->save()) {
                if($newMessage->receiver_type == 'mro'){
                              //platform notification
                              $aoNotificationsPreferences = MroNotificationsPreferences::findOne(['mro_id' => $newMessage->receiver_id]);
                              if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_by_platform) {
                                // Call the action to save the notification
                                Yii::$app->runAction('notification/save-notification', [
                                    'recipientType' => 'mro',
                                    'recipientId' => $newMessage->receiver_id,
                                    'message' => 'New message received.',
                                    'actions' => Yii::$app->request->baseUrl . '/conversations/view?chat_id=' . $newMessage->chat_id, // Or any route you want

                                ]);
                            }
                }else if ($newMessage->receiver_type == 'ao'){
                      //platform notification
                      $aoNotificationsPreferences = AoNotificationsPreferences::findOne(['ao_id' => $newMessage->receiver_id]);
                      if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_by_platform) {
                        // Call the action to save the notification
                        Yii::$app->runAction('notification/save-notification', [
                            'recipientType' => 'ao',
                            'recipientId' => $newMessage->receiver_id,
                            'message' => 'New message received.',
                             'actions' => Yii::$app->request->baseUrl . '/conversations/view?chat_id=' . $newMessage->chat_id, // Or any route you want

                        ]);
                    }
                }





                Yii::$app->session->setFlash('message', 'Message sent successfully.');
            } else {
                Yii::$app->session->setFlash('error', 'Failed to send message.');
            }
        }
        $newMessage->message = '';

        // Fetch all messages related to the conversation's chat ID
        $messages = Conversations::find()
        ->where(['chat_id' => $chat_id])
        ->orderBy(['timestamp' => SORT_ASC])
        ->all();
    
        // Render the reply form with the conversation and new message
        return $this->render('view', [
            'conversation' => $conversation,
            'newMessage' => $newMessage,
            'messages' => $messages,
        ]);
    }
    
    
    


    public function actionCreate()
    {
        // Create a new conversation model
        $conversation = new Conversations();

        // Check if the request is a POST request and load the posted data into the model
        if ($conversation->load(Yii::$app->request->post()) && $conversation->save()) {
            // If the model is saved successfully, redirect to the conversation view page
            return $this->redirect(['view', 'id' => $conversation->id]);
        }

        // If the model couldn't be saved or the request is not POST, render the chat create form
        return $this->render('create', [
            'conversation' => $conversation,
        ]);
    }
public function actionFetchMessages($conversationId)
{
    $messages = Conversations::find()->where(['chat_id' => $conversationId])->orderBy(['timestamp' => SORT_ASC])->all();

    return $this->renderPartial('_message_list', [
        'messages' => $messages,
    ]);
}

}
