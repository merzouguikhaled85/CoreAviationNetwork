<?php

namespace app\controllers;

use app\models\Airports;
use app\models\Cities;
use app\models\Countries;
use Yii;
use app\models\MroProfile;
use app\models\MroprofileAirport;
use yii\data\Pagination;
use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;
use yii\helpers\VarDumper;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

class MroAirportsController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // Only authenticated users
                        'matchCallback' => function ($rule, $action) {
                            // Allow access only to users with specific user types
                            return in_array(Yii::$app->session->get('user_type'), ['mro']);
                        }
                    ],
                ],
            ],
        ];
    }
    /**
     * Displays all airports associated with a specific MRO profile.
     * @return string
     */
    
     public function actionIndex()
     {
         $mro_id = Yii::$app->session->get('mro_id');
     
         $mroProfile = MroProfile::findOne($mro_id);
         if (!$mroProfile) {
             throw new NotFoundHttpException('MRO profile not found.');
         }
     
         // Find all MroprofileAirport records where mro_id matches the session value
         $query = MroprofileAirport::find()
             ->select(['mroprofile_airport.airport_id']) // Select only the airport_id for filtering
             ->where(['mro_id' => $mro_id]);

     
         // Handle search if search query parameter is provided
         $search = Yii::$app->request->get('search');
         if ($search) {
             // Join with airports to search by airport_name, city_name, country_name, and icao
             $query->leftJoin('airports a', 'a.airport_id = mroprofile_airport.airport_id')
                   ->leftJoin('countries c', 'c.country_id = a.country_id')
                   ->leftJoin('cities ci', 'ci.city_id = a.city_id')
                   ->andWhere([
                       'or',
                       ['like', 'a.airport_name', $search],
                       ['like', 'ci.city_name', $search],
                       ['like', 'c.country_name', $search],
                       ['like', 'a.icao', $search],
                   ]);
         }
     
         // Get airport_ids filtered by mro_id and search criteria
         $airportIds = $query->column();
     
         // Fetch Airports records based on filtered airport_ids
         $airports = Airports::find()
             ->where(['airport_id' => $airportIds])
             ->orderBy(['airport_name' => SORT_ASC]) // Example sorting by country_name
             ->all();
     
         // Pagination setup (if needed)
          $pagination = new Pagination([
              'defaultPageSize' => 20,
              'totalCount' => count($airports),
          ]);
     
         return $this->render('index', [
             'airports' => $airports,
              'pagination' => $pagination, // Uncomment if using pagination
         ]);
     }
     
     
     
     
//f

    
    

    /**
     * Displays a specific airport.
     * @param int $id
     * @return string
     * @throws NotFoundHttpException
     */
    public function actionView($id)
    {
        $airport = MroprofileAirport::findOne($id);
        if (!$airport) {
            throw new NotFoundHttpException('Airport not found.');
        }

        return $this->render('view', [
            'airport' => $airport,
        ]);
    }

    /**
     * Adds a new airport for the MRO profile.
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException
     */
  public function actionCreate()
{
    $mro_id = Yii::$app->session->get('mro_id');

    $mroProfile = MroProfile::findOne($mro_id);
    if (!$mroProfile) {
        throw new NotFoundHttpException('MRO profile not found.');
    }

    $model = new MroprofileAirport();
    $model->mro_id = $mro_id;

    if ($model->load(Yii::$app->request->post())) {

        $post = Yii::$app->request->post('MroprofileAirport');

        $selectedAirportIds = [];

        // Airports from country → city dropdown
        if (!empty($post['airport_id'])) {
            $selectedAirportIds = $post['airport_id'];
        }

        // Airports from ICAO search
        if (!empty($post['airport_id_icao'])) {
            $selectedAirportIds = array_merge($selectedAirportIds, $post['airport_id_icao']);
        }

        // Remove duplicates
        $selectedAirportIds = array_unique($selectedAirportIds);

        if (!empty($selectedAirportIds)) {

            foreach ($selectedAirportIds as $airportId) {

                $exists = MroprofileAirport::find()
                    ->where([
                        'mro_id' => $mro_id,
                        'airport_id' => $airportId
                    ])
                    ->exists();

                if (!$exists) {

                    $mroAirport = new MroprofileAirport();
                    $mroAirport->mro_id = $mro_id;
                    $mroAirport->airport_id = $airportId;

                    if (!$mroAirport->save()) {
                        Yii::$app->session->setFlash('error', 'Error saving some airports.');
                    }
                }
            }

            Yii::$app->session->setFlash('message', 'MRO Airports saved successfully.');

        } else {
            Yii::$app->session->setFlash('info', 'No airports selected for saving.');
        }

        return $this->redirect(['index']);
    }

    // Fetch countries
    $countries = Countries::find()
        ->orderBy(['country_name' => SORT_ASC])
        ->all();

    // Airports not already linked
    $subquery = MroprofileAirport::find()
        ->select('airport_id')
        ->where(['mro_id' => $mro_id]);

    $airports = Airports::find()
        ->where(['not in', 'airport_id', $subquery])
        ->orderBy(['airport_name' => SORT_ASC])
        ->all();

    $cities = [];

    return $this->render('create', [
        'mroProfile' => $mroProfile,
        'model' => $model,
        'countries' => $countries,
        'cities' => $cities,
        'airports' => $airports,
    ]);
}
    

    
    

    /**
     * Updates an existing airport.
     * @param int $id
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException
     */
    public function actionUpdate($id)
    {

        $mroAirport = MroprofileAirport::findOne($id);

        if ($mroAirport->load(Yii::$app->request->post()) && $mroAirport->save()) {
            Yii::$app->session->setFlash('success', 'MRO Airport created successfully.');
            return $this->redirect(['index']);
        }

        return $this->render('create', [
            'model' => $mroAirport,
        ]);
    }

    /**
     * Deletes an airport.
     * @param int $id
     * @return \yii\web\Response
     * @throws NotFoundHttpException
     */
    public function actionDelete($id)
    {
        $airport = MroprofileAirport::findOne(['airport_id' => $id]);
        if (!$airport) {
            throw new NotFoundHttpException('Airport not found.');
        }

        $airport->delete();

        return $this->redirect(['index']);
    }
    public function actionGetCities($country_ids)
    {
        $countryIdsArray = explode(',', $country_ids);
        $cities = cities::find()->where(['country_id' => $countryIdsArray])->all();
        $citiesArray = ArrayHelper::map($cities, 'id', 'city_name');
        return json_encode($citiesArray);
    }

    public function actionGetAirports($city_ids)
    {
        $cityIdsArray = explode(',', $city_ids);
        $airports = Airports::find()->where(['city_id' => $cityIdsArray])->all();
        $airportsArray = ArrayHelper::map($airports, 'airport_id', 'airport_name');
        return json_encode($airportsArray);
    }
    public function actionSearchAirports($q = null)
{
    Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;

    $results = [];

    if ($q !== null) {

        $airports = Airports::find()
            ->where(['like', 'icao', $q])
            ->limit(50)
            ->all();

        foreach ($airports as $airport) {
            $results[] = [
                'id' => $airport->airport_id,
                'text' => $airport->icao . ' - ' . $airport->airport_name
            ];
        }
    }

    return ['results' => $results];
}
}
