<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use app\models\Appointment;
use app\models\AoRequestsApplications;
use app\models\MroNotificationsPreferences;
use app\models\MroProfile;
use yii\web\NotFoundHttpException;

class AoAppointmentsController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // Only authenticated users
                        'matchCallback' => function ($rule, $action) {
                            // Allow access only to users with specific user types
                            return in_array(Yii::$app->session->get('user_type'), ['ao']);
                        }
                    ],
                ],
            ],
        ];
    }
    public function actionIndex()
    {
        // Fetch AO appointments
        $appointments = Appointment::find()->where(['ao_id' => Yii::$app->session->get('ao_id')])->all();

        return $this->render('index', [
            'appointments' => $appointments,
        ]);
    }

    public function actionCancel($id)
    {
        $appointment = Appointment::findOne($id);

        if ($appointment) {
            // Set status to canceled
            $appointment->status = 'canceled';

            if ($appointment->save()) {
                $mro =MroProfile::findOne($appointment->mro_id);
            
                Yii::$app->mailer->compose('appointment_canceled', ['appointment' => $appointment])
                    ->setTo($mro->email)
                    
                    ->setSubject('appointment canceled')
                    ->send();

                                    //platform notification
                                        // Call the action to save the notification
                                        Yii::$app->runAction('notification/save-notification', [
                                            'recipientType' => 'mro',
                                            'recipientId' => $mro->mro_id,
                                            'message' => 'Your appointment has been canceled.',
                                                                     'actions' => Yii::$app->request->baseUrl . '/mro-appointments' // Or any route you want

                                        ]);
                                

                Yii::$app->session->setFlash('success', 'Appointment canceled successfully.');
            } else {
                Yii::$app->session->setFlash('error', 'Failed to cancel appointment.');
            }
        } else {
            Yii::$app->session->setFlash('error', 'Appointment not found.');
        }

        return $this->redirect(['index']);
    }

    public function actionConfirm($id)
    {
        $appointment = Appointment::findOne($id);

        if ($appointment) {
            // Set status to confirmed
            $appointment->status = 'confirmed';

            if ($appointment->save()) {
                $mro =MroProfile::findOne($appointment->mro_id);
                $notificationPreferences = MroNotificationsPreferences::findOne(['mro_id' => $mro->mro_id]);
                if ($notificationPreferences && $notificationPreferences->notify_by_email && $notificationPreferences->notify_for_appointment_acceptance) {
         
                Yii::$app->mailer->compose('appointment_confirmed', ['appointment' => $appointment])
                    ->setTo($mro->email)
                    
                    ->setSubject('appointment confirmed')
                    ->send();
                }
                //platform notification
                    if ($notificationPreferences && $notificationPreferences->notify_by_platform && $notificationPreferences->notify_for_appointment_acceptance) {
                        // Call the action to save the notification
                        Yii::$app->runAction('notification/save-notification', [
                            'recipientType' => 'mro',
                            'recipientId' => $mro->mro_id,
                            'message' => 'Your appointment has been confirmed.',
                                                     'actions' => Yii::$app->request->baseUrl . '/mro-appointments' // Or any route you want

                        ]);
                }
                Yii::$app->session->setFlash('success', 'Appointment confirmed successfully.');
            } else {
                Yii::$app->session->setFlash('error', 'Failed to confirm appointment.');
            }
        } else {
            Yii::$app->session->setFlash('error', 'Appointment not found.');
        }

        return $this->redirect(['index']);
    }
    public function actionReschedule($id)
    {
        $appointment = Appointment::findOne($id);

        if (!$appointment) {
            throw new NotFoundHttpException("Appointment not found with ID: $id");
        }

        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post('Appointment');
if (!empty($post['reschedule_appointment_date'])) {
    $appointment->reschedule_appointment_date = date('Y-m-d H:i:s', strtotime($post['reschedule_appointment_date']));
}            $appointment->status = 'reschedule';

            if ($appointment->save()) {
                $mro =MroProfile::findOne($appointment->mro_id);
                $notificationPreferences = MroNotificationsPreferences::findOne(['mro_id' => $mro->mro_id]);
                if ($notificationPreferences && $notificationPreferences->notify_by_email && $notificationPreferences->notify_for_appointment_acceptance) {
         
                Yii::$app->mailer->compose('appointment_reschedule', ['appointment' => $appointment])
                    ->setTo($mro->email)
                    
                    ->setSubject('appointment reschedule demand')
                    ->send();
                }
                //platform notification
                    if ($notificationPreferences && $notificationPreferences->notify_by_platform && $notificationPreferences->notify_for_appointment_acceptance) {
                        // Call the action to save the notification
                        Yii::$app->runAction('notification/save-notification', [
                            'recipientType' => 'mro',
                            'recipientId' => $mro->mro_id,
                            'message' => 'appointment reschedule demand.',
                         'actions' => Yii::$app->request->baseUrl . '/mro-appointments' // Or any route you want

                        ]);
                }
                Yii::$app->session->setFlash('success', 'Appointment reschedule successfully.');
                return $this->redirect(['index']); // Redirect to appointments list page
            } else {
                Yii::$app->session->setFlash('error', 'Failed to reschedule appointment.');
            }
        }

        return $this->render('reschedule', [
            'appointment' => $appointment,
        ]);
    }
}
