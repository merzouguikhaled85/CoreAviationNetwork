<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\Response;
use app\models\Notification;
use yii\helpers\VarDumper;

class NotificationController extends Controller
{
    // Action to save notifications
public function actionSaveNotification($recipientType, $recipientId, $message, $actions = null)
{
    // Create a new instance of the Notification model
    $notification = new Notification();

    // Assign values to the notification attributes
    $notification->recipient_type = $recipientType;
    $notification->recipient_id = $recipientId;
    $notification->content = $message;
    $notification->actions = $actions; // <-- New line added
    $notification->created_at = date('Y-m-d H:i:s'); // Current timestamp


    // Validate and save the notification
    if ($notification->validate() && $notification->save()) {
        return true; // Return true or success response as needed
    } else {
        // Handle validation or save errors
        $errors = $notification->errors;
        Yii::error('Failed to save notification: ' . json_encode($errors));
        return false; // Return false or error response
    }
}


    public function actionMarkAllAsRead()
    {
        // Determine the user type ('ao', 'mro', or 'admin')
        $userType = Yii::$app->session->get('user_type');
        $userId = $this->getUserId($userType); // Get user ID based on userType

        // Fetch notifications to mark as read based on recipient type and ID
        $notifications = Notification::find()
            ->where(['recipient_type' => $userType, 'recipient_id' => $userId])
            ->andWhere(['<>', 'status', 'read'])
            ->all();

        // Mark each notification as read
        foreach ($notifications as $notification) {
            $notification->status = 'read';
            $notification->save();
        }

        // Return success response as JSON
        Yii::$app->response->format = Response::FORMAT_JSON;
        return ['success' => true];
    }

    public function actionDeleteAll()
    {
        // Determine the user type ('ao', 'mro', or 'admin')
        $userType = Yii::$app->session->get('user_type');
        $userId = $this->getUserId($userType); // Get user ID based on userType

        // Fetch notifications to mark as read based on recipient type and ID
        $notifications = Notification::find()
            ->where(['recipient_type' => $userType, 'recipient_id' => $userId])
            ->all();

        // Mark each notification as read
        foreach ($notifications as $notification) {
            $notification->delete();
        }
        // Return success response as JSON
        Yii::$app->response->format = Response::FORMAT_JSON;
        return ['success' => true];
    }

    public function actionNotificationCount()
    {
        // Determine the user type ('ao', 'mro', or 'admin')
        $userType = Yii::$app->session->get('user_type');
        $userId = $this->getUserId($userType); // Get user ID based on userType
        

        // Logic to fetch notification count based on user type and user ID
        switch ($userType) {
            case 'ao':
                $notificationCount = Notification::find()
                    ->where(['recipient_type' => 'ao', 'recipient_id' => $userId])
                    ->andWhere(['<>', 'status', 'read']) // Add condition here
                    ->count();
                break;
            case 'mro':
                $notificationCount = Notification::find()
                    ->where(['recipient_type' => 'mro', 'recipient_id' => $userId])
                    ->andWhere(['<>', 'status', 'read']) // Add condition here
                    ->count();
                break;
            case 'admin':
                // For admin, you might want to fetch all notifications, so recipient_id is optional
                $notificationCount = Notification::find()
                    ->where(['recipient_type' => 'admin'])
                    ->andWhere(['<>', 'status', 'read']) // Add condition here
                    ->count();
                break;
            default:
                $notificationCount = 0;
                break;
        }

        // Return as JSON response
        Yii::$app->response->format = Response::FORMAT_JSON;
        return [
            'success' => true,
            'count' => $notificationCount,
        ];
    }

    /**
     * Helper function to retrieve user ID based on user type
     */
    private function getUserId($userType)
    {
        switch ($userType) {
            case 'ao':
                return Yii::$app->session->get('ao_id');
            case 'mro':
                return Yii::$app->session->get('mro_id');
            case 'admin':
                return Yii::$app->session->get('admin_id');
            default:
                return null;
        }
    }

    public function actionUpdateNotification($id)
    {
        $notification = Notification::findOne($id);
        if ($notification) {
            $notification->status = 'read';
            if ($notification->save()) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ['success' => true];
            }
        }
        Yii::$app->response->format = Response::FORMAT_JSON;
        return ['success' => false];
    }
    public function actionDeleteNotification($id)
    {
        $notification = Notification::findOne($id);
        if ($notification && $notification->delete()) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ['success' => true];
        }
        Yii::$app->response->format = Response::FORMAT_JSON;
        return ['success' => false];
    }
    public function actionNotificationList()
    {
        $userType = Yii::$app->session->get('user_type');
        $userId = $this->getUserId($userType); // Get user ID based on userType

        // Fetch notifications based on recipient type and ID
        switch ($userType) {
            case 'ao':
                $notifications = Notification::find()
                    ->where(['recipient_type' => 'ao', 'recipient_id' => $userId])
                    ->orderBy(['created_at' => SORT_DESC])
                    ->all();
                break;
            case 'mro':
                $notifications = Notification::find()
                    ->where(['recipient_type' => 'mro', 'recipient_id' => $userId])
                    ->orderBy(['created_at' => SORT_DESC])
                    ->all();
                break;
            case 'admin':
                // For admin, you might fetch all notifications without specific recipient ID
                $notifications = Notification::find()
                    ->where(['recipient_type' => 'admin'])
                    ->orderBy(['created_at' => SORT_DESC])
                    ->all();
                break;
            default:
                $notifications = [];
                break;
        }

        // Prepare data for JSON response
        $notificationData = [];
        foreach ($notifications as $notification) {
            $notificationData[] = [
                'id' => $notification->id,
                'message' => $notification->content,
                'read' => $notification->status,
                'actions' => $notification->actions,  // send this to front-end too

            ];
        }

        // Return as JSON response
        Yii::$app->response->format = Response::FORMAT_JSON;
        return [
            'success' => true,
            'notifications' => $notificationData,
        ];
    }
}
