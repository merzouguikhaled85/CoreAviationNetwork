<?php

namespace app\controllers;

use app\models\Aircrafts;
use app\models\Airports;
use app\models\AoRequestsApplications;
use app\models\Certificates;
use app\models\Chat;
use app\models\Conversations;
use app\models\Feedback;
use app\models\MroAircraftCertificate;
use Yii;
use app\models\Requests;
use app\models\MroProfile;
use app\models\MroNotificationsPreferences;
use app\models\MroRequestApply;
use app\models\RepairReport;
use yii\data\Pagination;
use yii\helpers\ArrayHelper;
use yii\web\UploadedFile;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\Url;
use yii\helpers\VarDumper;

class RequestsController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Requests models.
     * @param string|null $search
     * @return mixed
     */
    public function actionIndex($search = null)
    {
        // Get the AO ID from session
        $ao_id = Yii::$app->session->get('ao_id');
        
        // Build the query to fetch requests where ao_id matches $mro_id
        $query = Requests::find()->where(['ao_id' => $ao_id])
            ->joinWith([ 'destinationAirport']); // Eager loading the related airport data
    
        // Apply search filter if search query is provided
        if ($search !== null) {
            $query->andFilterWhere(['like', 'request_details', $search])
                  ->orFilterWhere(['like', 'aircraft_registration', $search]);
        }
    
        $countQuery = clone $query;
        $totalCount = $countQuery->count();
    
        $pagination = new Pagination(['totalCount' => $totalCount]);
        $pagination->pageSize = 20; // Adjust the page size as needed
    
        $requests = $query->offset($pagination->offset)
            ->limit($pagination->limit)
            ->all();
            $title = "Requests";

        return $this->render('index', [
            'requests' => $requests,
            'pagination' => $pagination,
            'search' => $search,
            'title' => $title,

        ]);
    }
    public function actionNewRequests($search = null)
{
    // Get the AO ID from session
    $ao_id = Yii::$app->session->get('ao_id');
    
    // Build the query to fetch requests where ao_id matches $ao_id
        $query = Requests::find()
        ->where(['ao_id' => $ao_id])
        ->andWhere(['status' => ['created', 'answered', 'po_loaded']]) // Filter by status
        ->joinWith(['destinationAirport']) // Eager loading the related airport data
        ->joinWith(['mroApplication']) // Join with MroRequestApply and then Mro to get the username
        ->orderBy(['request_id' => SORT_DESC]); // Order by request_id descending


    // Apply search filter if search query is provided
    if ($search !== null) {
        $query->andFilterWhere(['like', 'request_details', $search])
              ->orFilterWhere(['like', 'aircraft_registration', $search]);
    }




    // Clone the query to get the total count for pagination
    $countQuery = clone $query;
    $totalCount = $countQuery->count();

    $pagination = new Pagination(['totalCount' => $totalCount]);
    $pagination->pageSize = 20; // Adjust the page size as needed

    // Fetch the requests with pagination
    $requests = $query->offset($pagination->offset)
        ->limit($pagination->limit)
        ->all();

       // VarDumper::dump($requests); die();
    
    $title = "New requests";

    // Render the 'index' view with the fetched data
    return $this->render('index', [
        'requests' => $requests,
        'pagination' => $pagination,
        'search' => $search,
        'title' => $title,
    ]);
}
public function actionOpenRequests($search = null)
{
    // Get the AO ID from session
    $ao_id = Yii::$app->session->get('ao_id');
    
    // Build the query to fetch requests where ao_id matches $ao_id
    $query = Requests::find()
        ->where(['ao_id' => $ao_id])
        ->andWhere(['status' => ['work_accepted', 'work_started', 'report_submitted', 'update_request', 'update_request_accepted', 'update_request_denied']]) // Filter by status
        ->joinWith(['destinationAirport']) // Eager loading the related airport data
        ->orderBy(['request_id' => SORT_DESC]); // Order by request_id descending

    // Apply search filter if search query is provided
    if ($search !== null) {
        $query->andFilterWhere(['like', 'request_details', $search])
              ->orFilterWhere(['like', 'aircraft_registration', $search]);
    }

    // Clone the query to get the total count for pagination
    $countQuery = clone $query;
    $totalCount = $countQuery->count();

    $pagination = new Pagination(['totalCount' => $totalCount]);
    $pagination->pageSize = 20; // Adjust the page size as needed

    // Fetch the requests with pagination
    $requests = $query->offset($pagination->offset)
        ->limit($pagination->limit)
        ->all();
    
    $title = "Open requests";

    // Render the 'index' view with the fetched data
    return $this->render('index', [
        'requests' => $requests,
        'pagination' => $pagination,
        'search' => $search,
        'title' => $title,
    ]);
}

public function actionClosedRequests($search = null)
{
    // Get the AO ID from session
    $ao_id = Yii::$app->session->get('ao_id');
    
    // Build the query to fetch requests where ao_id matches $ao_id
    $query = Requests::find()
        ->where(['ao_id' => $ao_id])
        ->andWhere(['status' => ['closed']]) // Filter by status
        ->joinWith(['destinationAirport']) // Eager loading the related airport data
        ->orderBy(['request_id' => SORT_DESC]); // Order by request_id descending

    // Apply search filter if search query is provided
    if ($search !== null) {
        $query->andFilterWhere(['like', 'request_details', $search])
              ->orFilterWhere(['like', 'aircraft_registration', $search]);
    }

    // Clone the query to get the total count for pagination
    $countQuery = clone $query;
    $totalCount = $countQuery->count();

    $pagination = new Pagination(['totalCount' => $totalCount]);
    $pagination->pageSize = 20; // Adjust the page size as needed

    // Fetch the requests with pagination
    $requests = $query->offset($pagination->offset)
        ->limit($pagination->limit)
        ->all();
    
    $title = "Closed requests";

    // Render the 'index' view with the fetched data
    return $this->render('index', [
        'requests' => $requests,
        'pagination' => $pagination,
        'search' => $search,
        'title' => $title,
    ]);
}

    /**
     * Displays a single Request model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        // Attempt to find the AoRequest by request_id
        $AoRequest = AoRequestsApplications::find()
            ->where(['request_id' => $id])
            ->orderBy(['created_at' => SORT_DESC])
            ->one();
            
        // If no AoRequest is found, set $poAttachment to an empty string
        $poAttachment = $AoRequest ? $AoRequest->po : '';
    
        $aoRequestApplication = AoRequestsApplications::find()
    ->where(['request_id' => $id])
    ->orderBy(['id' => SORT_DESC]) // Sort by the ID of AoRequestsApplications
    ->one();

        // Attempt to find the AoRequest by request_id
        $MroApplication = $aoRequestApplication && $aoRequestApplication->application
        ? $aoRequestApplication->application->id
        : null; // Return null if no related application exists

                
        // If no AoRequest is found, set $poAttachment to an empty string
        $invoice = $MroApplication ? $MroApplication : '';


        // Get all mro request application
        $allRepairReports = RepairReport::find()
        ->orderBy(['updated_at' => SORT_DESC])
        ->all();

        $repairReports = [];
        foreach ($allRepairReports as $report) {
            if ( $report->getRequest()->request_id == $id && $report->CRSed == 0) {
                $repairReports[] = $report->CRS_attachment;
            }
        }

        // Get all mro request application
        $CRSReports = RepairReport::find()
        ->where(['CRSed' => 1])
        ->orderBy(['updated_at' => SORT_DESC])
        ->all();

        $CrsReports = [];
        foreach ($CRSReports as $report) {
            if ( $report->getRequest()->request_id == $id) {
                $CrsReports[] = $report->CRS_attachment;
            }
        }


        $crs = $CrsReports ? $CrsReports[0] : '';

        // Render the view with the found request model and the PO attachment (or empty)
        return $this->render('view', [
            'request' => $this->findModel($id),
            'poAttachment' => $poAttachment, // This will be empty if no AoRequest is found
            'invoice' => $invoice, // This will be empty if no AoRequest is found
            'repairReports' => $repairReports,
            'crs' => $crs,
        ]);
    }
    

    /**
     * Creates a new Request model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $request = new Requests();
        
        // Get the AO ID from session
        $ao_id = Yii::$app->session->get('ao_id');
        
        // Set the ao_id attribute of the request model
        $request->ao_id = $ao_id;
        
        // Fetch all airports for dropdowns
        $airports = Airports::find()
        ->orderBy('icao')
        ->all();        
        if ($request->load(Yii::$app->request->post())) {
            $request->required_certificates = $request->getAircraft()->one()->getCertificateType()->one()->type;
            
               // Check if a file is uploaded
                $request->attachment = UploadedFile::getInstance($request, 'attachment');
                if ($request->attachment) {
                    $uploadPath = 'uploads/' . Yii::$app->security->generateRandomString() . '.' . $request->attachment->extension;
                    if ($request->attachment->saveAs($uploadPath)) {
                        // File upload successful, set the attachment attribute to the file path
                        $request->attachment = $uploadPath;
                    } else {
                        // File upload failed
                        Yii::$app->session->setFlash('error', 'Failed to upload attachment.');
                        return $this->render('create', [
                            'request' => $request,
                            'airports' => $airports,
                        ]);
                    }
                }


                $request->location = Airports::findOne($request->destination)->airport_name ;
            
    
            // Server-side validation to ensure ETD is after ETA
            $request->eta = date('Y-m-d H:i:s', strtotime($request->eta));
            $request->etd = date('Y-m-d H:i:s', strtotime($request->etd));

            $eta = strtotime($request->eta);
            $etd = strtotime($request->etd);
        
            if ($etd <= $eta) {
                Yii::$app->session->setFlash('error', 'ETD must be after ETA.');
                return $this->render('create', [
                    'request' => $request,
                    'airports' => $airports,
                ]);
            }
        
            if ($request->save()) {
                // Get the required certificates from the posted data
                $requiredCertificates = $request->getAircraft()->one()->getCertificateType()->one()->type;


                // Find all MROs that have any of the required certificates
                $mrosWithCertificates = MroProfile::find()
                    ->joinWith('certificates')
                    ->where(['IN', 'certificates.type', $requiredCertificates])
                    ->all();
                         // Get the aircraft model ID from the posted request
                         $requiredAircraftCertificate = Aircrafts::findOne(Yii::$app->request->post('Requests')['aircraft_id'])->getAircraftModel()->one()->aircraft_model_id;

                         // Find all MroProfiles linked to the specified aircraft model ID
                         $mroProfilesWithAircraftCertificate = MroProfile::find()
                             ->joinWith('aircraftCertificates') // Assuming the relation in MroProfile is named 'aircraftCertificates'
                             ->where(['mro_aircraft_certificate.aircraft_model_id' => $requiredAircraftCertificate])
                             ->all();
                                    
                $allMros = MroProfile::find()->all();
if (empty($allMros)) {
    // No MROs found → show a message or log
    Yii::$app->session->setFlash('message', 'Request created, but no MRO profiles exist yet to notify.');
    return $this->redirect(['new-requests']);
}
                // Loop through each MRO
                foreach ($allMros as $mro) {
                    $mroIdsWithCertificates = array_map(function($mro) {
                        return $mro->mro_id;
                    }, $mrosWithCertificates);
                    foreach ($allMros as $mro) {
                        $mroIdsWithAircraftCertificate = array_map(function($mro) {
                            return $mro->mro_id;
                        }, $mroProfilesWithAircraftCertificate);
                    // Retrieve the MRO's notification preferences
                    $notificationPreferences = MroNotificationsPreferences::findOne(['mro_id' => $mro->mro_id]);
                    $url = Url::to(['mro-requests/index'], true); // Generate the URL for the actionIndex of MroRequestsController

                    // Check if the MRO is in the list of MROs with certificates and if the notification preferences match for certified aircraft

                    if (in_array($mro->mro_id, $mroIdsWithCertificates) && in_array($mro->mro_id, $mroIdsWithAircraftCertificate) && $notificationPreferences && $notificationPreferences->notify_by_email && $notificationPreferences->notify_for_certified_aircraft) {
                        // Send email for certified aircraft
                        Yii::$app->mailer->compose('notification_certified', ['url' => $url])
                        ->setTo($mro->email)
                            
                            ->setSubject('New Request Notification')
                            ->send();
                    }
                    //platform notification
                    if (in_array($mro->mro_id, $mroIdsWithCertificates) && in_array($mro->mro_id, $mroIdsWithAircraftCertificate) && $notificationPreferences && $notificationPreferences->notify_by_platform && $notificationPreferences->notify_for_certified_aircraft) {
                    // Call the action to save the notification
                        Yii::$app->runAction('notification/save-notification', [
                            'recipientType' => 'mro',
                            'recipientId' => $mro->mro_id,
                            'message' => 'A new request has been submitted that matches your scope of work.',
                            'actions' =>  Yii::$app->request->baseUrl .'/mro-requests', // Or any route you want

                        ]);
                    }

                    // Check if the MRO is not in the list of MROs with certificates and if the notification preferences match for non-certified aircraft
                    if ((!in_array($mro->mro_id, $mroIdsWithCertificates)||  !in_array($mro->mro_id, $mroIdsWithAircraftCertificate)) && $notificationPreferences && $notificationPreferences->notify_by_email && $notificationPreferences->notify_for_non_certified_aircraft) {
                       $aircraft = Aircrafts::findOne(Yii::$app->request->post('Requests')['aircraft_id']); 
                        // Send email for non-certified aircraft
                        Yii::$app->mailer->compose('notification_non_certified', [
                            'manufacturer' => $aircraft->manufacturer,
                            'model' => $aircraft->model,
                            // Add more parameters as needed
                        ])->setTo($mro->email)
                            
                            ->setSubject('New Request Notification')
                            ->send();
                    }
                                        //platform notification
                                        if ((!in_array($mro->mro_id, $mroIdsWithCertificates) ||  !in_array($mro->mro_id, $mroIdsWithAircraftCertificate)) && $notificationPreferences && $notificationPreferences->notify_by_platform && $notificationPreferences->notify_for_non_certified_aircraft) {
                                            // Call the action to save the notification
                                                Yii::$app->runAction('notification/save-notification', [
                                                    'recipientType' => 'mro',
                                                    'recipientId' => $mro->mro_id,
                                                    'message' => 'A new request has been submitted which you do not hold the appropriate cover. ',
                                                    'actions' =>  Yii::$app->request->baseUrl .'/mro-requests', // Or any route you want

                                                ]);
                                            }
                        
                }
        
                // Flash message for successful request creation
                Yii::$app->session->setFlash('message', 'Request created successfully.');
                return $this->redirect(['new-requests']);
            }
        }
    }
        return $this->render('create', [
            'request' => $request,
            'airports' => $airports,
        ]);
    
    
}
public function actionSearchAirports($term)
{
    Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;

    if (strlen($term) < 3) {
        return [];
    }

    $airports = Airports::find()
        ->filterWhere(['or',
            ['like', 'airport_name', $term],
            ['like', 'icao', $term],
            ['like', 'city_name', $term]
        ])
        ->orderBy('icao')
        ->limit(20) // Limit the number of results to prevent overload
        ->all();

    return ArrayHelper::toArray($airports, [
        Airports::class => [
            'id' => 'airport_id',
            'text' => function ($airport) {
                return "{$airport->icao} : {$airport->airport_name} ({$airport->city_name})";
            },
        ],
    ]);
}

    /**
     * Updates an existing Request model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id , $status = null)
    {
        $request = $this->findModel($id);
            
        // Get the AO ID from session
        $ao_id = Yii::$app->session->get('ao_id');
        
        // Set the ao_id attribute of the request model
        $request->ao_id = $ao_id;
        
        if (!empty($request->eta)) {
    $request->eta = date('d M Y H:i', strtotime($request->eta));
}

if (!empty($request->etd)) {
    $request->etd = date('d M Y H:i', strtotime($request->etd));
}

        // Fetch all airports for dropdowns
        $airports = Airports::find()->all();

        $selectedAirportName = null;
        $selectedAirport = Airports::findOne($request->destination);
        if ($selectedAirport) {
            $selectedAirportName = $selectedAirport->airport_name;
        }

        
        if ($request->load(Yii::$app->request->post())) {

            if ($request->destination) {

            }
               // Check if a file is uploaded
                $request->attachment = UploadedFile::getInstance($request, 'attachment');
                if ($request->attachment) {
                    $uploadPath = 'uploads/' . Yii::$app->security->generateRandomString() . '.' . $request->attachment->extension;
                    if ($request->attachment->saveAs($uploadPath)) {
                        // File upload successful, set the attachment attribute to the file path
                        $request->attachment = $uploadPath;
                    } else {
                        // File upload failed
                        Yii::$app->session->setFlash('error', 'Failed to upload attachment.');
                        return $this->render('create', [
                            'request' => $request,
                            'airports' => $airports,
                        ]);
                    }
                }


                $request->location = Airports::findOne($request->destination)->airport_name ;
            
    
            // Server-side validation to ensure ETD is after ETA
            $request->eta = date('Y-m-d H:i:s', strtotime($request->eta));
            $request->etd = date('Y-m-d H:i:s', strtotime($request->etd));
            $eta = strtotime($request->eta);
            $etd = strtotime($request->etd);
        
            if ($etd <= $eta) {
                Yii::$app->session->setFlash('error', 'ETD must be after ETA.');
                return $this->render('create', [
                    'request' => $request,
                    'airports' => $airports,
                ]);
            }
            if( $status != null){
                $request->status = $status;
            }
        
            if ($request->save()) {
                               // Get the required certificates from the posted data
                               $requiredCertificates = $request->getAircraft()->one()->getCertificateType()->one()->type;



                               // Find all MROs that have any of the required certificates
                               $mrosWithCertificates = MroProfile::find()
                                   ->joinWith('certificates')
                                   ->where(['IN', 'certificates.type', $requiredCertificates])
                                   ->all();
                                        // Get the aircraft model ID from the posted request
                                        $requiredAircraftCertificate = Aircrafts::findOne(Yii::$app->request->post('Requests')['aircraft_id'])->getAircraftModel()->one()->aircraft_model_id;
               
                                        // Find all MroProfiles linked to the specified aircraft model ID
                                        $mroProfilesWithAircraftCertificate = MroProfile::find()
                                            ->joinWith('aircraftCertificates') // Assuming the relation in MroProfile is named 'aircraftCertificates'
                                            ->where(['mro_aircraft_certificate.aircraft_model_id' => $requiredAircraftCertificate])
                                            ->all();
                                                   
                               $allMros = MroProfile::find()->all();
               if (empty($allMros)) {
    // No MROs found → show a message or log
    Yii::$app->session->setFlash('warning', 'Request Updated, but no MRO profiles exist yet to notify.');
    return $this->redirect(['new-requests']);
}
                              if($request->status =='created')
                        {     
                               // Loop through each MRO
                               foreach ($allMros as $mro) {
                                   $mroIdsWithCertificates = array_map(function($mro) {
                                       return $mro->mro_id;
                                   }, $mrosWithCertificates);
                                }
                                   foreach ($allMros as $mro) {
                                       $mroIdsWithAircraftCertificate = array_map(function($mro) {
                                           return $mro->mro_id;
                                       }, $mroProfilesWithAircraftCertificate);
                                    }
                    // Retrieve the MRO's notification preferences
                    $notificationPreferences = MroNotificationsPreferences::findOne(['mro_id' => $mro->mro_id]);
                    $url = Url::to(['mro-requests/index'], true); // Generate the URL for the actionIndex of MroRequestsController

                    // Check if the MRO is in the list of MROs with certificates and if the notification preferences match for certified aircraft
                     // Check if the MRO is in the list of MROs with certificates and if the notification preferences match for certified aircraft
                     if (in_array($mro->mro_id, $mroIdsWithCertificates)&& in_array($mro->mro_id, $mroIdsWithAircraftCertificate) && $notificationPreferences && $notificationPreferences->notify_by_email && $notificationPreferences->notify_for_certified_aircraft) {
                        // Send email for certified aircraft
                        Yii::$app->mailer->compose('notification_certified', ['url' => $url])
                        ->setTo($mro->email)
                            
                            ->setSubject('New Request Notification')
                            ->send();
                    }
                    //platform notification
                    if (in_array($mro->mro_id, $mroIdsWithCertificates) && in_array($mro->mro_id, $mroIdsWithAircraftCertificate) && $notificationPreferences && $notificationPreferences->notify_by_platform && $notificationPreferences->notify_for_certified_aircraft) {
                    // Call the action to save the notification
                        Yii::$app->runAction('notification/save-notification', [
                            'recipientType' => 'mro',
                            'recipientId' => $mro->mro_id,
                            'message' => 'A new request has been submitted that matches your scope of work.',
                            'actions' =>  Yii::$app->request->baseUrl .'/mro-requests', // Or any route you want

                        ]);
                    }
                    // Check if the MRO is not in the list of MROs with certificates and if the notification preferences match for non-certified aircraft
                    if ((!in_array($mro->mro_id, $mroIdsWithCertificates)||  !in_array($mro->mro_id, $mroIdsWithAircraftCertificate)) && $notificationPreferences && $notificationPreferences->notify_by_email && $notificationPreferences->notify_for_non_certified_aircraft) {
                       $aircraft = Aircrafts::findOne(Yii::$app->request->post('Requests')['aircraft_id']); 
                        // Send email for non-certified aircraft
                        Yii::$app->mailer->compose('notification_non_certified', [
                            'manufacturer' => $aircraft->manufacturer,
                            'model' => $aircraft->model,
                            // Add more parameters as needed
                        ])->setTo($mro->email)
                            
                            ->setSubject('Request Upaded Notification')
                            ->send();
                    }
                      //platform notification
                      if ((!in_array($mro->mro_id, $mroIdsWithCertificates)||  !in_array($mro->mro_id, $mroIdsWithAircraftCertificate)) && $notificationPreferences && $notificationPreferences->notify_by_platform && $notificationPreferences->notify_for_non_certified_aircraft) {
                        // Call the action to save the notification
                            Yii::$app->runAction('notification/save-notification', [
                                'recipientType' => 'mro',
                                'recipientId' => $mro->mro_id,
                                'message' => 'A request has been Updated which you do not hold the appropriate cover. ',
                                'actions' =>  Yii::$app->request->baseUrl .'/mro-requests', // Or any route you want

                            ]);
                        }
                }
            }
        
                // Flash message for successful request creation
                Yii::$app->session->setFlash('message', 'Request updated successfully.');
                return $this->redirect(['new-requests']);
            }
        
    
        return $this->render('update', [
            'request' => $request,
            'airports' => $airports,
            'statuss' => $status,
            'selectedAirportName' => $selectedAirportName,


        ]);
    
}

    public function actionCheckApplications($id)
{
    // Load the request by its ID
    $request = Requests::findOne($id);

    // Fetch all applications for the specific request
    $applications = MroRequestApply::find()->where(['request_id' => $id])->all();

    // Render the view with the applications data
    return $this->render('check-applications', [
        'request' => $request,
        'applications' => $applications,
    ]);
}

public function actionDeny($id)
{
    // Load the MRO request application by its ID
    $application = MroRequestApply::findOne($id);
    $requestId = $application->request_id;
    if ($application) {
        // Load the associated MRO
        $mro = $application->mro;
        
        // Send email notification to the MRO including application details
        Yii::$app->mailer->compose('application_denied', ['application' => $application])
        ->setTo($mro->email)
        
        ->setSubject('Request Application Denied')
        ->send();

                                                //platform notification
                                                    // Call the action to save the notification
                                                        Yii::$app->runAction('notification/save-notification', [
                                                            'recipientType' => 'mro',
                                                            'recipientId' => $mro->mro_id,
                                                            'message' => 'Your application for the request has been Denied.',
                                                         'actions' =>  Yii::$app->request->baseUrl .'/mro-requests', // Or any route you want

                                                        ]);
                                                    
        
        // Delete the application
        $application->delete();
        $applicationsCount = MroRequestApply::find()->where(['request_id' => $requestId])->count();
        if ($applicationsCount === 0) {
            // Update request status to 'created'
            $request = Requests::findOne($requestId);
            if ($request) {
                $request->status = 'created';
                $request->save();
            }
        }

        // Set flash message
        Yii::$app->session->setFlash('success', 'Application denied and notification sent.');
    } else {
        Yii::$app->session->setFlash('error', 'Application not found.');
    }

    // Redirect back to the check-applications page or any other relevant page
    return $this->redirect(['check-applications', 'id' => $application->request_id]);
}
public function actionLoadPo($id)
{
    $application = MroRequestApply::findOne($id);
    $mro = $application->mro;

    // Load the AO request by its ID
    $aoRequest = new AoRequestsApplications();
    $aoRequest->application_id = $id;
    $aoRequest->request_id = $application->request_id;

    $request = Requests::findOne($application->request_id);

    $mroCertificate = Certificates::find()
        ->where([
            'mro_id' => $mro->mro_id,
            'type' => $request->required_certificates
        ])
        ->one();

        $mroAircraftCertificate = MroAircraftCertificate::find()
        ->where([
            'mro_id' => $mro->mro_id,
            'aircraft_model_id' => $request->getAircraft()->one()->aircraft_model_id
        ])
        ->one();

    // Check if the form is submitted and the model is validated
    if (Yii::$app->request->isPost) {
        if (Yii::$app->request->post('check-certificate')) {
            // Handle the "Check Certificate" button click
            return $this->render('load-po', [
                'aoRequest' => $aoRequest,
                'mroCertificate' => $mroCertificate,
                'mroAircraftCertificate' =>$mroAircraftCertificate,
                'certificateModal' => true // Flag to show the modal
            ]);
        }

        $uploadedFile = UploadedFile::getInstance($aoRequest, 'po');
        if ($uploadedFile) {
            // Generate a unique filename
            $filename = 'po_' . Yii::$app->security->generateRandomString(8) . '.' . $uploadedFile->extension;

            // Save the uploaded file
            if ($uploadedFile->saveAs('uploads/' . $filename)) {
                // Assign the filename to the model attribute
                $aoRequest->po = $filename;

                // Save the model
                if ($aoRequest->save()) {
                    // Update the request status to "answered"
                    $request->status = 'po_loaded';
                    $request->save();

                    $notificationPreferences = MroNotificationsPreferences::findOne(['mro_id' => $mro->mro_id]);
                    if ($notificationPreferences && $notificationPreferences->notify_by_email) {
                        // Send email notification to the MRO including application details
                        Yii::$app->mailer->compose('application_accepted', ['application' => $application])
                            ->setTo($mro->email)
                            
                            ->setSubject('PO loaded')
                            ->send();
                    }

                    // Platform notification
                    if ($notificationPreferences && $notificationPreferences->notify_by_platform) {
                        // Call the action to save the notification
                        Yii::$app->runAction('notification/save-notification', [
                            'recipientType' => 'mro',
                            'recipientId' => $mro->mro_id,
                            'message' => 'Your application for the request has been accepted.',
                            'actions' =>  Yii::$app->request->baseUrl .'/mro-applications', // Or any route you want

                        ]);
                    }

                    Yii::$app->session->setFlash('success', 'PO file uploaded successfully.');
                } else {
                    Yii::$app->session->setFlash('error', 'Failed to save PO file.');
                }
            } else {
                Yii::$app->session->setFlash('error', 'Failed to upload PO file.');
            }
        } else {
            Yii::$app->session->setFlash('error', 'No file uploaded.');
        }

        // Redirect to a relevant page
        return $this->redirect(['new-requests']);
    }

    // Render the view with the AO request model
    return $this->render('load-po', [
        'aoRequest' => $aoRequest,
        'mroCertificate' => $mroCertificate,
        'mroAircraftCertificate' =>$mroAircraftCertificate,
        'certificateModal' => false // Flag to hide the modal initially
    ]);
}



public function actionViewPo($id)
{
    // Find the request by its ID
    $request = Requests::findOne($id);
    
    // Check if the request exists
    if (!$request) {
        throw new NotFoundHttpException('The requested page does not exist.');
    }
    
    // Find all AoRequestsApplications related to the request_id
    $aoRequestsApplications = AoRequestsApplications::find()->where(['request_id' => $id])->all();
    
    // Pass the request data and AoRequestsApplications data to the view
    return $this->render('view-po', [
        'request' => $request,
        'aoRequestsApplications' => $aoRequestsApplications,
    ]);
}
public function actionDownloadPo($id)
{
    // Find the AO request application by its ID
    $aoRequest = AoRequestsApplications::findOne($id);

    if ($aoRequest && !empty($aoRequest->po)) {
        // Define the file path
        $filePath = Yii::getAlias('@webroot/uploads/' . $aoRequest->po);

        // Check if the file exists
        if (file_exists($filePath)) {
            // Send the file to the browser for download
            return Yii::$app->response->sendFile($filePath, $aoRequest->po, ['inline' => false]);
        } else {
            // File not found, display error message
            Yii::$app->session->setFlash('error', 'File not found.');
        }
    } else {
        // No PO file associated with this request, display error message
        Yii::$app->session->setFlash('error', 'No PO file associated with this request.');
    }

    // Redirect back to the view-po page
    return $this->redirect(['view-po', 'id' => $aoRequest->request_id]);
}


    /**
     * Deletes an existing Request model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        Yii::$app->getSession()->setFlash('success', 'Request deleted successfully!');
        return $this->redirect(['new-requests']);
    }

    /**
     * Finds the Request model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Request the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Requests::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

public function actionViewReports($id)
{
    $request = Requests::findOne($id);

    if (!$request) {
        throw new NotFoundHttpException('Request not found.');
    }

    // Handle form submission (CRS approval/rejection)
    if (Yii::$app->request->isPost) {
        $post = Yii::$app->request->post();
        $reportId = $post['report_id'] ?? null; // Expect this from hidden input
        $decision = $post['approve'] ?? null;

        if ($reportId && in_array($decision, ['yes', 'no'])) {
            $report = RepairReport::findOne($reportId);
            if (!$report) {
                Yii::$app->session->setFlash('error', 'CRS report not found.');
                return $this->redirect(['view-reports', 'id' => $id]);
            }

            $lastMroRequestApply = MroRequestApply::find()
                ->where(['id' => $report->mro_request_apply_id])
                ->orderBy(['id' => SORT_DESC])
                ->one();

            $mro = MroProfile::findOne($lastMroRequestApply->mro_id);
            $notificationPreferences = MroNotificationsPreferences::findOne(['mro_id' => $mro->mro_id]);

            if ($decision === 'yes') {
                $report->quote_approved = true;
                $report->save();

                $request->status = 'closed';
                $request->save();

                if ($notificationPreferences && $notificationPreferences->notify_by_email) {
                    Yii::$app->mailer->compose('CRS_report_accepted', ['report' => $report, 'mro' => $mro])
                        ->setTo($mro->email)
                        ->setSubject('CRS report accepted')
                        ->send();
                }

                if ($notificationPreferences && $notificationPreferences->notify_by_platform) {
                    Yii::$app->runAction('notification/save-notification', [
                        'recipientType' => 'mro',
                        'recipientId' => $mro->mro_id,
                        'message' => 'CRS report accepted.',
                        'actions' =>  Yii::$app->request->baseUrl .'/mro-applications/closed-requests', // Or any route you want

                    ]);
                }

                Yii::$app->session->setFlash('success', 'CRS approved successfully.');
            } else {
                $report->quote_approved = false;
                $report->save();

                if ($notificationPreferences && $notificationPreferences->notify_by_email) {
                    Yii::$app->mailer->compose('CRS_report_rejected', ['report' => $report, 'mro' => $mro])
                        ->setTo($mro->email)
                        ->setSubject('CRS report rejected')
                        ->send();
                }

                if ($notificationPreferences && $notificationPreferences->notify_by_platform) {
                    Yii::$app->runAction('notification/save-notification', [
                        'recipientType' => 'mro',
                        'recipientId' => $mro->mro_id,
                        'message' => 'CRS report rejected.',
                        'actions' =>  Yii::$app->request->baseUrl .'/mro-applications', // Or any route you want

                    ]);
                }

                Yii::$app->session->setFlash('error', 'CRS rejected. MRO should upload new CRS.');
            }

            return $this->redirect(['view-reports', 'id' => $id]);
        }

        Yii::$app->session->setFlash('error', 'Invalid form submission.');
    }

    // Fetch reports linked to this request
        $allRepairReports = RepairReport::find()->all();

        $repairReports = [];
        foreach ($allRepairReports as $report) {
            if ($report->getRequest()->request_id == $id) {
                $repairReports[] = $report;
            }
        }

    return $this->render('view-reports', [
        'request' => $request,
        'repairReports' => $repairReports,
    ]);
}


    public function actionDownload($id)
    {
        $report = RepairReport::findOne($id);

        if (!$report || !$report->CRS_attachment) {
            throw new NotFoundHttpException('Report not found or attachment not available.');
        }
        $filePath = Yii::getAlias('@webroot/uploads/' . $report->CRS_attachment);

        if (!file_exists($filePath)) {
            throw new NotFoundHttpException('Attachment file not found.');
        }

        return Yii::$app->response->sendFile($filePath, null, ['inline' => false]);
    }

    public function actionSubmitDescription($id)
    {
        $report = RepairReport::findOne($id);
    
        if (!$report) {
            throw new NotFoundHttpException('Report not found.');
        }
    
        if ($report->load(Yii::$app->request->post())) {
            $report->AO_description = Yii::$app->request->post('RepairReport')['AO_description'];

            if ($report->save()) {

                Yii::$app->session->setFlash('success', 'Description submitted successfully.');
                return $this->redirect(['view-reports', 'id' => $report->getRequest()->request_id]);
            } else {
                Yii::$app->session->setFlash('error', 'Failed to submit description.');
            }
        }
    
        return $this->render('submit-description', [
            'report' => $report,
        ]);
    }

    public function actionAcceptCrs($id)
    {
        $report = RepairReport::findOne($id);

        if (!$report) {
            throw new NotFoundHttpException('Report not found.');
        }
        $lastMroRequestApply = MroRequestApply::find()
        ->where(['id' => $report->mro_request_apply_id]) // Assuming 'id' is the correct column name
        ->orderBy(['id' => SORT_DESC]) // Assuming 'created_at' is the timestamp column
        ->one();

        $mro =  MroProfile::findOne($lastMroRequestApply->mro_id);
        // Check if the request is a POST request and if the quote is approved
        if (Yii::$app->request->isPost && Yii::$app->request->post('approve') === 'yes') {

            // Set the quote_approved field to true
            $report->quote_approved = true;
            $report->save();

            // Set the request status to 'closed'
            $request = $report->getRequest();
            $request->status = 'closed';
            $request->save();

            $notificationPreferences = MroNotificationsPreferences::findOne(['mro_id' => $mro->mro_id]);
            if ($notificationPreferences && $notificationPreferences->notify_by_email) {
                Yii::$app->mailer->compose('CRS_report_accepted', ['report' => $report , 'mro' => $mro])
                ->setTo($mro->email)
                
                ->setSubject('CRS report accepted')
                ->send();
            }
              //platform notification
              if ($notificationPreferences && $notificationPreferences->notify_by_platform) {
                // Call the action to save the notification
                    Yii::$app->runAction('notification/save-notification', [
                        'recipientType' => 'mro',
                        'recipientId' => $mro->mro_id,
                        'message' => 'CRS report accepted.',
                                                'actions' =>  Yii::$app->request->baseUrl .'/mro-applications/closed-requests', // Or any route you want

                    ]);
                }

            Yii::$app->session->setFlash('success', 'CRS approved successfully.');

            return $this->redirect(['view-reports', 'id' => $report->getRequest()->request_id]);

        } elseif (Yii::$app->request->isPost && Yii::$app->request->post('approve') === 'no') {
            // Set the quote_approved field to true
            $report->quote_approved = false;
            $report->save();
            $notificationPreferences = MroNotificationsPreferences::findOne(['mro_id' => $mro->mro_id]);
            if ($notificationPreferences && $notificationPreferences->notify_by_email) {
                Yii::$app->mailer->compose('CRS_report_rejected', ['report' => $report , 'mro' => $mro])
                ->setTo($mro->email)
                
                ->setSubject('CRS report Rejected')
                ->send();
            }
              //platform notification
              if ($notificationPreferences && $notificationPreferences->notify_by_platform) {
                // Call the action to save the notification
                    Yii::$app->runAction('notification/save-notification', [
                        'recipientType' => 'mro',
                        'recipientId' => $mro->mro_id,
                        'message' => 'CRS report Rejected.',
                                                'actions' =>  Yii::$app->request->baseUrl .'/mro-applications', // Or any route you want

                    ]);
                }
  

            Yii::$app->session->setFlash('error', 'CRS rejected. MRO should upload new CRS.');
            return $this->redirect(['view-reports', 'id' => $report->getRequest()->request_id]);

        } else {
            Yii::$app->session->setFlash('error', 'Invalid request.');

        }
 // Render the approve quote view
 return $this->render('approve-quote', [
    'report' => $report,
]);
    }

    public function actionApproveQuote($id)
    {
        $report = RepairReport::findOne($id);

        if (!$report) {
            throw new NotFoundHttpException('Report not found.');
        }



        // Check if the request is a POST request and if the quote is approved
        if (Yii::$app->request->isPost && Yii::$app->request->post('approve') === 'yes') {

            // Set the quote_approved field to true
            $report->quote_approved = true;
            $report->save();

            // Set the request status to 'closed'
            $request = $report->getRequest();
            $request->status = 'closed';
            $request->save();

          
            Yii::$app->session->setFlash('success', 'Quote approved successfully.');

            return $this->redirect(['view-reports', 'id' => $report->getRequest()->request_id]);

        } elseif (Yii::$app->request->isPost && Yii::$app->request->post('approve') === 'no') {

            // Find the AO application and delete it
            $ao_application = AoRequestsApplications::find()->where(['application_id' => $report->mro_request_apply_id])->one();
            if ($ao_application) {
                $ao_application->delete();
            }
          // Set the request status to 'answered'
          $request = $report->getRequest();
          $request->status = 'answered';
          $request->save();
          // Remove the report
          $report->delete();

         
            Yii::$app->session->setFlash('error', 'Quote rejected. Request cancelled.');
            return $this->redirect(['index']);

        } else {
            Yii::$app->session->setFlash('error', 'Invalid request.');

        }
 // Render the approve quote view
 return $this->render('approve-quote', [
    'report' => $report,
]);
    }
    public function actionProvideFeedback($id)
    {
        $report = RepairReport::findOne($id);
        $feedback = new Feedback();

        if (!$report) {
            throw new NotFoundHttpException('Report not found.');
        }
    
        if (Yii::$app->request->isPost) {


            $feedback->request_id = $report->getRequest()->request_id;
            $feedback->ao_id = $report->getRequest()->ao_id;

            $feedback->kept_to_agreed_schedule_rating = Yii::$app->request->post('Feedback')['kept_to_agreed_schedule_rating'];
            $feedback->kept_to_agreed_cost_rating = Yii::$app->request->post('Feedback')['kept_to_agreed_cost_rating'];
            $feedback->overall_communication_rating = Yii::$app->request->post('Feedback')['overall_communication_rating'];
            $feedback->rating =round(($feedback->kept_to_agreed_schedule_rating + $feedback->kept_to_agreed_cost_rating + $feedback->overall_communication_rating)/3) ;
            $feedback->mro_id = $report->getMro()->mro_id;
            $feedback->feedback_text = Yii::$app->request->post('Feedback')['feedback_text'];
          //  VarDumper::dump($feedback); die();

            $feedback->save();
    
            Yii::$app->session->setFlash('success', 'Feedback submitted successfully.');
            $mro = $report->getMro();
            $notificationPreferences = MroNotificationsPreferences::findOne(['mro_id' => $mro->mro_id]);
            if ($notificationPreferences && $notificationPreferences->notify_by_email && $notificationPreferences->notify_for_appointment_acceptance) {
                Yii::$app->mailer->compose('feedback_sent', ['feedback' => $feedback , 'mro' => $mro])
                ->setTo($mro->email)
                
                ->setSubject('FeedBack sent')
                ->send();
            }
              //platform notification
              if ($notificationPreferences && $notificationPreferences->notify_by_platform && $notificationPreferences->notify_for_appointment_acceptance) {
                // Call the action to save the notification
                    Yii::$app->runAction('notification/save-notification', [
                        'recipientType' => 'mro',
                        'recipientId' => $mro->mro_id,
                        'message' => 'feedback has been provided for the maintenance operation.',
                                                'actions' =>  Yii::$app->request->baseUrl .'/mro-applications/closed-requests', // Or any route you want

                    ]);
                }
            return $this->redirect(['view-reports', 'id' => $report->getRequest()->request_id]);
        }
    
        return $this->render('provide-feedback', [
            'report' => $report,
            'feedback'=>$feedback,

        ]);
    }

    public function actionUpdateRequest($id)
    {
        $request = $this->findModel($id); // Fetch the request model

        // Update the status to 'update_request'
        $request->status = Requests::STATUS_UPDATE_REQUEST;


$lastMroRequestApply = MroRequestApply::find()
    ->where(['request_id' => $request->request_id])
    ->orderBy(['id' => SORT_DESC])  // Assuming 'created_at' is the timestamp column
    ->one();
//VarDumper::dump($lastMroRequestApply);die();
        $mro =  MroProfile::findOne($lastMroRequestApply->mro_id);
        // Save the updated status
        if ($request->save()) {

            $aoNotificationsPreferences = MroNotificationsPreferences::findOne(['mro_id' => $mro->mro_id]);
            if ($aoNotificationsPreferences && $aoNotificationsPreferences->notify_by_email) {
                Yii::$app->mailer->compose('update_request_recived', ['request' => $request])
                ->setTo($mro->email)
                
                ->setSubject('Update Request Recived')
                ->send();
                }
                                                  //platform notification
                                                  if ($aoNotificationsPreferences  && $aoNotificationsPreferences->notify_by_platform) {
                                                    // Call the action to save the notification
                                                    Yii::$app->runAction('notification/save-notification', [
                                                        'recipientType' => 'mro',
                                                        'recipientId' => $mro->mro_id,
                                                        'message' => 'Update Request Recived.',
                                                                                'actions' =>  Yii::$app->request->baseUrl .'/mro-applications/', // Or any route you want

                                                    ]);
                                                }
            Yii::$app->session->setFlash('success', 'Request status updated to Update Request successfully.');
        } else {
            Yii::$app->session->setFlash('error', 'Failed to update request status.');
        }

        return $this->redirect(['requests/update', 'id' => $request->request_id,'status' =>$request->status]); // Redirect to view page or any other page
    }


    public function actionContact($id)
    {
        $mroRequestApplication = MroRequestApply::findOne($id);
        // Check if a conversation already exists for the given request
        $conversation = Conversations::findOne(['request_id' => $mroRequestApplication->request_id]);
    
        // If conversation does not exist, create a new one
        if (!$conversation) {
            // Create a new chat
            $chat = new Chat();
            $chat->mro_id =  $mroRequestApplication->mro_id;
            $chat->ao_id = Yii::$app->session->get('ao_id');
            $chat->request_id =  $mroRequestApplication->request_id;

            $chat->save();
    
            // Create a new conversation
            $conversation = new Conversations();
            $conversation->request_id =  $mroRequestApplication->request_id;
            $conversation->chat_id = $chat->chat_id;
            $conversation->sender_id = $chat->ao_id;
            $conversation->sender_type ='ao';
            $conversation->receiver_id = $chat->mro_id;
            $conversation->receiver_type ='mro';
            // Additional attributes initialization if needed
            $conversation->save();


        }
    
        // Redirect to view the conversation
        return $this->redirect(['conversations/view', 'chat_id' => $conversation->chat_id]);
    }
    
}
