<?php

use app\models\Airports;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use app\models\Countries; // Import the Countries model
use app\models\Cities; // Import the Cities model

$this->title = ' Add Airport(s) to MRO';
    set_time_limit(120);

?>
<style>
/* CSS for enabling vertical scrolling in Kartik Select2 */

.select2-container--krajee-bs5 .select2-selection--multiple .select2-selection__rendered {
    display: flex;
    flex-wrap: wrap; /* Allow choices to wrap */
    max-height: 100px!important; /* Set a maximum height for the container */
    overflow-y: auto !important; /* Enable vertical scrolling */
}

.select2-container--krajee-bs5 .select2-selection--multiple .select2-selection__choice  {
    white-space: normal !important; /* Allow text to wrap */
    display: inline-block !important; /* Ensure each choice is a block element */
    margin: 2px !important; /* Add some spacing between choices */
    max-width: 100% !important; /* Ensure choices take full width */
}







#city-dropdown {
    width: 100% !important;
    /* Add other necessary CSS rules */
}
</style>

<main class="dash-content">
    <div class="container-fluid">
        <h1 class="dash-title"><?= Html::encode($this->title) ?></h1>
        <?php
        if (Yii::$app->session->hasFlash('message')) {
            echo '<div class="alert alert-success">' . Yii::$app->session->getFlash('message') . '</div>';
        }

        if (Yii::$app->session->hasFlash('error')) {
            echo '<div class="alert alert-danger">' . Yii::$app->session->getFlash('error') . '</div>';
        }
        ?>
        <div class="row mb-3">
    <div class="col-lg-6">
                <button type="button" class="btn btn-secondary" id="btn-logic-icao">
            Search by ICAO
        </button>
        <button type="button" class="btn btn-primary" id="btn-logic-select">
            Select by Country / City
        </button>


    </div>
</div>
        <?php $form = ActiveForm::begin(); ?>
<div id="logic-select" style="display:none;">

        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($model, 'country_id')->widget(Select2::classname(), [
                'data' => ArrayHelper::map(Countries::find()->orderBy('country_name')->all(), 'country_id', 'country_name'),
                'options' => [
                    'placeholder' => 'Select Country',
                    'multiple' => true,
                    'id' => 'country-dropdown',
                    'class' => 'scrollable-select2', // Add custom CSS class
                ],
                'pluginOptions' => [
                    'allowClear' => true,
                    'scrollAfterSelect' => true,
                ],
            ])->label('Countries'); ?>

                <?= Html::hiddenInput('country_ids', '', ['id' => 'country-ids-hidden']) ?>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($model, 'city_id')->widget(Select2::classname(), [
                    'data' => [], // Initial empty data
                    'options' => [
                        'placeholder' => 'Select City',
                        'multiple' => true,
                        'id' => 'city-dropdown',
                    ],
                    'pluginOptions' => [
                        'allowClear' => false,
                        'scrollAfterSelect' => true, // Enable scrollAfterSelect
                    ],
                ]); ?>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <?= $form->field($model, 'airport_id')->widget(Select2::classname(), [
                    'data' => [], // Initial empty data
                    'options' => [
                        'placeholder' => 'Select Airport',
                        'multiple' => true,
                        'id' => 'airport-dropdown',

                    ],
                    'pluginOptions' => [
                        'allowClear' => true,
                        'scrollAfterSelect' => true, // Enable scrollAfterSelect
                    ],
                ]); ?>
            </div>
        </div>
        </div>
<div id="logic-icao">

<div class="row">
    <div class="col-lg-6">
        <?= $form->field($model, 'airport_id_icao')->widget(Select2::classname(), [
            'options' => [
                'placeholder' => 'Type ICAO (Write minimum 3 letters)',
                'multiple' => true,
            ],
            'pluginOptions' => [
                'allowClear' => true,
                'minimumInputLength' => 3,
                'ajax' => [
                    'url' => \yii\helpers\Url::to(['/mro-airports/search-airports']),
                    'dataType' => 'json',
                    'delay' => 250,
                    'data' => new \yii\web\JsExpression('function(params) {
                        return {q:params.term};
                    }'),
                    'processResults' => new \yii\web\JsExpression('function(data) {
                        return {results:data.results};
                    }'),
                ],
            ],
        ]); ?>
    </div>
</div>

</div>
        <div class="row">
            <div class="form-group col-lg-6">
                <?= Html::submitButton('Create', ['class' => 'btn btn-primary']) ?>
                <?= Html::a('Cancel', Yii::$app->request->referrer, [ 'class' => 'btn btn-secondary']) ?>

            </div>
        </div>

        <?php ActiveForm::end(); ?>
    </div>
</main>
<?php
$this->registerJs('
// Initial load of countries
var countries = ' . json_encode(ArrayHelper::map(Countries::find()->orderBy("country_name")->all(), "country_id", "country_name")) . ';

// When the country dropdown value changes
$("#country-dropdown").on("change", function() {
    var selectedCountries = $(this).val();
    
    if (selectedCountries && selectedCountries.length > 0) {
        $.ajax({
            url: "' . \yii\helpers\Url::to(['/site/load-cities']) . '",
            type: "POST",
            data: { country_ids: selectedCountries },
            success: function(data) {
                var selectedCities = data.cities;
                 // Convert the cities object into an array of key-value pairs and sort by city name
                    var sortedCities = Object.keys(selectedCities)
                        .map(function(key) {
                            return { id: key, name: selectedCities[key] };
                        })
                        .sort(function(a, b) {
                            return a.name.localeCompare(b.name); // Sort by city name
                        });

                var cityOptions = "<option value=\'\' disabled>Select City</option>"; // Default "Select City" option
                // Loop through the cities and generate options


                    sortedCities.forEach(function(city) {
                        cityOptions += "<option value=\'" + city.id + "\'>" + city.name + "</option>";
                    });
                
                // Update the city dropdown and trigger the change event
                $("#city-dropdown").html(cityOptions).trigger("change");
            }
        });
    } else {
        // If no countries are selected, clear the city dropdown
        $("#city-dropdown").empty().trigger("change");
    }
});

    $("#city-dropdown").on("change", function() {
        var selectedCities = $(this).val();
        if (selectedCities.length > 0) {
            $.ajax({
                url: "' . \yii\helpers\Url::to(['/site/load-airports']) . '",
                type: "POST",
                data: { city_ids: selectedCities },
                success: function(data) {
                    var selectedAirports = data.airports;
                    // Convert the airports object into an array of key-value pairs and sort by airport_name
                    var sortedAirports = Object.keys(selectedAirports)
                        .map(function(key) {
                            return { id: key, name: selectedAirports[key] };
                        })
                        .sort(function(a, b) {
                            return a.name.localeCompare(b.name); // Sort by airport name
                        });

                    // Create the airport dropdown options
                    var airportOptions = "<option value=\'\' disabled>Select Airport</option>"; // Default "Select Airport" option
                    
                    sortedAirports.forEach(function(airport) {
                        airportOptions += "<option value=\'" + airport.id + "\'>" + airport.name + "</option>";
                    });
                    
                    // Update the airport dropdown and trigger the change event
                    $("#airport-dropdown").html(airportOptions).trigger("change");
                }
            });
        } else {
            $("#airport-dropdown").empty().trigger("change");
        }
    });

    // Trigger the initial change to load cities and airports if any country/city is selected
    $("#country-dropdown").trigger("change");
    $("#city-dropdown").trigger("change");

// Default mode = ICAO search
$(document).ready(function(){

    $("#logic-select").hide();
    $("#logic-icao").show();

    // disable select logic
    $("#country-dropdown").prop("disabled", true);
    $("#city-dropdown").prop("disabled", true);
    $("#airport-dropdown").prop("disabled", true);

    // enable ICAO search
    $("#logic-icao select").prop("disabled", false);

});

$("#btn-logic-select").click(function(){

    $("#logic-select").show();
    $("#logic-icao").hide();

    // enable select logic fields
    $("#country-dropdown").prop("disabled", false);
    $("#city-dropdown").prop("disabled", false);
    $("#airport-dropdown").prop("disabled", false);

    // disable icao search
    $("#logic-icao select").prop("disabled", true);

});

$("#btn-logic-icao").click(function(){

    $("#logic-select").hide();
    $("#logic-icao").show();

    // disable select logic
    $("#country-dropdown").prop("disabled", true);
    $("#city-dropdown").prop("disabled", true);
    $("#airport-dropdown").prop("disabled", true);

    // enable icao search
    $("#logic-icao select").prop("disabled", false);

});
');
?>




