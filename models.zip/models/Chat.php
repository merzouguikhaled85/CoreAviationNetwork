<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

class Chat extends ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'chat';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['mro_id', 'ao_id'], 'required'],
            [['mro_id', 'ao_id', 'request_id'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'chat_id' => 'Chat ID',
            'mro_id' => 'MRO ID',
            'ao_id' => 'AO ID',
            'request_id' => 'Request ID',
        ];
    }
}
