<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\base\InvalidConfigException;

class UsernameResetRequestForm extends Model
{
    public $email;
    public $usertype;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['email', 'usertype'], 'required'],
            [['email'], 'email'],
            [['usertype'], 'in', 'range' => ['mro', 'ao']],
        ];
    }

    /**
     * Sends an email with a link, for user to reset their username.
     *
     * @return bool whether the email was sent
     * @throws InvalidConfigException
     */
    public function sendEmail()
    {
        if ($this->usertype == 'mro') {
            $user = MroProfile::findOne(['status' => 'active', 'email' => $this->email]);
        } else {
            $user = AoProfile::findOne(['status' => 'active', 'email' => $this->email]);
        }

        if (!$user) {
            return false;
        }

        $mailer = Yii::$app->mailer;
        $message = $mailer->compose()
            ->setTo($this->email)
            ->setSubject('Your username reminder')
            ->setTextBody("Your username is: {$user->username}");

        return $message->send();
    }
}
