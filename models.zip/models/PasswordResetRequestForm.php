<?php
namespace app\models;

use Yii;
use yii\base\Model;

class PasswordResetRequestForm extends Model
{
    public $email;

    public function rules()
    {
        return [
            [['email'], 'required'],
            [['email'], 'email'],
        ];
    }

    public function sendEmail()
    {
        /* @var $user AoProfile */
        $user = AoProfile::findOne([
            'email' => $this->email,
            'status' => 'active',
        ]);
        if (!$user) {
            $user = MroProfile::findOne([
                'email' => $this->email,
                'status' => 'active',
            ]);
        }
    


        if (!$user) {
            return false;
        }

        if (!$user->generatePasswordResetToken()) {
            return false;
        }

        return Yii::$app->mailer->compose()
            ->setTo($this->email)
            ->setFrom([Yii::$app->params['adminEmail'] => Yii::$app->name])
            ->setSubject('Password reset for ' . Yii::$app->name)
            ->setTextBody('Follow the link to reset your password: ' . Yii::$app->urlManager->createAbsoluteUrl(['site/reset-password', 'token' => $user->password_reset_token]))
            ->send();
    }
}
