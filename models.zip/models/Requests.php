<?php
namespace app\models;

use Yii;
use yii\db\ActiveRecord;

class Requests extends ActiveRecord
{
    const STATUS_CREATED = 'created';
    const STATUS_ANSWERED = 'answered';
    const STATUS_PO_LOADED = 'po_loaded';
    const STATUS_WORK_ACCEPTED = 'work_accepted';
    const STATUS_WORK_STARTED = 'work_started';
    const STATUS_REPORT_SUBMITTED = 'report_submitted';
    const STATUS_CLOSED = 'closed';
    const STATUS_CANCELLED = 'cancelled';
    const STATUS_UPDATE_REQUEST = 'update_request'; // New status added
    const STATUS_UPDATE_REQUEST_ACCEPTED = 'update_request_accepted'; // New status added
    const STATUS_UPDATE_REQUEST_DENIED = 'update_request_denied'; // New status added


    public static function tableName()
    {
        return 'requests';
    }

    public function rules()
    {
        return [
            [['request_details', 'status','aircraft_registration', 'location', 'serial_number', 'aircraft_id', 'destination'], 'required'],
            [['ao_id', 'aircraft_id', 'destination'], 'integer'],
            [['eta', 'etd'], 'required'],
            [['request_details', 'attachment','required_certificates'], 'string'],
            [['aircraft_registration', 'location', 'serial_number'], 'string', 'max' => 255],
            [['status'], 'in', 'range' => [
                self::STATUS_CREATED,
                self::STATUS_ANSWERED,
                self::STATUS_PO_LOADED,
                self::STATUS_WORK_ACCEPTED,
                self::STATUS_WORK_STARTED,
                self::STATUS_REPORT_SUBMITTED,
                self::STATUS_CLOSED,
                self::STATUS_CANCELLED,
                self::STATUS_UPDATE_REQUEST, // Include the new status here
                self::STATUS_UPDATE_REQUEST_ACCEPTED, // Include the new status here
                self::STATUS_UPDATE_REQUEST_DENIED, // Include the new status here

            ]],
            ['required_certificates', 'safe'],
        ];
    }

    public function attributeLabels()
    {
        return [
            'request_id' => 'Request ID',
            'ao_id' => 'AO ID',
            'aircraft_id' => 'Aircraft Model ID',
            'request_details' => 'Request Details',
            'aircraft_registration' => 'Aircraft Registration',
            'serial_number' => 'Serial Number',
            'eta' => 'ETA',
            'etd' => 'ETD',
            'location' => 'Location',
            'destination' => 'Destination (Airport)',
            'status' => 'Status',
            'required_certificates' => 'Required Certificates',
            'attachment' => 'Attachment',
        ];
    }

    public function getRequiredCertificates()
    {
        return $this->hasMany(Certificates::className(), ['certificate_id' => 'certificate_id'])
            ->viaTable('request_certificates', ['request_id' => 'request_id']);
    }

    public function getDestinationAirport()
    {
        return $this->hasOne(Airports::className(), ['airport_id' => 'destination']);
    }

    public function getAO()
    {
        return $this->hasOne(AoProfile::className(), ['ao_id' => 'ao_id']);
    }
    public function getAircraft()
    {
        return $this->hasOne(Aircrafts::className(), ['aircraft_id' => 'aircraft_id']);
    }
    public function getMroApplication()
{
    return $this->hasOne(MroRequestApply::className(), ['request_id' => 'request_id']);
}

}
