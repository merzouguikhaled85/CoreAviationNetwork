<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\base\InvalidConfigException;

class UserPasswordResetRequestForm extends Model
{
    public $email;
    public $usertype;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['email', 'usertype'], 'required'],
            [['email'], 'email'],
            [['usertype'], 'in', 'range' => ['mro', 'ao']],
        ];
    }

    /**
     * Sends an email with a link, for resetting the password.
     *
     * @return bool whether the email was sent
     * @throws InvalidConfigException
     */
    public function sendEmail()
    {
        if ($this->usertype == 'mro') {
            $user = MroProfile::findOne(['status' => 'active', 'email' => $this->email]);
        } else {
            $user = AoProfile::findOne(['status' =>  'active', 'email' => $this->email]);
        }

        if (!$user) {
            return false;
        }

        $user->generatePasswordResetToken();
        if (!$user->save()) {
            return false;
        }

        $resetLink = Yii::$app->urlManager->createAbsoluteUrl(['site/reset-password', 'token' => $user->password_reset_token]);

        $mailer = Yii::$app->mailer;
        $message = $mailer->compose()
            ->setTo($this->email)
            ->setSubject('Password reset')
            ->setTextBody("Follow the link below to reset your password:\n\n$resetLink");

        return $message->send();
    }
}
